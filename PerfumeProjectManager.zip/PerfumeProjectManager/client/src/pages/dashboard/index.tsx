import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { ArrowUpIcon, AlertTriangle, AlertCircle, GripVertical, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Project, Task } from "@/lib/types";
import { format } from "date-fns";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import LowStockAlert from "@/components/resources/LowStockAlert";
import { useState, useEffect } from "react";
import GridLayout from "react-grid-layout";
import 'react-grid-layout/css/styles.css';
import 'react-resizable/css/styles.css';
import { useToast } from "@/hooks/use-toast";

// Define the widget structure
interface WidgetLayout {
  i: string;
  x: number;
  y: number;
  w: number;
  h: number;
  minW?: number;
  minH?: number;
  static?: boolean;
}

// Widget IDs
enum WidgetId {
  ACTIVE_PROJECTS = "activeProjects",
  PENDING_FORMULAS = "pendingFormulas",
  RESOURCE_REQUESTS = "resourceRequests",
  RECENT_PROJECTS = "recentProjects",
  UPCOMING_TASKS = "upcomingTasks",
  LOW_STOCK = "lowStock"
}

const Dashboard = () => {
  const { toast } = useToast();
  const { data, isLoading } = useQuery({
    queryKey: ['/api/dashboard'],
  });
  
  // Default dashboard layout
  const defaultLayout: WidgetLayout[] = [
    { i: WidgetId.ACTIVE_PROJECTS, x: 0, y: 0, w: 1, h: 2, minW: 1, minH: 2 },
    { i: WidgetId.PENDING_FORMULAS, x: 1, y: 0, w: 1, h: 2, minW: 1, minH: 2 },
    { i: WidgetId.RESOURCE_REQUESTS, x: 2, y: 0, w: 1, h: 2, minW: 1, minH: 2 },
    { i: WidgetId.RECENT_PROJECTS, x: 0, y: 2, w: 3, h: 4, minW: 2, minH: 4 },
    { i: WidgetId.UPCOMING_TASKS, x: 0, y: 6, w: 1.5, h: 4, minW: 1, minH: 3 },
    { i: WidgetId.LOW_STOCK, x: 1.5, y: 6, w: 1.5, h: 4, minW: 1, minH: 3 }
  ];

  // Layout State
  const [layout, setLayout] = useState<WidgetLayout[]>(() => {
    // Try to load layout from localStorage
    const savedLayout = localStorage.getItem('dashboard-layout');
    return savedLayout ? JSON.parse(savedLayout) : defaultLayout;
  });
  
  const [isEditing, setIsEditing] = useState(false);
  
  // Save layout to localStorage when it changes
  useEffect(() => {
    localStorage.setItem('dashboard-layout', JSON.stringify(layout));
  }, [layout]);

  // Widget rendering functions
  const getStageProgress = (stage: string): number => {
    switch (stage.toLowerCase()) {
      case 'planning': return 25;
      case 'formulation': return 50;
      case 'testing': return 75;
      case 'completed': return 100;
      default: return 0;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800">Active</Badge>;
      case 'in review':
        return <Badge className="bg-yellow-100 text-yellow-800">In Review</Badge>;
      case 'new':
        return <Badge className="bg-blue-100 text-blue-800">New</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority.toLowerCase()) {
      case 'high':
        return <Badge variant="destructive">Urgent</Badge>;
      case 'medium':
        return <Badge className="bg-amber-100 text-amber-800">Medium</Badge>;
      case 'low':
        return <Badge className="bg-blue-100 text-blue-800">Normal</Badge>;
      default:
        return <Badge variant="outline">{priority}</Badge>;
    }
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return "N/A";
    return format(new Date(dateString), "MMM dd, yyyy");
  };

  const handleLayoutChange = (newLayout: WidgetLayout[]) => {
    setLayout(newLayout);
  };

  const saveLayout = () => {
    localStorage.setItem('dashboard-layout', JSON.stringify(layout));
    setIsEditing(false);
    toast({
      title: "Dashboard layout saved",
      description: "Your customized dashboard layout has been saved."
    });
  };

  const resetLayout = () => {
    setLayout(defaultLayout);
    localStorage.setItem('dashboard-layout', JSON.stringify(defaultLayout));
    toast({
      title: "Dashboard layout reset",
      description: "Your dashboard has been reset to default layout."
    });
    setIsEditing(false);
  };

  // Widget components
  const renderWidgets = () => {
    const widgets: Record<string, JSX.Element> = {
      [WidgetId.ACTIVE_PROJECTS]: (
        <Card className="card-hover h-full">
          {isEditing && <div className="absolute right-2 top-2 text-gray-400 drag-handle cursor-move"><GripVertical size={16} /></div>}
          <CardContent className="p-5">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-medium text-gray-800">Active Projects</h2>
              <div className="text-primary">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-activity"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
              </div>
            </div>
            <div className="text-3xl font-bold text-gray-900 mb-2">{data?.stats?.activeProjects || 0}</div>
            <div className="flex items-center text-green-600">
              <ArrowUpIcon className="h-4 w-4 mr-1" />
              <span className="text-sm">+2 from last month</span>
            </div>
          </CardContent>
        </Card>
      ),
      [WidgetId.PENDING_FORMULAS]: (
        <Card className="card-hover h-full">
          {isEditing && <div className="absolute right-2 top-2 text-gray-400 drag-handle cursor-move"><GripVertical size={16} /></div>}
          <CardContent className="p-5">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-medium text-gray-800">Pending Formulas</h2>
              <div className="text-primary">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-flask-conical"><path d="M10 2v7.527a2 2 0 0 1-.211.896L4.72 20.55a1 1 0 0 0 .9 1.45h12.76a1 1 0 0 0 .9-1.45l-5.069-10.127A2 2 0 0 1 14 9.527V2"/><path d="M8.5 2h7"/><path d="M7 16h10"/></svg>
              </div>
            </div>
            <div className="text-3xl font-bold text-gray-900 mb-2">{data?.stats?.pendingFormulas || 0}</div>
            <div className="flex items-center text-amber-600">
              <AlertTriangle className="h-4 w-4 mr-1" />
              <span className="text-sm">3 require attention</span>
            </div>
          </CardContent>
        </Card>
      ),
      [WidgetId.RESOURCE_REQUESTS]: (
        <Card className="card-hover h-full">
          {isEditing && <div className="absolute right-2 top-2 text-gray-400 drag-handle cursor-move"><GripVertical size={16} /></div>}
          <CardContent className="p-5">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-medium text-gray-800">Resource Requests</h2>
              <div className="text-primary">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-package"><path d="M16.5 9.4 7.55 4.24"/><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.29 7 12 12 20.71 7"/><line x1="12" y1="22" x2="12" y2="12"/></svg>
              </div>
            </div>
            <div className="text-3xl font-bold text-gray-900 mb-2">{data?.stats?.resourceRequests || 0}</div>
            <div className="flex items-center text-red-600">
              <AlertCircle className="h-4 w-4 mr-1" />
              <span className="text-sm">{data?.stats?.urgentRequests || 0} urgent requests</span>
            </div>
          </CardContent>
        </Card>
      ),
      [WidgetId.RECENT_PROJECTS]: (
        <Card className="h-full overflow-hidden">
          {isEditing && <div className="absolute right-2 top-2 text-gray-400 drag-handle cursor-move"><GripVertical size={16} /></div>}
          <CardHeader className="px-5 py-4 border-b">
            <CardTitle>Recent Projects</CardTitle>
          </CardHeader>
          <div className="overflow-auto" style={{ maxHeight: 'calc(100% - 120px)' }}>
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50 sticky top-0">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Project</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Client</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stage</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Due</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {data?.recentProjects?.map((project: Project) => (
                  <tr key={project.id}>
                    <td className="px-6 py-3 whitespace-nowrap">
                      <div className="flex items-center">
                        <div>
                          <div className="text-sm font-medium text-gray-900">{project.name}</div>
                          <div className="text-sm text-gray-500 truncate max-w-[150px]">{project.description}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-3 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{project.client}</div>
                    </td>
                    <td className="px-6 py-3 whitespace-nowrap">
                      {getStatusBadge(project.status)}
                    </td>
                    <td className="px-6 py-3 whitespace-nowrap text-sm text-gray-500">
                      <div className="flex items-center">
                        <Progress className="w-16 h-2 mr-2" value={getStageProgress(project.stage)} />
                        <span>{project.stage}</span>
                      </div>
                    </td>
                    <td className="px-6 py-3 whitespace-nowrap text-sm text-gray-500">
                      {formatDate(project.dueDate)}
                    </td>
                    <td className="px-6 py-3 whitespace-nowrap text-sm font-medium">
                      <Button variant="link" className="text-primary hover:text-primary-dark mr-3 p-0 h-auto">
                        View
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="px-5 py-3 border-t flex justify-between items-center">
            <span className="text-sm text-gray-700">
              Showing {data?.recentProjects?.length || 0} of {data?.stats?.activeProjects || 0} projects
            </span>
            <Button variant="link" className="text-primary hover:text-primary-dark flex items-center p-0">
              View All Projects
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-1"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
            </Button>
          </div>
        </Card>
      ),
      [WidgetId.UPCOMING_TASKS]: (
        <Card className="h-full flex flex-col">
          {isEditing && <div className="absolute right-2 top-2 text-gray-400 drag-handle cursor-move"><GripVertical size={16} /></div>}
          <CardHeader className="px-5 py-4 border-b flex flex-row items-center justify-between">
            <CardTitle>Upcoming Tasks</CardTitle>
            <Button variant="ghost" size="icon" className="text-primary">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 5v14"/><path d="M5 12h14"/></svg>
            </Button>
          </CardHeader>
          <CardContent className="p-5 flex-grow overflow-auto">
            <ul className="divide-y divide-gray-200">
              {data?.upcomingTasks?.map((task: Task) => (
                <li key={task.id} className="py-3 flex items-center">
                  <input type="checkbox" className="mr-3 h-5 w-5 text-primary rounded" />
                  <div className="flex-1">
                    <p className="text-gray-800 font-medium">{task.title}</p>
                    <p className="text-sm text-gray-500">
                      Due {task.dueDate ? formatDate(task.dueDate) : 'Not set'}
                    </p>
                  </div>
                  {getPriorityBadge(task.priority)}
                </li>
              ))}
            </ul>
          </CardContent>
          <div className="px-5 py-3 border-t mt-auto">
            <Button variant="link" className="text-primary hover:text-primary-dark flex items-center justify-center w-full p-0">
              View All Tasks
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-1"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
            </Button>
          </div>
        </Card>
      ),
      [WidgetId.LOW_STOCK]: (
        <div className="h-full">
          {isEditing && <div className="absolute right-2 top-2 text-gray-400 drag-handle cursor-move z-10"><GripVertical size={16} /></div>}
          <div className="flex flex-col h-full">
            <h3 className="text-lg font-medium text-gray-800 mb-3">Inventory Status</h3>
            <div className="flex-grow overflow-auto">
              <LowStockAlert />
            </div>
          </div>
        </div>
      )
    };

    return Object.entries(widgets).map(([key, widget]) => (
      <div key={key}>{widget}</div>
    ));
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardContent className="p-5">
                <div className="flex justify-between items-center mb-4">
                  <Skeleton className="h-6 w-40" />
                  <Skeleton className="h-6 w-6 rounded-full" />
                </div>
                <Skeleton className="h-10 w-16 mb-2" />
                <Skeleton className="h-4 w-32" />
              </CardContent>
            </Card>
          ))}
        </div>
        
        <Card className="mb-6">
          <CardHeader className="pb-2">
            <CardTitle>
              <Skeleton className="h-6 w-40" />
            </CardTitle>
          </CardHeader>
          <div className="overflow-x-auto">
            <Skeleton className="h-64 w-full" />
          </div>
        </Card>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {[1, 2].map((i) => (
            <Card key={i}>
              <CardHeader className="pb-2 flex flex-row items-center justify-between">
                <CardTitle>
                  <Skeleton className="h-6 w-40" />
                </CardTitle>
                <Skeleton className="h-8 w-8 rounded-full" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-60 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <div className="flex gap-2">
          {isEditing ? (
            <>
              <Button 
                className="bg-green-600 hover:bg-green-700" 
                size="sm"
                onClick={saveLayout}
              >
                <Save className="mr-2 h-4 w-4" />
                Save Layout
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setIsEditing(false)}
              >
                Cancel
              </Button>
              <Button 
                variant="destructive" 
                size="sm"
                onClick={resetLayout}
              >
                Reset to Default
              </Button>
            </>
          ) : (
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setIsEditing(true)}
            >
              Customize Layout
            </Button>
          )}
        </div>
      </div>

      <style jsx global>{`
        .react-grid-item {
          transition: all 200ms ease;
          transition-property: left, top;
        }
        .react-grid-item.react-grid-placeholder {
          background: #66a8ff;
          opacity: 0.2;
          border-radius: 0.5rem;
        }
        .react-resizable-handle {
          position: absolute;
          bottom: 0;
          right: 0;
          width: 20px;
          height: 20px;
          background-repeat: no-repeat;
          background-origin: content-box;
          box-sizing: border-box;
          padding: 0 3px 3px 0;
          background-image: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA2IDYiIHN0eWxlPSJiYWNrZ3JvdW5kLWNvbG9yOiNmZmZmZmYwMCIgeD0iMHB4IiB5PSIwcHgiIHdpZHRoPSI2cHgiIGhlaWdodD0iNnB4Ij48ZyBvcGFjaXR5PSIwLjMwMiI+PHBhdGggZD0iTSA2IDYgTCAwIDYgTCAwIDQuMiBMIDQgNC4yIEwgNC4yIDQuMiBMIDQuMiAwIEwgNiAwIEwgNiA2IEwgNiA2IFoiIGZpbGw9IiMwMDAwMDAiLz48L2c+PC9zdmc+');
          background-position: bottom right;
          cursor: se-resize;
        }
        .drag-handle {
          cursor: move;
        }
      `}</style>

      <GridLayout 
        className="layout"
        layout={layout}
        cols={3}
        rowHeight={85}
        width={window.innerWidth - 48} // Adjust for padding
        onLayoutChange={handleLayoutChange}
        isDraggable={isEditing}
        isResizable={isEditing}
        draggableHandle=".drag-handle"
        margin={[16, 16]}
        containerPadding={[0, 0]}
      >
        {renderWidgets()}
      </GridLayout>
    </div>
  );
};

export default Dashboard;
