import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Download, TrendingUp, Users, Calendar, FileText } from "lucide-react";

const MarketingPage = () => {
  // Sample data for charts
  const perfumePerformanceData = [
    { name: "Jan", sales: 4000, impressions: 2400 },
    { name: "Feb", sales: 3000, impressions: 1398 },
    { name: "Mar", sales: 2000, impressions: 9800 },
    { name: "Apr", sales: 2780, impressions: 3908 },
    { name: "May", sales: 1890, impressions: 4800 },
    { name: "Jun", sales: 2390, impressions: 3800 },
    { name: "Jul", sales: 3490, impressions: 4300 },
  ];

  const marketSegmentData = [
    { name: "Luxury", value: 45 },
    { name: "Mid-range", value: 30 },
    { name: "Budget", value: 15 },
    { name: "Specialty", value: 10 },
  ];

  const COLORS = ["#8D6E63", "#A1887F", "#BCAAA4", "#D7CCC8"];

  const campaignData = [
    { name: "Summer Collection", reach: 95000, engagement: 12000, conversions: 3500 },
    { name: "Winter Essentials", reach: 70000, engagement: 8500, conversions: 2300 },
    { name: "Spring Launch", reach: 85000, engagement: 10200, conversions: 3100 },
    { name: "Holiday Special", reach: 110000, engagement: 15000, conversions: 4200 },
    { name: "Valentine's Day", reach: 65000, engagement: 7800, conversions: 1900 },
  ];

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold mb-2">Marketing Dashboard</h1>
          <p className="text-gray-500">Analyze market trends and campaign performance for your perfumery products</p>
        </div>
        <Button variant="outline" className="flex items-center gap-2">
          <Download className="h-4 w-4" />
          Export Reports
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start mb-2">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                <TrendingUp className="h-6 w-6" />
              </div>
              <span className="text-3xl font-bold">23.4%</span>
            </div>
            <h3 className="font-medium">Growth Rate</h3>
            <p className="text-sm text-gray-500">Year-over-year sales growth</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start mb-2">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                <Users className="h-6 w-6" />
              </div>
              <span className="text-3xl font-bold">87.3K</span>
            </div>
            <h3 className="font-medium">Customer Reach</h3>
            <p className="text-sm text-gray-500">Total customer impressions</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start mb-2">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                <Calendar className="h-6 w-6" />
              </div>
              <span className="text-3xl font-bold">3</span>
            </div>
            <h3 className="font-medium">Active Campaigns</h3>
            <p className="text-sm text-gray-500">Currently running campaigns</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="mb-6">
        <TabsList className="mb-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
          <TabsTrigger value="market-analysis">Market Analysis</TabsTrigger>
          <TabsTrigger value="content">Content Planning</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Perfume Performance</CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={perfumePerformanceData}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="sales" stroke="#6D4C41" activeDot={{ r: 8 }} />
                      <Line type="monotone" dataKey="impressions" stroke="#8D6E63" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Market Segments</CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={marketSegmentData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {marketSegmentData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="campaigns">
          <Card>
            <CardHeader>
              <CardTitle>Campaign Performance</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="h-96">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={campaignData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="reach" fill="#6D4C41" name="Reach" />
                    <Bar dataKey="engagement" fill="#8D6E63" name="Engagement" />
                    <Bar dataKey="conversions" fill="#A1887F" name="Conversions" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Campaign Calendar</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center px-4 py-3 bg-primary/5 rounded-lg">
                    <Calendar className="h-8 w-8 text-primary mr-4" />
                    <div>
                      <h3 className="font-medium">Summer Collection Launch</h3>
                      <p className="text-sm text-gray-500">Jun 15 - Jul 30</p>
                    </div>
                    <Badge className="ml-auto bg-green-100 text-green-800">Active</Badge>
                  </div>
                  <div className="flex items-center px-4 py-3 bg-primary/5 rounded-lg">
                    <Calendar className="h-8 w-8 text-primary mr-4" />
                    <div>
                      <h3 className="font-medium">Fall Essentials Preview</h3>
                      <p className="text-sm text-gray-500">Aug 10 - Aug 25</p>
                    </div>
                    <Badge className="ml-auto bg-yellow-100 text-yellow-800">Planned</Badge>
                  </div>
                  <div className="flex items-center px-4 py-3 bg-primary/5 rounded-lg">
                    <Calendar className="h-8 w-8 text-primary mr-4" />
                    <div>
                      <h3 className="font-medium">Holiday Special Collection</h3>
                      <p className="text-sm text-gray-500">Nov 15 - Dec 25</p>
                    </div>
                    <Badge className="ml-auto bg-blue-100 text-blue-800">Upcoming</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Campaign Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Customer Acquisition Cost</span>
                      <span className="text-sm">$24.50</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-primary h-2.5 rounded-full" style={{ width: "65%" }}></div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Conversion Rate</span>
                      <span className="text-sm">3.8%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-primary h-2.5 rounded-full" style={{ width: "38%" }}></div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Email Open Rate</span>
                      <span className="text-sm">28.4%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-primary h-2.5 rounded-full" style={{ width: "72%" }}></div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Social Media Engagement</span>
                      <span className="text-sm">15.2%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-primary h-2.5 rounded-full" style={{ width: "52%" }}></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="market-analysis">
          <Card>
            <CardHeader>
              <CardTitle>Market Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium mb-4">Market Trends</h3>
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <div className="h-6 w-6 rounded-full bg-green-100 flex items-center justify-center text-green-600 mt-0.5 mr-3">
                        <TrendingUp className="h-4 w-4" />
                      </div>
                      <div>
                        <h4 className="font-medium">Sustainable Ingredients</h4>
                        <p className="text-sm text-gray-500">Growing demand for environmentally friendly ingredients and packaging</p>
                      </div>
                    </li>
                    <li className="flex items-start">
                      <div className="h-6 w-6 rounded-full bg-green-100 flex items-center justify-center text-green-600 mt-0.5 mr-3">
                        <TrendingUp className="h-4 w-4" />
                      </div>
                      <div>
                        <h4 className="font-medium">Unisex Fragrances</h4>
                        <p className="text-sm text-gray-500">Increasing popularity of gender-neutral scents in the market</p>
                      </div>
                    </li>
                    <li className="flex items-start">
                      <div className="h-6 w-6 rounded-full bg-green-100 flex items-center justify-center text-green-600 mt-0.5 mr-3">
                        <TrendingUp className="h-4 w-4" />
                      </div>
                      <div>
                        <h4 className="font-medium">Clean Beauty</h4>
                        <p className="text-sm text-gray-500">Rising demand for non-toxic, natural formulations</p>
                      </div>
                    </li>
                    <li className="flex items-start">
                      <div className="h-6 w-6 rounded-full bg-red-100 flex items-center justify-center text-red-600 mt-0.5 mr-3">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M23 18c-3.33-3.5-6.67-3.5-10-3.5s-6.67 0-10 3.5"/><path d="M23 6c-3.33 3.5-6.67 3.5-10 3.5S6.33 9.5 3 6"/></svg>
                      </div>
                      <div>
                        <h4 className="font-medium">Celebrity Fragrances</h4>
                        <p className="text-sm text-gray-500">Declining interest in celebrity-endorsed perfumes</p>
                      </div>
                    </li>
                  </ul>
                </div>
                <div>
                  <h3 className="text-lg font-medium mb-4">Competitive Analysis</h3>
                  <div className="space-y-4">
                    <div className="p-4 border rounded-lg">
                      <div className="flex justify-between mb-2">
                        <h4 className="font-medium">Luxury Market Share</h4>
                        <span className="text-sm bg-primary/10 px-2 py-0.5 rounded text-primary">42%</span>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Our Brand</span>
                          <span>18%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div className="bg-primary h-2 rounded-full" style={{ width: "18%" }}></div>
                        </div>
                      </div>
                      <div className="space-y-2 mt-2">
                        <div className="flex justify-between text-sm">
                          <span>Competitor A</span>
                          <span>24%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div className="bg-gray-500 h-2 rounded-full" style={{ width: "24%" }}></div>
                        </div>
                      </div>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <div className="flex justify-between mb-2">
                        <h4 className="font-medium">Customer Satisfaction</h4>
                        <span className="text-sm bg-green-100 px-2 py-0.5 rounded text-green-800">High</span>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Our Brand</span>
                          <span>4.7/5</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div className="bg-primary h-2 rounded-full" style={{ width: "94%" }}></div>
                        </div>
                      </div>
                      <div className="space-y-2 mt-2">
                        <div className="flex justify-between text-sm">
                          <span>Industry Average</span>
                          <span>4.2/5</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div className="bg-gray-500 h-2 rounded-full" style={{ width: "84%" }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="content">
          <Card>
            <CardHeader>
              <CardTitle>Content Planning</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center mb-3">
                      <FileText className="h-5 w-5 text-primary mr-2" />
                      <h3 className="font-medium">Blog Posts</h3>
                    </div>
                    <ul className="space-y-2">
                      <li className="text-sm">The Art of Scent Layering</li>
                      <li className="text-sm">Sustainable Perfumery Practices</li>
                      <li className="text-sm">Behind the Scenes: Formula Creation</li>
                      <li className="text-sm">Perfume Notes for Every Season</li>
                    </ul>
                    <Button variant="link" className="mt-2 h-auto p-0">View Editorial Calendar</Button>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center mb-3">
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary mr-2"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="m9 9 6 6"/><path d="m15 9-6 6"/></svg>
                      <h3 className="font-medium">Social Media</h3>
                    </div>
                    <ul className="space-y-2">
                      <li className="text-sm">Customer Testimonials</li>
                      <li className="text-sm">Ingredient Spotlights</li>
                      <li className="text-sm">Fragrance Tips & Tricks</li>
                      <li className="text-sm">New Collection Teasers</li>
                    </ul>
                    <Button variant="link" className="mt-2 h-auto p-0">View Content Calendar</Button>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center mb-3">
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary mr-2"><path d="m22 8-6 4 6 4V8Z"/><rect width="14" height="12" x="2" y="6" rx="2"/><path d="M6 12h4"/><path d="M10 9v6"/></svg>
                      <h3 className="font-medium">Video Content</h3>
                    </div>
                    <ul className="space-y-2">
                      <li className="text-sm">Perfumer Interviews</li>
                      <li className="text-sm">Lab to Bottle Process</li>
                      <li className="text-sm">Scent Stories</li>
                      <li className="text-sm">Virtual Fragrance Tours</li>
                    </ul>
                    <Button variant="link" className="mt-2 h-auto p-0">View Production Schedule</Button>
                  </div>
                </div>
                
                <div className="border rounded-lg overflow-hidden">
                  <div className="bg-primary/5 px-4 py-3 border-b">
                    <h3 className="font-medium">Content Production Timeline</h3>
                  </div>
                  <div className="p-4">
                    <div className="relative">
                      <div className="absolute h-full w-0.5 bg-gray-200 left-2.5 top-0"></div>
                      <ul className="space-y-4">
                        <li className="flex">
                          <div className="h-5 w-5 rounded-full bg-blue-200 flex items-center justify-center text-blue-600 relative z-10 mt-0.5 mr-4">
                            <span className="h-2 w-2 rounded-full bg-blue-600"></span>
                          </div>
                          <div>
                            <h4 className="font-medium">Week 1-2: Content Planning</h4>
                            <p className="text-sm text-gray-500">Theme development, target audience mapping</p>
                          </div>
                        </li>
                        <li className="flex">
                          <div className="h-5 w-5 rounded-full bg-purple-200 flex items-center justify-center text-purple-600 relative z-10 mt-0.5 mr-4">
                            <span className="h-2 w-2 rounded-full bg-purple-600"></span>
                          </div>
                          <div>
                            <h4 className="font-medium">Week 3-4: Content Creation</h4>
                            <p className="text-sm text-gray-500">Copy writing, photography, video production</p>
                          </div>
                        </li>
                        <li className="flex">
                          <div className="h-5 w-5 rounded-full bg-amber-200 flex items-center justify-center text-amber-600 relative z-10 mt-0.5 mr-4">
                            <span className="h-2 w-2 rounded-full bg-amber-600"></span>
                          </div>
                          <div>
                            <h4 className="font-medium">Week 5: Review & Approval</h4>
                            <p className="text-sm text-gray-500">Content review, legal checks, stakeholder approval</p>
                          </div>
                        </li>
                        <li className="flex">
                          <div className="h-5 w-5 rounded-full bg-green-200 flex items-center justify-center text-green-600 relative z-10 mt-0.5 mr-4">
                            <span className="h-2 w-2 rounded-full bg-green-600"></span>
                          </div>
                          <div>
                            <h4 className="font-medium">Week 6-8: Publication & Promotion</h4>
                            <p className="text-sm text-gray-500">Content scheduling, cross-platform promotion</p>
                          </div>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

// Add this import at the top
import { Badge } from "@/components/ui/badge";

export default MarketingPage;
