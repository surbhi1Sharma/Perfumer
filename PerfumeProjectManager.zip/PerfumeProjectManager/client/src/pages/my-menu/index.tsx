import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery } from "@tanstack/react-query";
import { CalendarIcon, FileTextIcon, ClockIcon, UserIcon } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

const MyMenu = () => {
  const { data: userData, isLoading: userLoading } = useQuery({
    queryKey: ['/api/auth/me'],
  });

  const { data: tasksData, isLoading: tasksLoading } = useQuery({
    queryKey: ['/api/tasks', { userId: 1 }],
  });

  const { data: projectsData, isLoading: projectsLoading } = useQuery({
    queryKey: ['/api/projects'],
  });

  if (userLoading || tasksLoading || projectsLoading) {
    return (
      <div className="p-6">
        <Card className="mb-6">
          <CardHeader>
            <Skeleton className="h-8 w-64" />
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Skeleton className="h-32 w-full" />
              <Skeleton className="h-32 w-full" />
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="tasks">
          <TabsList className="mb-4">
            <TabsTrigger value="tasks">My Tasks</TabsTrigger>
            <TabsTrigger value="projects">My Projects</TabsTrigger>
            <TabsTrigger value="formulas">My Formulas</TabsTrigger>
            <TabsTrigger value="resources">My Resources</TabsTrigger>
          </TabsList>
          <TabsContent value="tasks">
            <div className="grid grid-cols-1 gap-4">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-20 w-full" />
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    );
  }

  return (
    <div className="p-6">
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>My Profile</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex items-start space-x-4">
              <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center text-white">
                <UserIcon className="h-8 w-8" />
              </div>
              <div>
                <h3 className="text-xl font-medium">{userData?.fullName || "Sophia Chen"}</h3>
                <p className="text-gray-500">{userData?.role || "Senior Perfumer"}</p>
                <p className="text-gray-500">{userData?.email || "sophia@aromasuite.com"}</p>
                <p className="text-gray-500">{userData?.department || "R&D Department"}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <ClockIcon className="h-5 w-5 text-primary" />
                  <span className="font-medium">Active Time</span>
                </div>
                <p className="text-2xl font-bold">127h</p>
                <p className="text-sm text-gray-500">This month</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <FileTextIcon className="h-5 w-5 text-primary" />
                  <span className="font-medium">Completed</span>
                </div>
                <p className="text-2xl font-bold">24</p>
                <p className="text-sm text-gray-500">Tasks this month</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="tasks">
        <TabsList className="mb-4">
          <TabsTrigger value="tasks">My Tasks</TabsTrigger>
          <TabsTrigger value="projects">My Projects</TabsTrigger>
          <TabsTrigger value="formulas">My Formulas</TabsTrigger>
          <TabsTrigger value="resources">My Resources</TabsTrigger>
        </TabsList>
        
        <TabsContent value="tasks">
          <div className="grid grid-cols-1 gap-4">
            {tasksData?.map((task: any) => (
              <Card key={task.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium">{task.title}</h3>
                      <p className="text-sm text-gray-500">{task.description}</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className={`px-2 py-1 text-xs rounded-full ${
                        task.priority === 'high' ? 'bg-red-100 text-red-800' :
                        task.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-blue-100 text-blue-800'
                      }`}>
                        {task.priority}
                      </div>
                      <div className={`px-2 py-1 text-xs rounded-full ${
                        task.status === 'completed' ? 'bg-green-100 text-green-800' :
                        task.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {task.status}
                      </div>
                    </div>
                  </div>
                  <div className="mt-2 flex items-center text-sm text-gray-500">
                    <CalendarIcon className="h-4 w-4 mr-1" />
                    Due: {task.dueDate ? format(new Date(task.dueDate), "MMM dd, yyyy") : "Not set"}
                  </div>
                </CardContent>
              </Card>
            ))}
            {(!tasksData || tasksData.length === 0) && (
              <Card>
                <CardContent className="p-6 text-center">
                  <p className="text-gray-500">No tasks assigned to you.</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="projects">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {projectsData?.filter((p: any) => p.manager === 1 || (p.team && p.team.includes(1)))
              .map((project: any) => (
                <Card key={project.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <h3 className="font-medium">{project.name}</h3>
                    <p className="text-sm text-gray-500">Client: {project.client}</p>
                    <div className="mt-2 flex justify-between items-center">
                      <div className="flex items-center text-sm text-gray-500">
                        <CalendarIcon className="h-4 w-4 mr-1" />
                        Due: {project.dueDate ? format(new Date(project.dueDate), "MMM dd, yyyy") : "Not set"}
                      </div>
                      <div className={`px-2 py-1 text-xs rounded-full ${
                        project.status === 'active' ? 'bg-green-100 text-green-800' :
                        project.status === 'in review' ? 'bg-yellow-100 text-yellow-800' :
                        project.status === 'completed' ? 'bg-gray-100 text-gray-800' :
                        'bg-blue-100 text-blue-800'
                      }`}>
                        {project.status}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            {(!projectsData || projectsData.filter((p: any) => p.manager === 1 || (p.team && p.team.includes(1))).length === 0) && (
              <Card className="md:col-span-2">
                <CardContent className="p-6 text-center">
                  <p className="text-gray-500">No projects assigned to you.</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="formulas">
          <Card>
            <CardContent className="p-6 text-center">
              <p className="text-gray-500">Your formulas will appear here.</p>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="resources">
          <Card>
            <CardContent className="p-6 text-center">
              <p className="text-gray-500">Your resource requests will appear here.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default MyMenu;
