import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { 
  BeakerIcon, 
  ClipboardList, 
  FileText, 
  Beaker,
  ChevronRight, 
  Clock, 
  Calendar, 
  CheckCircle2, 
  AlertCircle
} from "lucide-react";

const PPDPage = () => {
  const [activeTab, setActiveTab] = useState("overview");

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold mb-2">Product & Process Development</h1>
          <p className="text-gray-500">Manage and track the development of new perfume products</p>
        </div>
        <Button>
          New Development Project
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card className="bg-white">
          <CardContent className="p-6">
            <div className="flex justify-between items-start mb-2">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                <BeakerIcon className="h-6 w-6" />
              </div>
              <span className="text-3xl font-bold">12</span>
            </div>
            <h3 className="font-medium">Active Developments</h3>
            <p className="text-sm text-gray-500">Products in development pipeline</p>
          </CardContent>
        </Card>

        <Card className="bg-white">
          <CardContent className="p-6">
            <div className="flex justify-between items-start mb-2">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                <ClipboardList className="h-6 w-6" />
              </div>
              <span className="text-3xl font-bold">5</span>
            </div>
            <h3 className="font-medium">Pending Approvals</h3>
            <p className="text-sm text-gray-500">Projects awaiting approval</p>
          </CardContent>
        </Card>

        <Card className="bg-white">
          <CardContent className="p-6">
            <div className="flex justify-between items-start mb-2">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                <Beaker className="h-6 w-6" />
              </div>
              <span className="text-3xl font-bold">8</span>
            </div>
            <h3 className="font-medium">Completed Projects</h3>
            <p className="text-sm text-gray-500">Successfully launched products</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="mb-6">
        <TabsList className="mb-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="development-process">Development Process</TabsTrigger>
          <TabsTrigger value="quality-testing">Quality Testing</TabsTrigger>
          <TabsTrigger value="documentation">Documentation</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <Card>
            <CardHeader>
              <CardTitle>Development Projects</CardTitle>
              <CardDescription>Current status of perfume product development pipeline</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center text-purple-600">
                        <BeakerIcon className="h-5 w-5" />
                      </div>
                      <div>
                        <h3 className="font-medium">Floral Dreams Collection</h3>
                        <p className="text-sm text-gray-500">Spring/Summer Eau de Parfum</p>
                      </div>
                    </div>
                    <Badge className="bg-green-100 text-green-800">Testing</Badge>
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span>75%</span>
                    </div>
                    <Progress value={75} className="h-2" />
                  </div>
                  <div className="flex justify-between text-sm text-gray-500">
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      <span>Due: Aug 30, 2023</span>
                    </div>
                    <Button variant="link" size="sm" className="h-auto p-0 flex items-center gap-1">
                      View Details <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
                        <BeakerIcon className="h-5 w-5" />
                      </div>
                      <div>
                        <h3 className="font-medium">Amber Woods</h3>
                        <p className="text-sm text-gray-500">Unisex Eau de Toilette</p>
                      </div>
                    </div>
                    <Badge className="bg-blue-100 text-blue-800">Formulation</Badge>
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span>40%</span>
                    </div>
                    <Progress value={40} className="h-2" />
                  </div>
                  <div className="flex justify-between text-sm text-gray-500">
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      <span>Due: Oct 15, 2023</span>
                    </div>
                    <Button variant="link" size="sm" className="h-auto p-0 flex items-center gap-1">
                      View Details <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="h-10 w-10 rounded-full bg-amber-100 flex items-center justify-center text-amber-600">
                        <BeakerIcon className="h-5 w-5" />
                      </div>
                      <div>
                        <h3 className="font-medium">Citrus & Spice</h3>
                        <p className="text-sm text-gray-500">Men's Cologne</p>
                      </div>
                    </div>
                    <Badge className="bg-yellow-100 text-yellow-800">Concept</Badge>
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span>15%</span>
                    </div>
                    <Progress value={15} className="h-2" />
                  </div>
                  <div className="flex justify-between text-sm text-gray-500">
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      <span>Due: Dec 10, 2023</span>
                    </div>
                    <Button variant="link" size="sm" className="h-auto p-0 flex items-center gap-1">
                      View Details <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="border-t px-6 py-3">
              <Button variant="link" className="ml-auto flex items-center gap-1">
                View All Projects <ChevronRight className="h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="development-process">
          <Card>
            <CardHeader>
              <CardTitle>Development Process</CardTitle>
              <CardDescription>Standard operating procedures for product development</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="relative">
                <div className="absolute h-full w-0.5 bg-gray-200 left-6 top-0"></div>
                <div className="space-y-8">
                  <div className="flex">
                    <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 relative z-10 mr-6">
                      <span className="text-lg font-bold">1</span>
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-medium mb-1">Concept & Brief</h3>
                      <p className="text-gray-600 mb-2">Define product concept, target market, and consumer profile</p>
                      <div className="bg-gray-50 p-3 rounded-lg">
                        <h4 className="font-medium text-sm mb-2">Key Deliverables:</h4>
                        <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                          <li>Product brief document</li>
                          <li>Market positioning analysis</li>
                          <li>Preliminary scent direction</li>
                          <li>Initial budget estimation</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="flex">
                    <div className="h-12 w-12 rounded-full bg-amber-100 flex items-center justify-center text-amber-600 relative z-10 mr-6">
                      <span className="text-lg font-bold">2</span>
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-medium mb-1">Formulation</h3>
                      <p className="text-gray-600 mb-2">Develop the initial formula prototypes and iterations</p>
                      <div className="bg-gray-50 p-3 rounded-lg">
                        <h4 className="font-medium text-sm mb-2">Key Deliverables:</h4>
                        <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                          <li>Initial formula compositions</li>
                          <li>Raw material sourcing plan</li>
                          <li>Prototype samples</li>
                          <li>Stability assessments</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="flex">
                    <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center text-green-600 relative z-10 mr-6">
                      <span className="text-lg font-bold">3</span>
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-medium mb-1">Testing & Refinement</h3>
                      <p className="text-gray-600 mb-2">Comprehensive testing and formula refinement</p>
                      <div className="bg-gray-50 p-3 rounded-lg">
                        <h4 className="font-medium text-sm mb-2">Key Deliverables:</h4>
                        <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                          <li>Physical stability testing</li>
                          <li>Sensory evaluation</li>
                          <li>Focus group feedback</li>
                          <li>Final formula adjustments</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="flex">
                    <div className="h-12 w-12 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 relative z-10 mr-6">
                      <span className="text-lg font-bold">4</span>
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-medium mb-1">Approval & Production</h3>
                      <p className="text-gray-600 mb-2">Final approvals, regulatory compliance, and production setup</p>
                      <div className="bg-gray-50 p-3 rounded-lg">
                        <h4 className="font-medium text-sm mb-2">Key Deliverables:</h4>
                        <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                          <li>Regulatory documentation</li>
                          <li>Production specifications</li>
                          <li>Quality control protocols</li>
                          <li>Finalized packaging design</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="quality-testing">
          <Card>
            <CardHeader>
              <CardTitle>Quality Testing</CardTitle>
              <CardDescription>Current testing protocols and results</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="border rounded-lg overflow-hidden">
                    <div className="bg-gray-50 px-4 py-3 border-b">
                      <h3 className="font-medium">Physical Stability Tests</h3>
                    </div>
                    <div className="p-4 space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <CheckCircle2 className="h-5 w-5 text-green-600 mr-2" />
                          <span>Color Stability</span>
                        </div>
                        <Badge className="bg-green-100 text-green-800">Passed</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <CheckCircle2 className="h-5 w-5 text-green-600 mr-2" />
                          <span>Temperature Cycle</span>
                        </div>
                        <Badge className="bg-green-100 text-green-800">Passed</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <AlertCircle className="h-5 w-5 text-red-600 mr-2" />
                          <span>Light Exposure</span>
                        </div>
                        <Badge className="bg-red-100 text-red-800">Failed</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <CheckCircle2 className="h-5 w-5 text-green-600 mr-2" />
                          <span>Container Compatibility</span>
                        </div>
                        <Badge className="bg-green-100 text-green-800">Passed</Badge>
                      </div>
                      <div className="mt-2 text-sm text-gray-500">
                        <p>Last updated: July 15, 2023</p>
                      </div>
                    </div>
                  </div>

                  <div className="border rounded-lg overflow-hidden">
                    <div className="bg-gray-50 px-4 py-3 border-b">
                      <h3 className="font-medium">Chemical Analysis</h3>
                    </div>
                    <div className="p-4 space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <CheckCircle2 className="h-5 w-5 text-green-600 mr-2" />
                          <span>pH Testing</span>
                        </div>
                        <Badge className="bg-green-100 text-green-800">Compliant</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <CheckCircle2 className="h-5 w-5 text-green-600 mr-2" />
                          <span>Allergen Analysis</span>
                        </div>
                        <Badge className="bg-green-100 text-green-800">Compliant</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Clock className="h-5 w-5 text-amber-600 mr-2" />
                          <span>Evaporation Rate</span>
                        </div>
                        <Badge className="bg-amber-100 text-amber-800">In Progress</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <CheckCircle2 className="h-5 w-5 text-green-600 mr-2" />
                          <span>Concentration Testing</span>
                        </div>
                        <Badge className="bg-green-100 text-green-800">Compliant</Badge>
                      </div>
                      <div className="mt-2 text-sm text-gray-500">
                        <p>Last updated: July 18, 2023</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="border rounded-lg overflow-hidden">
                  <div className="bg-gray-50 px-4 py-3 border-b">
                    <h3 className="font-medium">Sensory Evaluation</h3>
                  </div>
                  <div className="p-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="text-sm font-medium mb-3">Floral Dreams EDP - Test Results</h4>
                        <div className="space-y-3">
                          <div className="space-y-1">
                            <div className="flex justify-between text-sm">
                              <span>Longevity</span>
                              <span>8.5/10</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div className="bg-primary h-2 rounded-full" style={{ width: "85%" }}></div>
                            </div>
                          </div>
                          <div className="space-y-1">
                            <div className="flex justify-between text-sm">
                              <span>Sillage</span>
                              <span>7.8/10</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div className="bg-primary h-2 rounded-full" style={{ width: "78%" }}></div>
                            </div>
                          </div>
                          <div className="space-y-1">
                            <div className="flex justify-between text-sm">
                              <span>Top Note Impression</span>
                              <span>9.2/10</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div className="bg-primary h-2 rounded-full" style={{ width: "92%" }}></div>
                            </div>
                          </div>
                          <div className="space-y-1">
                            <div className="flex justify-between text-sm">
                              <span>Base Note Development</span>
                              <span>8.0/10</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div className="bg-primary h-2 rounded-full" style={{ width: "80%" }}></div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="space-y-4">
                        <div>
                          <h4 className="text-sm font-medium mb-1">Panel Feedback</h4>
                          <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
                            <p>"Excellent floral representation with good longevity. Middle notes could benefit from stronger development. Base notes provide adequate anchoring but could be more distinctive."</p>
                          </div>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium mb-1">Recommended Actions</h4>
                          <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                            <li>Strengthen middle note development</li>
                            <li>Adjust base note composition for more distinctiveness</li>
                            <li>Conduct further light exposure stability tests</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="documentation">
          <Card>
            <CardHeader>
              <CardTitle>Documentation</CardTitle>
              <CardDescription>Product development documentation and requirements</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="border p-4 rounded-lg hover:bg-gray-50 cursor-pointer">
                    <div className="flex items-center mb-3">
                      <FileText className="h-6 w-6 text-primary mr-2" />
                      <h3 className="font-medium">Standard Operating Procedures</h3>
                    </div>
                    <p className="text-sm text-gray-500 mb-2">Guidelines for product development processes</p>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-500">PDF • 2.3 MB</span>
                      <Button variant="ghost" size="sm" className="h-8">
                        View
                      </Button>
                    </div>
                  </div>

                  <div className="border p-4 rounded-lg hover:bg-gray-50 cursor-pointer">
                    <div className="flex items-center mb-3">
                      <FileText className="h-6 w-6 text-primary mr-2" />
                      <h3 className="font-medium">Regulatory Compliance</h3>
                    </div>
                    <p className="text-sm text-gray-500 mb-2">Documentation for regulatory requirements</p>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-500">PDF • 4.7 MB</span>
                      <Button variant="ghost" size="sm" className="h-8">
                        View
                      </Button>
                    </div>
                  </div>

                  <div className="border p-4 rounded-lg hover:bg-gray-50 cursor-pointer">
                    <div className="flex items-center mb-3">
                      <FileText className="h-6 w-6 text-primary mr-2" />
                      <h3 className="font-medium">Quality Assurance Templates</h3>
                    </div>
                    <p className="text-sm text-gray-500 mb-2">Standard forms for quality testing</p>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-500">ZIP • 1.8 MB</span>
                      <Button variant="ghost" size="sm" className="h-8">
                        Download
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="border rounded-lg overflow-hidden">
                  <div className="bg-gray-50 px-4 py-3 border-b">
                    <h3 className="font-medium">Required Documentation</h3>
                  </div>
                  <div className="p-4">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead>
                        <tr>
                          <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Document</th>
                          <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Required For</th>
                          <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Template</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        <tr>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900">Product Brief</div>
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                            Concept Phase
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap text-sm">
                            <Button variant="link" size="sm" className="h-auto p-0">
                              Download Template
                            </Button>
                          </td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900">Formula Specification</div>
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                            Formulation Phase
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap text-sm">
                            <Button variant="link" size="sm" className="h-auto p-0">
                              Download Template
                            </Button>
                          </td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900">Stability Test Report</div>
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                            Testing Phase
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap text-sm">
                            <Button variant="link" size="sm" className="h-auto p-0">
                              Download Template
                            </Button>
                          </td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900">Sensory Evaluation</div>
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                            Testing Phase
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap text-sm">
                            <Button variant="link" size="sm" className="h-auto p-0">
                              Download Template
                            </Button>
                          </td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900">Raw Materials List</div>
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                            Formulation Phase
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap text-sm">
                            <Button variant="link" size="sm" className="h-auto p-0">
                              Download Template
                            </Button>
                          </td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900">Production Specifications</div>
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                            Approval Phase
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap text-sm">
                            <Button variant="link" size="sm" className="h-auto p-0">
                              Download Template
                            </Button>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default PPDPage;
