import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { createFormula } from "@/lib/api";
import { File, Upload, AlertCircle, CheckCircle, Building } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const AcquisitionImport = () => {
  const [file, setFile] = useState<File | null>(null);
  const [formulas, setFormulas] = useState<any[]>([]);
  const [acquisitionName, setAcquisitionName] = useState("");
  const [acquisitionDate, setAcquisitionDate] = useState("");
  const [notes, setNotes] = useState("");
  const [importing, setImporting] = useState(false);
  const [importComplete, setImportComplete] = useState(false);
  const { toast } = useToast();

  const importMutation = useMutation({
    mutationFn: createFormula,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/formulas'] });
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      // In a real app, you would properly parse the file
      // Here we're just simulating some sample data
      setFormulas([
        {
          name: "Mountain Pine",
          type: "Candle Fragrance",
          category: "Woody",
          status: "pending",
          composition: { notes: ["Pine", "Cedar", "Moss"] },
          description: "Fresh pine scent for home fragrance"
        },
        {
          name: "Ocean Breeze",
          type: "Room Spray",
          category: "Fresh",
          status: "pending",
          composition: { notes: ["Marine", "Citrus", "Ozone"] },
          description: "Fresh oceanic fragrance for room sprays"
        },
        {
          name: "Vanilla Spice",
          type: "Potpourri",
          category: "Gourmand",
          status: "pending",
          composition: { notes: ["Vanilla", "Cinnamon", "Clove"] },
          description: "Warm vanilla and spice blend for potpourri"
        }
      ]);
    }
  };

  const handleImport = async () => {
    if (!acquisitionName) {
      toast({
        title: "Acquisition name required",
        description: "Please enter the acquisition name before importing.",
        variant: "destructive",
      });
      return;
    }
    
    setImporting(true);
    try {
      // Prepare formulas with acquisition data and user ID
      const preparedFormulas = formulas.map(formula => ({
        ...formula,
        createdBy: 1, // Default user ID for now
        notes: `Acquisition: ${acquisitionName}${acquisitionDate ? ` (${acquisitionDate})` : ''}${notes ? `\n\nNotes: ${notes}` : ''}`
      }));
      
      // In a real app, you would process each formula
      for (const formula of preparedFormulas) {
        await importMutation.mutateAsync(formula);
      }
      
      setImportComplete(true);
      toast({
        title: "Import successful",
        description: `Imported ${formulas.length} formulas from ${acquisitionName} successfully.`,
      });
    } catch (error) {
      toast({
        title: "Import failed",
        description: "There was an error importing the formulas.",
        variant: "destructive",
      });
    } finally {
      setImporting(false);
    }
  };

  const resetImport = () => {
    setFile(null);
    setFormulas([]);
    setAcquisitionName("");
    setAcquisitionDate("");
    setNotes("");
    setImportComplete(false);
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-2">Acquisition Import</h1>
        <p className="text-gray-500">Import formulas from acquired companies</p>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Import Acquisition Formulas</CardTitle>
          <CardDescription>
            Upload and import formulas from acquired companies or brands
          </CardDescription>
        </CardHeader>
        <CardContent>
          {importComplete ? (
            <Alert className="bg-green-50 border-green-100">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertTitle>Import completed successfully</AlertTitle>
              <AlertDescription>
                All formulas have been imported into the system.
              </AlertDescription>
            </Alert>
          ) : (
            <div className="space-y-6">
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="acquisition">Acquisition Name</Label>
                    <div className="flex items-center mt-1.5">
                      <div className="mr-2">
                        <Building className="h-4 w-4 text-gray-400" />
                      </div>
                      <Input
                        id="acquisition"
                        value={acquisitionName}
                        onChange={(e) => setAcquisitionName(e.target.value)}
                        placeholder="Enter acquired company name"
                        className="flex-1"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="date">Acquisition Date</Label>
                    <Input
                      id="date"
                      type="date"
                      value={acquisitionDate}
                      onChange={(e) => setAcquisitionDate(e.target.value)}
                      className="mt-1.5"
                    />
                  </div>
                </div>
                
                <div className="border-2 border-dashed border-gray-200 rounded-lg p-6 text-center">
                  <div className="mb-4">
                    <div className="mx-auto w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <File className="h-6 w-6 text-primary" />
                    </div>
                  </div>
                  <h3 className="text-lg font-medium mb-2">Upload Formula Database</h3>
                  <p className="text-sm text-gray-500 mb-4">
                    Drag and drop your file here, or click to browse
                  </p>
                  <Input
                    type="file"
                    accept=".csv, .xlsx, .xls, .json, .xml"
                    id="file-upload"
                    className="hidden"
                    onChange={handleFileChange}
                  />
                  <Button asChild>
                    <label htmlFor="file-upload" className="cursor-pointer">Browse Files</label>
                  </Button>
                </div>

                {file && (
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex items-center">
                      <File className="h-5 w-5 text-gray-400 mr-2" />
                      <span className="font-medium">{file.name}</span>
                      <span className="ml-2 text-sm text-gray-500">
                        ({(file.size / 1024).toFixed(2)} KB)
                      </span>
                    </div>
                  </div>
                )}

                {formulas.length > 0 && (
                  <div>
                    <h3 className="font-medium mb-2">Preview Import Data</h3>
                    <div className="border rounded-lg overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Name</TableHead>
                            <TableHead>Type</TableHead>
                            <TableHead>Category</TableHead>
                            <TableHead>Description</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {formulas.map((formula, index) => (
                            <TableRow key={index}>
                              <TableCell className="font-medium">{formula.name}</TableCell>
                              <TableCell>{formula.type}</TableCell>
                              <TableCell>{formula.category}</TableCell>
                              <TableCell>{formula.description}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                )}

                <div>
                  <Label htmlFor="notes">Additional Notes</Label>
                  <Textarea
                    id="notes"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Enter any additional notes about this acquisition..."
                    className="min-h-[100px]"
                  />
                </div>
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          {importComplete ? (
            <div className="flex w-full justify-center">
              <Button onClick={resetImport}>Import Another File</Button>
            </div>
          ) : (
            <div className="flex w-full justify-end gap-2">
              <Button
                variant="outline"
                onClick={resetImport}
                disabled={!file || importing}
              >
                Reset
              </Button>
              <Button
                onClick={handleImport}
                disabled={!formulas.length || !acquisitionName || importing}
                className="flex items-center gap-2"
              >
                {importing ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-current border-t-transparent rounded-full" />
                    Importing...
                  </>
                ) : (
                  <>
                    <Upload className="h-4 w-4" />
                    Import Formulas
                  </>
                )}
              </Button>
            </div>
          )}
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Import Guidelines</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h3 className="font-medium mb-1">Supported File Formats</h3>
              <p className="text-sm text-gray-500">
                We support the following file formats for formula imports:
              </p>
              <ul className="list-disc list-inside text-sm text-gray-500 mt-2 ml-4">
                <li>Excel spreadsheets (.xlsx, .xls)</li>
                <li>CSV files (.csv)</li>
                <li>JSON data files (.json)</li>
                <li>XML data files (.xml)</li>
              </ul>
            </div>

            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Data Compliance</AlertTitle>
              <AlertDescription>
                Ensure all imported formulas comply with regulations. All imported formulas will be marked as "pending" until they are reviewed and approved.
              </AlertDescription>
            </Alert>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AcquisitionImport;
