import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { createBaseRequest } from "@/lib/api";
import { useLocation } from "wouter";
import { CheckCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const baseRequestSchema = z.object({
  userId: z.number().default(1), // Default to current user (in a real app, this would come from auth)
  name: z.string().min(3, "Base name must be at least 3 characters").max(100, "Base name cannot exceed 100 characters"),
  purpose: z.string().min(10, "Purpose must be at least 10 characters").max(500, "Purpose cannot exceed 500 characters"),
  description: z.string().min(20, "Description must be at least 20 characters").max(1000, "Description cannot exceed 1000 characters"),
  urgency: z.string({
    required_error: "Please select urgency level",
  }),
});

type BaseRequestFormValues = z.infer<typeof baseRequestSchema>;

const RequestBases = () => {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [submitted, setSubmitted] = useState(false);

  const form = useForm<BaseRequestFormValues>({
    resolver: zodResolver(baseRequestSchema),
    defaultValues: {
      userId: 1,
      name: "",
      purpose: "",
      description: "",
      urgency: "medium",
    },
  });

  const createRequestMutation = useMutation({
    mutationFn: createBaseRequest,
    onSuccess: () => {
      toast({
        title: "Request submitted",
        description: "Your base request has been submitted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/base-requests'] });
      setSubmitted(true);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to submit request. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: BaseRequestFormValues) => {
    createRequestMutation.mutate(data);
  };

  const resetForm = () => {
    form.reset();
    setSubmitted(false);
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-2">Raise Request for Bases</h1>
        <p className="text-gray-500">Submit a request for new fragrance bases needed for your formulas</p>
      </div>

      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Base Request Form</CardTitle>
          <CardDescription>
            Provide details about the base you need to create
          </CardDescription>
        </CardHeader>
        <CardContent>
          {submitted ? (
            <div className="py-6">
              <Alert className="bg-green-50 border-green-100">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertTitle>Request Submitted Successfully</AlertTitle>
                <AlertDescription>
                  Your request for a new base has been submitted and will be reviewed by the team.
                </AlertDescription>
              </Alert>
              <div className="mt-6 flex justify-center">
                <Button onClick={resetForm}>Submit Another Request</Button>
              </div>
            </div>
          ) : (
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Base Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Floral Spring Base #42" {...field} />
                      </FormControl>
                      <FormDescription>
                        Provide a clear name for the base you're requesting
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="purpose"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Purpose</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Explain the purpose of this base..."
                          className="min-h-[80px]"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>
                        Describe why this base is needed and how it will be used
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Provide detailed specifications for the base..."
                          className="min-h-[150px]"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>
                        Include scent profile, suggested ingredients, target products, etc.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="urgency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Urgency</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select urgency level" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="low">Low - Within 4 weeks</SelectItem>
                          <SelectItem value="medium">Medium - Within 2 weeks</SelectItem>
                          <SelectItem value="high">High - Within 1 week</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        Select the urgency level for this request
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end space-x-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => navigate("/formulas")}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={createRequestMutation.isPending}
                  >
                    {createRequestMutation.isPending ? "Submitting..." : "Submit Request"}
                  </Button>
                </div>
              </form>
            </Form>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

// Add this import at the top
import { useState } from "react";

export default RequestBases;
