import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { createFormula } from "@/lib/api";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Check, Plus, Trash2, Save } from "lucide-react";

const compositionItemSchema = z.object({
  resourceId: z.number().optional(),
  name: z.string().min(1, "Ingredient name is required"),
  percentage: z.number().min(0.01, "Must be greater than 0").max(100, "Cannot exceed 100%"),
  notes: z.string().optional(),
});

const potpourriFormulaSchema = z.object({
  name: z.string().min(3, "Name must be at least 3 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  category: z.string().min(1, "Category is required"),
  composition: z.array(compositionItemSchema).min(1, "At least one ingredient is required"),
  notes: z.string().optional(),
});

type PotpourriFormulaValues = z.infer<typeof potpourriFormulaSchema>;
type CompositionItem = z.infer<typeof compositionItemSchema>;

const PotpourriCreation = () => {
  const [ingredientName, setIngredientName] = useState("");
  const [ingredientPercentage, setIngredientPercentage] = useState(0);
  const [ingredientNotes, setIngredientNotes] = useState("");
  const { toast } = useToast();

  const form = useForm<PotpourriFormulaValues>({
    resolver: zodResolver(potpourriFormulaSchema),
    defaultValues: {
      name: "",
      description: "",
      category: "Potpourri",
      composition: [],
      notes: "",
    }
  });

  const { data: resources } = useQuery({
    queryKey: ['/api/resources'],
  });

  const createFormulaMutation = useMutation({
    mutationFn: (data: any) => {
      return createFormula({
        ...data,
        type: "Potpourri",
        status: "pending",
        createdBy: 1, // Default user ID
        composition: {
          ingredients: data.composition
        }
      });
    },
    onSuccess: () => {
      toast({
        title: "Formula created",
        description: "Potpourri formula has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/formulas'] });
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create formula. Please try again.",
        variant: "destructive",
      });
    },
  });

  const addIngredient = () => {
    if (!ingredientName || ingredientPercentage <= 0) return;
    
    const ingredient: CompositionItem = {
      name: ingredientName,
      percentage: ingredientPercentage,
      notes: ingredientNotes,
    };
    
    const currentComposition = form.getValues("composition");
    form.setValue("composition", [...currentComposition, ingredient]);
    
    // Reset ingredient inputs
    setIngredientName("");
    setIngredientPercentage(0);
    setIngredientNotes("");
  };

  const removeIngredient = (index: number) => {
    const currentComposition = form.getValues("composition");
    const newComposition = [...currentComposition];
    newComposition.splice(index, 1);
    form.setValue("composition", newComposition);
  };

  const getTotalPercentage = () => {
    const composition = form.getValues("composition");
    return composition.reduce((total, item) => total + item.percentage, 0);
  };

  const onSubmit = (data: PotpourriFormulaValues) => {
    createFormulaMutation.mutate(data);
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-2">Potpourri Formula Creation</h1>
        <p className="text-gray-500">Create a new potpourri blend formula</p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <Tabs defaultValue="basic" className="mb-6">
            <TabsList className="mb-4">
              <TabsTrigger value="basic">Basic Information</TabsTrigger>
              <TabsTrigger value="composition">Composition</TabsTrigger>
              <TabsTrigger value="notes">Additional Notes</TabsTrigger>
            </TabsList>
            
            <TabsContent value="basic">
              <Card>
                <CardHeader>
                  <CardTitle>Formula Details</CardTitle>
                  <CardDescription>Enter the basic information for your potpourri formula</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Formula Name</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. Autumn Harvest Blend" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Describe your potpourri formula..." 
                            className="min-h-[100px]"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="category"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Category</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. Seasonal, Floral, Herbal" {...field} />
                        </FormControl>
                        <FormDescription>
                          Specify the category of this potpourri formula
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
                <CardFooter>
                  <Button type="button" onClick={() => document.querySelector('[data-value="composition"]')?.click()}>
                    Continue to Composition
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            <TabsContent value="composition">
              <Card>
                <CardHeader>
                  <CardTitle>Formula Composition</CardTitle>
                  <CardDescription>Add the ingredients for your potpourri blend</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="ingredient-name">Ingredient Name</Label>
                        <Input
                          id="ingredient-name"
                          value={ingredientName}
                          onChange={(e) => setIngredientName(e.target.value)}
                          placeholder="e.g. Dried Lavender"
                        />
                      </div>
                      <div>
                        <Label htmlFor="ingredient-percentage">Percentage (%)</Label>
                        <Input
                          id="ingredient-percentage"
                          type="number"
                          min="0.01"
                          max="100"
                          step="0.01"
                          value={ingredientPercentage || ""}
                          onChange={(e) => setIngredientPercentage(parseFloat(e.target.value))}
                          placeholder="e.g. 25"
                        />
                      </div>
                      <div className="flex items-end">
                        <Button 
                          type="button" 
                          onClick={addIngredient}
                          className="flex items-center gap-2 mb-[2px]"
                        >
                          <Plus className="h-4 w-4" />
                          Add Ingredient
                        </Button>
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="ingredient-notes">Ingredient Notes (Optional)</Label>
                      <Textarea
                        id="ingredient-notes"
                        value={ingredientNotes}
                        onChange={(e) => setIngredientNotes(e.target.value)}
                        placeholder="Any special notes about this ingredient..."
                      />
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium mb-2">Current Composition</h3>
                    {form.getValues("composition").length === 0 ? (
                      <div className="text-center p-6 border rounded-lg bg-gray-50">
                        <p className="text-gray-500">No ingredients added yet</p>
                      </div>
                    ) : (
                      <div className="border rounded-lg overflow-hidden">
                        <table className="min-w-full divide-y divide-gray-200">
                          <thead className="bg-gray-50">
                            <tr>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ingredient</th>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Percentage</th>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Notes</th>
                              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                            {form.getValues("composition").map((ingredient, index) => (
                              <tr key={index}>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                  {ingredient.name}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                  {ingredient.percentage}%
                                </td>
                                <td className="px-6 py-4 text-sm text-gray-500">
                                  {ingredient.notes || "-"}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                  <Button
                                    type="button"
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => removeIngredient(index)}
                                    className="text-red-600 hover:text-red-900"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                    <div className="mt-2 flex justify-between text-sm">
                      <span>Total Percentage: {getTotalPercentage()}%</span>
                      {getTotalPercentage() !== 100 && (
                        <span className="text-amber-600">
                          {getTotalPercentage() < 100 
                            ? `Missing ${(100 - getTotalPercentage()).toFixed(2)}%` 
                            : `Exceeds 100% by ${(getTotalPercentage() - 100).toFixed(2)}%`}
                        </span>
                      )}
                    </div>
                    {form.formState.errors.composition && (
                      <p className="mt-2 text-sm text-red-600">{form.formState.errors.composition.message}</p>
                    )}
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button type="button" variant="outline" onClick={() => document.querySelector('[data-value="basic"]')?.click()}>
                    Back
                  </Button>
                  <Button type="button" onClick={() => document.querySelector('[data-value="notes"]')?.click()}>
                    Continue
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            <TabsContent value="notes">
              <Card>
                <CardHeader>
                  <CardTitle>Additional Notes</CardTitle>
                  <CardDescription>Add any additional information about your potpourri formula</CardDescription>
                </CardHeader>
                <CardContent>
                  <FormField
                    control={form.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Notes</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Enter any additional notes, usage recommendations, or special instructions..."
                            className="min-h-[200px]"
                            {...field}
                          />
                        </FormControl>
                        <FormDescription>
                          Add any observations, processing methods, or seasonal recommendations
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button type="button" variant="outline" onClick={() => document.querySelector('[data-value="composition"]')?.click()}>
                    Back
                  </Button>
                  <Button
                    type="submit"
                    disabled={createFormulaMutation.isPending || getTotalPercentage() !== 100}
                    className="flex items-center gap-2"
                  >
                    {createFormulaMutation.isPending ? (
                      <>
                        <div className="animate-spin w-4 h-4 border-2 border-current border-t-transparent rounded-full" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="h-4 w-4" />
                        Save Formula
                      </>
                    )}
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </form>
      </Form>
    </div>
  );
};

export default PotpourriCreation;
