import React, { useState, useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { Ingredient } from '@/lib/types';
import {
  getAllIngredients,
  getIngredientsByCategory,
  getIngredientsByPyramid
} from '@/lib/api';
import Layout from '@/components/layout/Layout';
import { 
  ArrowLeft, 
  DownloadIcon, 
  PlusIcon, 
  MinusIcon, 
  ZoomInIcon,
  ZoomOutIcon,
  MoveHorizontalIcon,
  RotateCcwIcon 
} from 'lucide-react';
import { Link } from 'wouter';

type FlavorProfile = {
  [key: string]: number;
};

type RadarChartData = {
  axis: string;
  value: number;
  group: string;
}[];

interface VisualizationIngredient extends Ingredient {
  percentage: number;
  color: string;
}

const SAMPLE_ODOR_PROFILES = [
  'Sweet', 'Woody', 'Spicy', 'Floral', 'Fruity', 
  'Citrus', 'Green', 'Herbal', 'Oriental', 'Amber',
  'Gourmand', 'Musk', 'Leather', 'Powdery', 'Aquatic'
];

const COLORS = [
  '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF',
  '#FF9F40', '#8AC926', '#1982C4', '#6A4C93', '#F94144',
  '#F3722C', '#F8961E', '#F9C74F', '#90BE6D', '#43AA8B'
];

// Generate a color based on category
const getCategoryColor = (category: string, index: number): string => {
  // If category maps directly to a predefined color, use it
  const categoryLower = category.toLowerCase();
  if (categoryLower.includes('floral')) return '#FF6384';
  if (categoryLower.includes('wood') || categoryLower.includes('woody')) return '#8B4513';
  if (categoryLower.includes('spice') || categoryLower.includes('spicy')) return '#FF9F40';
  if (categoryLower.includes('fruit')) return '#FFCE56';
  if (categoryLower.includes('citrus')) return '#F9C74F';
  if (categoryLower.includes('green')) return '#90BE6D';
  if (categoryLower.includes('herbal')) return '#43AA8B';
  if (categoryLower.includes('oriental')) return '#9966FF';
  if (categoryLower.includes('amber')) return '#F8961E';
  if (categoryLower.includes('gourmand')) return '#6A4C93';
  if (categoryLower.includes('musk')) return '#1982C4';
  
  // Fallback to the color array using the index
  return COLORS[index % COLORS.length];
};

const FlavorVisualizationPage: React.FC = () => {
  const [selectedIngredients, setSelectedIngredients] = useState<VisualizationIngredient[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [activePyramid, setActivePyramid] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [visualizationType, setVisualizationType] = useState<string>('wheel');
  const [selectedForComparison, setSelectedForComparison] = useState<number | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [scale, setScale] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const { toast } = useToast();

  // Fetch all ingredients
  const { data: allIngredients, isLoading, error } = useQuery({
    queryKey: ['ingredients'],
    queryFn: getAllIngredients
  });

  // Fetch ingredients by category when activeCategory changes
  const { data: categoryIngredients } = useQuery({
    queryKey: ['ingredients', 'category', activeCategory],
    queryFn: () => activeCategory === 'all' ? getAllIngredients() : getIngredientsByCategory(activeCategory),
    enabled: !!activeCategory && activeCategory !== 'all'
  });

  // Fetch ingredients by pyramid when activePyramid changes
  const { data: pyramidIngredients } = useQuery({
    queryKey: ['ingredients', 'pyramid', activePyramid],
    queryFn: () => activePyramid === 'all' ? getAllIngredients() : getIngredientsByPyramid(activePyramid),
    enabled: !!activePyramid && activePyramid !== 'all'
  });

  const displayedIngredients = React.useMemo(() => {
    let ingredients = allIngredients || [];

    if (activeCategory !== 'all' && categoryIngredients) {
      ingredients = categoryIngredients;
    }

    if (activePyramid !== 'all' && pyramidIngredients) {
      ingredients = pyramidIngredients;
    }

    if (searchQuery) {
      ingredients = ingredients.filter(ing => 
        ing.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (ing.casNumber && ing.casNumber.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    return ingredients;
  }, [allIngredients, categoryIngredients, pyramidIngredients, activeCategory, activePyramid, searchQuery]);

  // Extract unique categories from ingredients
  const categories = React.useMemo(() => {
    if (!allIngredients) return [];
    const uniqueCategories = new Set(allIngredients.map(ing => ing.category));
    return ['all', ...Array.from(uniqueCategories)];
  }, [allIngredients]);

  // Extract unique pyramid positions from ingredients
  const pyramidPositions = React.useMemo(() => {
    if (!allIngredients) return [];
    const uniquePyramids = new Set(
      allIngredients
        .map(ing => ing.pyramid)
        .filter(pyramid => pyramid) as string[]
    );
    return ['all', ...Array.from(uniquePyramids)];
  }, [allIngredients]);

  // Calculate combined flavor profile
  const combinedFlavorProfile = React.useMemo(() => {
    if (selectedIngredients.length === 0) return {};

    const profile: FlavorProfile = {};
    let totalPercentage = 0;

    selectedIngredients.forEach(ing => {
      totalPercentage += ing.percentage;
      
      // If ingredient has odorProfile as array of strings
      if (Array.isArray(ing.odorProfile)) {
        ing.odorProfile.forEach(odor => {
          if (!profile[odor]) profile[odor] = 0;
          profile[odor] += ing.percentage;
        });
      } 
      // If ingredient has odorProfile as an object with scores
      else if (typeof ing.odorProfile === 'object') {
        Object.entries(ing.odorProfile).forEach(([odor, score]) => {
          if (!profile[odor]) profile[odor] = 0;
          
          // If score is a number, use it directly
          if (typeof score === 'number') {
            profile[odor] += score * (ing.percentage / 100);
          } 
          // If score is a string that can be converted to a number
          else if (typeof score === 'string' && !isNaN(Number(score))) {
            profile[odor] += Number(score) * (ing.percentage / 100);
          }
          // Just add the percentage if we can't determine a score
          else {
            profile[odor] += ing.percentage;
          }
        });
      }
    });

    // Normalize values if total percentage is not 100
    if (totalPercentage > 0 && totalPercentage !== 100) {
      Object.keys(profile).forEach(key => {
        profile[key] = (profile[key] / totalPercentage) * 100;
      });
    }

    return profile;
  }, [selectedIngredients]);

  // Prepare data for radar chart
  const radarData = React.useMemo(() => {
    if (Object.keys(combinedFlavorProfile).length === 0) {
      // Return default data if no ingredients selected
      return SAMPLE_ODOR_PROFILES.map(odor => ({
        axis: odor,
        value: 0,
        group: 'formula'
      }));
    }

    return Object.entries(combinedFlavorProfile).map(([odor, value]) => ({
      axis: odor,
      value: value > 100 ? 100 : value, // Cap at 100
      group: 'formula'
    }));
  }, [combinedFlavorProfile]);

  // Draw the wheel chart when data changes
  useEffect(() => {
    if (!canvasRef.current || Object.keys(combinedFlavorProfile).length === 0) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    
    // Apply scaling and translation
    ctx.translate(offset.x + canvas.width / 2, offset.y + canvas.height / 2);
    ctx.scale(scale, scale);

    const centerX = 0; 
    const centerY = 0;
    const maxRadius = Math.min(canvas.width, canvas.height) / 2 - 50;

    // Draw the flavor wheel
    drawFlavorWheel(ctx, combinedFlavorProfile, centerX, centerY, maxRadius);
    
    ctx.restore();
  }, [combinedFlavorProfile, scale, offset]);

  // Draw the flavor wheel
  const drawFlavorWheel = (
    ctx: CanvasRenderingContext2D, 
    profile: FlavorProfile, 
    centerX: number, 
    centerY: number, 
    maxRadius: number
  ) => {
    const numOdors = Object.keys(profile).length;
    if (numOdors === 0) return;

    const sliceAngle = (2 * Math.PI) / numOdors;
    const innerRadius = maxRadius * 0.3; // Inner circle radius

    Object.entries(profile).forEach(([odor, value], index) => {
      const startAngle = index * sliceAngle;
      const endAngle = (index + 1) * sliceAngle;
      const normalizedValue = Math.max(10, Math.min(value, 100)); // Ensure value is between 10-100
      const outerRadius = innerRadius + (maxRadius - innerRadius) * (normalizedValue / 100);
      
      // Get color based on odor category
      const color = getCategoryColor(odor, index);
      
      // Draw slice
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, outerRadius, startAngle, endAngle);
      ctx.closePath();
      
      // Fill with gradient
      const gradient = ctx.createRadialGradient(
        centerX, centerY, innerRadius,
        centerX, centerY, outerRadius
      );
      gradient.addColorStop(0, `${color}80`); // Semi-transparent at inner radius
      gradient.addColorStop(1, color);
      ctx.fillStyle = gradient;
      ctx.fill();
      
      // Draw outline
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1;
      ctx.stroke();
      
      // Add label
      const midAngle = (startAngle + endAngle) / 2;
      const labelRadius = outerRadius + 20;
      const labelX = centerX + Math.cos(midAngle) * labelRadius;
      const labelY = centerY + Math.sin(midAngle) * labelRadius;
      
      ctx.save();
      ctx.translate(labelX, labelY);
      ctx.rotate(midAngle + Math.PI / 2);
      
      ctx.fillStyle = '#000000';
      ctx.font = '12px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(`${odor} (${normalizedValue.toFixed(1)}%)`, 0, 0);
      
      ctx.restore();
    });

    // Draw center circle
    ctx.beginPath();
    ctx.arc(centerX, centerY, innerRadius, 0, 2 * Math.PI);
    ctx.fillStyle = '#f0f0f0';
    ctx.fill();
    ctx.strokeStyle = '#cccccc';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Draw formula name in center
    ctx.fillStyle = '#333333';
    ctx.font = 'bold 16px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Flavor Profile', centerX, centerY - 10);
    ctx.font = '14px Arial';
    ctx.fillText(`${selectedIngredients.length} ingredients`, centerX, centerY + 10);
  };

  // Draw the radar chart
  const drawRadarChart = () => {
    if (!canvasRef.current || radarData.length === 0) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const maxRadius = Math.min(canvas.width, canvas.height) / 2 - 50;
    
    const numAxes = radarData.length;
    const angleStep = (2 * Math.PI) / numAxes;
    
    // Draw axes
    for (let i = 0; i < numAxes; i++) {
      const angle = i * angleStep - Math.PI / 2; // Start from top
      const axisEndX = centerX + Math.cos(angle) * maxRadius;
      const axisEndY = centerY + Math.sin(angle) * maxRadius;
      
      // Draw axis line
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.lineTo(axisEndX, axisEndY);
      ctx.strokeStyle = '#cccccc';
      ctx.lineWidth = 1;
      ctx.stroke();
      
      // Draw label
      const labelX = centerX + Math.cos(angle) * (maxRadius + 20);
      const labelY = centerY + Math.sin(angle) * (maxRadius + 20);
      
      ctx.fillStyle = '#333333';
      ctx.font = '12px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(radarData[i].axis, labelX, labelY);
      
      // Draw concentric circles
      for (let j = 1; j <= 4; j++) {
        const radius = (maxRadius * j) / 4;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
        ctx.strokeStyle = '#e0e0e0';
        ctx.lineWidth = 1;
        ctx.stroke();
      }
    }
    
    // Draw data points and connect them
    ctx.beginPath();
    for (let i = 0; i < numAxes; i++) {
      const angle = i * angleStep - Math.PI / 2;
      const value = radarData[i].value / 100; // Normalize to 0-1
      const pointX = centerX + Math.cos(angle) * (maxRadius * value);
      const pointY = centerY + Math.sin(angle) * (maxRadius * value);
      
      if (i === 0) {
        ctx.moveTo(pointX, pointY);
      } else {
        ctx.lineTo(pointX, pointY);
      }
    }
    
    // Close the path
    ctx.closePath();
    
    // Fill with semi-transparent color
    ctx.fillStyle = 'rgba(255, 99, 132, 0.2)';
    ctx.fill();
    
    // Draw outline
    ctx.strokeStyle = 'rgb(255, 99, 132)';
    ctx.lineWidth = 2;
    ctx.stroke();
    
    // Draw data points
    for (let i = 0; i < numAxes; i++) {
      const angle = i * angleStep - Math.PI / 2;
      const value = radarData[i].value / 100;
      const pointX = centerX + Math.cos(angle) * (maxRadius * value);
      const pointY = centerY + Math.sin(angle) * (maxRadius * value);
      
      ctx.beginPath();
      ctx.arc(pointX, pointY, 4, 0, 2 * Math.PI);
      ctx.fillStyle = 'rgb(255, 99, 132)';
      ctx.fill();
      ctx.strokeStyle = 'white';
      ctx.lineWidth = 1;
      ctx.stroke();
      
      // Display value near point
      const labelX = centerX + Math.cos(angle) * (maxRadius * value + 15);
      const labelY = centerY + Math.sin(angle) * (maxRadius * value + 15);
      
      ctx.fillStyle = '#333333';
      ctx.font = 'bold 12px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(`${radarData[i].value.toFixed(1)}%`, labelX, labelY);
    }
  };
  
  // Draw the pyramid balance visualization
  const drawPyramidBalance = () => {
    if (!canvasRef.current || selectedIngredients.length === 0) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    const width = canvas.width;
    const height = canvas.height;
    const pyramidHeight = height * 0.7;
    const pyramidBaseWidth = width * 0.8;
    const startX = (width - pyramidBaseWidth) / 2;
    const startY = height * 0.85;
    
    // Calculate percentages for each pyramid section
    const topNotesPercentage = selectedIngredients
      .filter(ing => ing.pyramid === 'Top')
      .reduce((sum, ing) => sum + ing.percentage, 0);
      
    const heartNotesPercentage = selectedIngredients
      .filter(ing => ing.pyramid === 'Heart' || ing.pyramid === 'Middle')
      .reduce((sum, ing) => sum + ing.percentage, 0);
      
    const baseNotesPercentage = selectedIngredients
      .filter(ing => ing.pyramid === 'Base')
      .reduce((sum, ing) => sum + ing.percentage, 0);
      
    const otherPercentage = selectedIngredients
      .filter(ing => !ing.pyramid)
      .reduce((sum, ing) => sum + ing.percentage, 0);
    
    // Total percentage (should be 100 but handle cases where it's not)
    const totalPercentage = topNotesPercentage + heartNotesPercentage + baseNotesPercentage + otherPercentage;
    
    // Calculate heights for each section as a proportion of the total pyramid height
    const baseSection = pyramidHeight * (baseNotesPercentage / totalPercentage);
    const heartSection = pyramidHeight * (heartNotesPercentage / totalPercentage);
    const topSection = pyramidHeight * (topNotesPercentage / totalPercentage);
    const otherSection = pyramidHeight * (otherPercentage / totalPercentage);
    
    // Draw the pyramid sections from bottom to top
    
    // Base Notes (bottom section)
    if (baseNotesPercentage > 0) {
      const baseHeight = baseSection;
      const baseTop = startY - baseHeight;
      
      ctx.beginPath();
      ctx.moveTo(startX, startY);
      ctx.lineTo(startX + pyramidBaseWidth, startY);
      ctx.lineTo(startX + pyramidBaseWidth * 0.85, baseTop);
      ctx.lineTo(startX + pyramidBaseWidth * 0.15, baseTop);
      ctx.closePath();
      
      const gradient = ctx.createLinearGradient(startX, startY, startX, baseTop);
      gradient.addColorStop(0, '#9c27b0');  // Dark purple
      gradient.addColorStop(1, '#b39ddb');  // Light purple
      ctx.fillStyle = gradient;
      ctx.fill();
      
      ctx.strokeStyle = '#6a1b9a';
      ctx.lineWidth = 2;
      ctx.stroke();
      
      // Label for base notes
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 16px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(`Base Notes (${baseNotesPercentage.toFixed(1)}%)`, width / 2, startY - baseHeight / 2);
      
      // Draw ingredients in this section
      const baseNotes = selectedIngredients.filter(ing => ing.pyramid === 'Base');
      if (baseNotes.length > 0) {
        let yOffset = 24;
        ctx.font = '12px Arial';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        
        baseNotes.forEach((ing, idx) => {
          if (idx < 3) { // Limit to prevent overcrowding
            ctx.fillText(`${ing.name} (${ing.percentage}%)`, width / 2, startY - baseHeight / 2 + yOffset);
            yOffset += 16;
          } else if (idx === 3) {
            ctx.fillText(`+${baseNotes.length - 3} more...`, width / 2, startY - baseHeight / 2 + yOffset);
          }
        });
      }
    }
    
    // Heart Notes (middle section)
    if (heartNotesPercentage > 0) {
      const heartStart = startY - baseSection;
      const heartEnd = heartStart - heartSection;
      
      ctx.beginPath();
      ctx.moveTo(startX + pyramidBaseWidth * 0.15, heartStart);
      ctx.lineTo(startX + pyramidBaseWidth * 0.85, heartStart);
      ctx.lineTo(startX + pyramidBaseWidth * 0.7, heartEnd);
      ctx.lineTo(startX + pyramidBaseWidth * 0.3, heartEnd);
      ctx.closePath();
      
      const gradient = ctx.createLinearGradient(startX, heartStart, startX, heartEnd);
      gradient.addColorStop(0, '#e91e63');  // Dark pink
      gradient.addColorStop(1, '#f8bbd0');  // Light pink
      ctx.fillStyle = gradient;
      ctx.fill();
      
      ctx.strokeStyle = '#c2185b';
      ctx.lineWidth = 2;
      ctx.stroke();
      
      // Label for heart notes
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 16px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(`Heart Notes (${heartNotesPercentage.toFixed(1)}%)`, width / 2, heartStart - heartSection / 2);
      
      // Draw ingredients in this section
      const heartNotes = selectedIngredients.filter(ing => ing.pyramid === 'Heart' || ing.pyramid === 'Middle');
      if (heartNotes.length > 0) {
        let yOffset = 24;
        ctx.font = '12px Arial';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        
        heartNotes.forEach((ing, idx) => {
          if (idx < 3) { // Limit to prevent overcrowding
            ctx.fillText(`${ing.name} (${ing.percentage}%)`, width / 2, heartStart - heartSection / 2 + yOffset);
            yOffset += 16;
          } else if (idx === 3) {
            ctx.fillText(`+${heartNotes.length - 3} more...`, width / 2, heartStart - heartSection / 2 + yOffset);
          }
        });
      }
    }
    
    // Top Notes (top section)
    if (topNotesPercentage > 0) {
      const topStart = startY - baseSection - heartSection;
      const topEnd = topStart - topSection;
      
      ctx.beginPath();
      ctx.moveTo(startX + pyramidBaseWidth * 0.3, topStart);
      ctx.lineTo(startX + pyramidBaseWidth * 0.7, topStart);
      ctx.lineTo(startX + pyramidBaseWidth * 0.55, topEnd);
      ctx.lineTo(startX + pyramidBaseWidth * 0.45, topEnd);
      ctx.closePath();
      
      const gradient = ctx.createLinearGradient(startX, topStart, startX, topEnd);
      gradient.addColorStop(0, '#2196f3');  // Dark blue
      gradient.addColorStop(1, '#bbdefb');  // Light blue
      ctx.fillStyle = gradient;
      ctx.fill();
      
      ctx.strokeStyle = '#1976d2';
      ctx.lineWidth = 2;
      ctx.stroke();
      
      // Label for top notes
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 16px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(`Top Notes (${topNotesPercentage.toFixed(1)}%)`, width / 2, topStart - topSection / 2);
      
      // Draw ingredients in this section
      const topNotes = selectedIngredients.filter(ing => ing.pyramid === 'Top');
      if (topNotes.length > 0) {
        let yOffset = 24;
        ctx.font = '12px Arial';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        
        topNotes.forEach((ing, idx) => {
          if (idx < 3) { // Limit to prevent overcrowding
            ctx.fillText(`${ing.name} (${ing.percentage}%)`, width / 2, topStart - topSection / 2 + yOffset);
            yOffset += 16;
          } else if (idx === 3) {
            ctx.fillText(`+${topNotes.length - 3} more...`, width / 2, topStart - topSection / 2 + yOffset);
          }
        });
      }
    }
    
    // Other/Undefined Notes (shown as a side component if present)
    if (otherPercentage > 0) {
      const sideX = startX + pyramidBaseWidth + 40;
      const sideY = startY - pyramidHeight / 2;
      const sideWidth = 140;
      const sideHeight = 100;
      
      ctx.beginPath();
      ctx.rect(sideX, sideY - sideHeight/2, sideWidth, sideHeight);
      ctx.fillStyle = '#90a4ae';
      ctx.fill();
      ctx.strokeStyle = '#546e7a';
      ctx.lineWidth = 2;
      ctx.stroke();
      
      // Label for undefined notes
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 14px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(`Other Notes`, sideX + sideWidth/2, sideY - sideHeight/2 + 20);
      ctx.fillText(`(${otherPercentage.toFixed(1)}%)`, sideX + sideWidth/2, sideY - sideHeight/2 + 40);
      
      // Draw ingredients in this section
      const otherNotes = selectedIngredients.filter(ing => !ing.pyramid);
      if (otherNotes.length > 0) {
        let yOffset = 60;
        ctx.font = '12px Arial';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        
        otherNotes.forEach((ing, idx) => {
          if (idx < 2) { // Limit to prevent overcrowding
            ctx.fillText(`${ing.name} (${ing.percentage}%)`, sideX + sideWidth/2, sideY - sideHeight/2 + yOffset);
            yOffset += 16;
          } else if (idx === 2) {
            ctx.fillText(`+${otherNotes.length - 2} more...`, sideX + sideWidth/2, sideY - sideHeight/2 + yOffset);
          }
        });
      }
    }
    
    // Draw recommended balance guidelines
    ctx.font = '14px Arial';
    ctx.fillStyle = '#333333';
    ctx.textAlign = 'left';
    
    const guideX = startX;
    const guideY = startY + 30;
    ctx.fillText('Recommended Balance:', guideX, guideY);
    ctx.fillText('• Top notes: 15-25% (fresh, volatile)', guideX, guideY + 20);
    ctx.fillText('• Heart notes: 40-60% (core character)', guideX, guideY + 40);
    ctx.fillText('• Base notes: 15-25% (longevity, depth)', guideX, guideY + 60);
  };

  // Handle visualization type change
  useEffect(() => {
    if (visualizationType === 'wheel') {
      // Redraw wheel chart
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          ctx.save();
          ctx.translate(offset.x + canvas.width / 2, offset.y + canvas.height / 2);
          ctx.scale(scale, scale);
          const centerX = 0;
          const centerY = 0;
          const maxRadius = Math.min(canvas.width, canvas.height) / 2 - 50;
          drawFlavorWheel(ctx, combinedFlavorProfile, centerX, centerY, maxRadius);
          ctx.restore();
        }
      }
    } else if (visualizationType === 'radar') {
      // Draw radar chart
      drawRadarChart();
    } else if (visualizationType === 'pyramid') {
      // Draw pyramid balance visualization
      drawPyramidBalance();
    }
  }, [visualizationType, combinedFlavorProfile, scale, offset, selectedIngredients]);

  // Handle ingredient selection
  const addIngredient = (ingredient: Ingredient) => {
    if (selectedIngredients.find(i => i.id === ingredient.id)) {
      toast({
        title: 'Already Added',
        description: `${ingredient.name} is already in your selection`,
      });
      return;
    }

    const colorIndex = selectedIngredients.length % COLORS.length;
    
    setSelectedIngredients(prev => [
      ...prev,
      {
        ...ingredient,
        percentage: 5, // Default percentage
        color: getCategoryColor(ingredient.category, colorIndex)
      }
    ]);

    toast({
      title: 'Ingredient Added',
      description: `${ingredient.name} has been added to your visualization`,
    });
  };

  // Handle ingredient removal
  const removeIngredient = (id: number) => {
    setSelectedIngredients(prev => prev.filter(i => i.id !== id));
  };

  // Update ingredient percentage
  const updatePercentage = (id: number, percentage: number) => {
    setSelectedIngredients(prev => 
      prev.map(ing => ing.id === id ? { ...ing, percentage } : ing)
    );
  };

  // Zoom in
  const zoomIn = () => {
    setScale(prev => Math.min(prev + 0.1, 2));
  };

  // Zoom out
  const zoomOut = () => {
    setScale(prev => Math.max(prev - 0.1, 0.5));
  };

  // Reset view
  const resetView = () => {
    setScale(1);
    setOffset({ x: 0, y: 0 });
  };

  // Pan handling
  const [isPanning, setIsPanning] = useState(false);
  const [startPanPosition, setStartPanPosition] = useState({ x: 0, y: 0 });

  const startPan = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsPanning(true);
    setStartPanPosition({ x: e.clientX, y: e.clientY });
  };

  const doPan = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isPanning) return;
    
    const dx = e.clientX - startPanPosition.x;
    const dy = e.clientY - startPanPosition.y;
    
    setOffset(prev => ({ x: prev.x + dx, y: prev.y + dy }));
    setStartPanPosition({ x: e.clientX, y: e.clientY });
  };

  const endPan = () => {
    setIsPanning(false);
  };

  // Export canvas as image
  const exportImage = () => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const image = canvas.toDataURL('image/png');
    
    const link = document.createElement('a');
    link.href = image;
    link.download = 'flavor-visualization.png';
    link.click();
    
    toast({
      title: 'Image Exported',
      description: 'Your flavor visualization has been exported as PNG',
    });
  };

  return (
    <Layout>
      <div className="container mx-auto py-6 space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Link href="/formulas">
              <Button variant="outline" size="sm">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Formulas
              </Button>
            </Link>
            <h1 className="text-3xl font-bold">Interactive Flavor Visualization</h1>
          </div>
          <Button onClick={exportImage}>
            <DownloadIcon className="mr-2 h-4 w-4" />
            Export Image
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Left column: Ingredient selection */}
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Ingredient Selection</CardTitle>
                <CardDescription>
                  Choose ingredients to visualize their combined flavor profile
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex space-x-2">
                  <Select
                    value={activeCategory}
                    onValueChange={setActiveCategory}
                  >
                    <SelectTrigger className="flex-1">
                      <SelectValue placeholder="Filter by Category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map(category => (
                        <SelectItem key={category} value={category}>
                          {category === 'all' ? 'All Categories' : category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Select
                    value={activePyramid}
                    onValueChange={setActivePyramid}
                  >
                    <SelectTrigger className="flex-1">
                      <SelectValue placeholder="Filter by Pyramid" />
                    </SelectTrigger>
                    <SelectContent>
                      {pyramidPositions.map(position => (
                        <SelectItem key={position} value={position}>
                          {position === 'all' ? 'All Notes' : position}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search ingredients..."
                    className="w-full px-3 py-2 border rounded-md"
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                  />
                </div>

                <div className="h-[300px] overflow-y-auto border rounded-md p-2">
                  {isLoading ? (
                    <div className="flex items-center justify-center h-full">
                      <div className="animate-spin h-6 w-6 border-2 border-primary border-t-transparent rounded-full"></div>
                    </div>
                  ) : error ? (
                    <div className="flex items-center justify-center h-full text-red-500">
                      Error loading ingredients
                    </div>
                  ) : displayedIngredients.length === 0 ? (
                    <div className="flex items-center justify-center h-full text-gray-500">
                      No ingredients found
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {displayedIngredients.map(ingredient => (
                        <div
                          key={ingredient.id}
                          className="flex items-center justify-between p-2 hover:bg-muted rounded-md"
                        >
                          <div>
                            <div className="font-medium">{ingredient.name}</div>
                            <div className="text-xs text-muted-foreground">
                              {ingredient.category}
                              {ingredient.pyramid && ` • ${ingredient.pyramid} note`}
                            </div>
                          </div>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => addIngredient(ingredient)}
                          >
                            <PlusIcon className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Selected Ingredients</CardTitle>
                <CardDescription>
                  Adjust percentages to see how they affect the flavor profile
                </CardDescription>
              </CardHeader>
              <CardContent>
                {selectedIngredients.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    No ingredients selected yet
                  </div>
                ) : (
                  <div className="space-y-4">
                    {selectedIngredients.map(ingredient => (
                      <div key={ingredient.id} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div
                              className="w-3 h-3 rounded-full mr-2"
                              style={{ backgroundColor: ingredient.color }}
                            />
                            <span className="font-medium">{ingredient.name}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <span className="text-sm">{ingredient.percentage}%</span>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => removeIngredient(ingredient.id)}
                            >
                              <MinusIcon className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        <Slider
                          value={[ingredient.percentage]}
                          min={1}
                          max={100}
                          step={1}
                          onValueChange={value => updatePercentage(ingredient.id, value[0])}
                        />
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>1%</span>
                          <span>50%</span>
                          <span>100%</span>
                        </div>
                      </div>
                    ))}

                    <div className="pt-4 border-t mt-4">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">Total:</span>
                        <span className={`font-bold ${
                          selectedIngredients.reduce((sum, ing) => sum + ing.percentage, 0) !== 100
                            ? 'text-orange-500'
                            : 'text-green-500'
                        }`}>
                          {selectedIngredients.reduce((sum, ing) => sum + ing.percentage, 0)}%
                        </span>
                      </div>
                      {selectedIngredients.reduce((sum, ing) => sum + ing.percentage, 0) !== 100 && (
                        <p className="text-xs text-muted-foreground mt-1">
                          Note: Percentages will be normalized for visualization
                        </p>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Center and right columns: Visualization */}
          <div className="md:col-span-2 space-y-4">
            <Card className="w-full">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <div>
                  <CardTitle>Flavor Profile Visualization</CardTitle>
                  <CardDescription>
                    Visual representation of the combined flavor profile
                  </CardDescription>
                </div>
                <div className="flex space-x-1">
                  <Button variant="outline" size="sm" onClick={zoomIn}>
                    <ZoomInIcon className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={zoomOut}>
                    <ZoomOutIcon className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={resetView}>
                    <RotateCcwIcon className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <Tabs
                  value={visualizationType}
                  onValueChange={setVisualizationType}
                  className="w-full"
                >
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="wheel">Flavor Wheel</TabsTrigger>
                    <TabsTrigger value="radar">Radar Chart</TabsTrigger>
                    <TabsTrigger value="pyramid">Pyramid Balance</TabsTrigger>
                  </TabsList>
                  
                  <div className="mt-4 border rounded-lg overflow-hidden">
                    <canvas
                      ref={canvasRef}
                      width={800}
                      height={600}
                      className={`w-full h-[500px] ${isPanning ? 'cursor-grabbing' : 'cursor-grab'}`}
                      onMouseDown={startPan}
                      onMouseMove={doPan}
                      onMouseUp={endPan}
                      onMouseLeave={endPan}
                    />
                  </div>

                  {selectedIngredients.length === 0 && (
                    <div className="absolute inset-0 flex items-center justify-center bg-background/80">
                      <div className="text-center p-6">
                        <p className="text-lg font-medium mb-2">No ingredients selected</p>
                        <p className="text-muted-foreground">
                          Add ingredients from the left panel to visualize their flavor profile
                        </p>
                      </div>
                    </div>
                  )}
                </Tabs>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle>Pyramid Balance</CardTitle>
                  <CardDescription>
                    Distribution of top, middle, and base notes
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {selectedIngredients.length === 0 ? (
                    <div className="text-center py-6 text-muted-foreground">
                      No ingredients selected yet
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {/* Top Notes */}
                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">Top Notes</span>
                          <span className="text-sm">
                            {selectedIngredients
                              .filter(ing => ing.pyramid === 'Top')
                              .reduce((sum, ing) => sum + ing.percentage, 0)}%
                          </span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-blue-400"
                            style={{
                              width: `${selectedIngredients
                                .filter(ing => ing.pyramid === 'Top')
                                .reduce((sum, ing) => sum + ing.percentage, 0)}%`,
                            }}
                          />
                        </div>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {selectedIngredients
                            .filter(ing => ing.pyramid === 'Top')
                            .map(ing => (
                              <Badge key={ing.id} variant="outline" className="text-xs">
                                {ing.name} ({ing.percentage}%)
                              </Badge>
                            ))}
                        </div>
                      </div>

                      {/* Middle/Heart Notes */}
                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">Heart Notes</span>
                          <span className="text-sm">
                            {selectedIngredients
                              .filter(ing => ing.pyramid === 'Heart' || ing.pyramid === 'Middle')
                              .reduce((sum, ing) => sum + ing.percentage, 0)}%
                          </span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-pink-400"
                            style={{
                              width: `${selectedIngredients
                                .filter(ing => ing.pyramid === 'Heart' || ing.pyramid === 'Middle')
                                .reduce((sum, ing) => sum + ing.percentage, 0)}%`,
                            }}
                          />
                        </div>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {selectedIngredients
                            .filter(ing => ing.pyramid === 'Heart' || ing.pyramid === 'Middle')
                            .map(ing => (
                              <Badge key={ing.id} variant="outline" className="text-xs">
                                {ing.name} ({ing.percentage}%)
                              </Badge>
                            ))}
                        </div>
                      </div>

                      {/* Base Notes */}
                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">Base Notes</span>
                          <span className="text-sm">
                            {selectedIngredients
                              .filter(ing => ing.pyramid === 'Base')
                              .reduce((sum, ing) => sum + ing.percentage, 0)}%
                          </span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-purple-400"
                            style={{
                              width: `${selectedIngredients
                                .filter(ing => ing.pyramid === 'Base')
                                .reduce((sum, ing) => sum + ing.percentage, 0)}%`,
                            }}
                          />
                        </div>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {selectedIngredients
                            .filter(ing => ing.pyramid === 'Base')
                            .map(ing => (
                              <Badge key={ing.id} variant="outline" className="text-xs">
                                {ing.name} ({ing.percentage}%)
                              </Badge>
                            ))}
                        </div>
                      </div>

                      {/* Other/Unknown */}
                      {selectedIngredients.some(ing => !ing.pyramid) && (
                        <div className="space-y-1">
                          <div className="flex items-center justify-between">
                            <span className="font-medium">Other/Undefined</span>
                            <span className="text-sm">
                              {selectedIngredients
                                .filter(ing => !ing.pyramid)
                                .reduce((sum, ing) => sum + ing.percentage, 0)}%
                            </span>
                          </div>
                          <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-gray-400"
                              style={{
                                width: `${selectedIngredients
                                  .filter(ing => !ing.pyramid)
                                  .reduce((sum, ing) => sum + ing.percentage, 0)}%`,
                              }}
                            />
                          </div>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {selectedIngredients
                              .filter(ing => !ing.pyramid)
                              .map(ing => (
                                <Badge key={ing.id} variant="outline" className="text-xs">
                                  {ing.name} ({ing.percentage}%)
                                </Badge>
                              ))}
                          </div>
                        </div>
                      )}

                      <div className="pt-2 text-xs text-muted-foreground">
                        <p>Recommended balance:</p>
                        <p>• Top notes: 15-25% (fresh, volatile)</p>
                        <p>• Heart notes: 40-60% (core character)</p>
                        <p>• Base notes: 15-25% (longevity, depth)</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Dominant Characteristics</CardTitle>
                  <CardDescription>
                    Most prominent flavor notes in this composition
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {Object.keys(combinedFlavorProfile).length === 0 ? (
                    <div className="text-center py-6 text-muted-foreground">
                      No ingredients selected yet
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {Object.entries(combinedFlavorProfile)
                        .sort(([, a], [, b]) => b - a)
                        .slice(0, 5)
                        .map(([odor, value], index) => (
                          <div key={odor} className="space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="font-medium">{odor}</span>
                              <span className="text-sm">{value.toFixed(1)}%</span>
                            </div>
                            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                              <div
                                className="h-full"
                                style={{
                                  width: `${Math.min(value, 100)}%`,
                                  backgroundColor: getCategoryColor(odor, index)
                                }}
                              />
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {selectedIngredients
                                .filter(ing => 
                                  Array.isArray(ing.odorProfile) 
                                    ? ing.odorProfile.includes(odor) 
                                    : typeof ing.odorProfile === 'object' && ing.odorProfile[odor]
                                )
                                .map(ing => ing.name)
                                .join(', ')}
                            </div>
                          </div>
                        ))}

                      <div className="pt-2 mt-2 border-t">
                        <h4 className="font-medium mb-2">Character Summary</h4>
                        <p className="text-sm">
                          This composition is predominantly characterized by 
                          {Object.entries(combinedFlavorProfile)
                            .sort(([, a], [, b]) => b - a)
                            .slice(0, 3)
                            .map(([odor], index, arr) => {
                              if (index === 0) return ` ${odor}`;
                              if (index === arr.length - 1) return ` and ${odor}`;
                              return `, ${odor}`;
                            })
                            .join('')} notes, 
                          giving it a 
                          {selectedIngredients.some(ing => ing.pyramid === 'Top') ? ' bright top note, ' : ' '}
                          {selectedIngredients.some(ing => ing.pyramid === 'Heart' || ing.pyramid === 'Middle') ? 'complex heart, ' : ''}
                          {selectedIngredients.some(ing => ing.pyramid === 'Base') ? 'and long-lasting base.' : ''}
                        </p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default FlavorVisualizationPage;