import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Resource } from "@/lib/types";
import { Search, Filter, ChevronUp, ChevronDown, Plus } from "lucide-react";
import { Link } from "wouter";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const ResourceSearch = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [selectedResources, setSelectedResources] = useState<number[]>([]);
  const [sortField, setSortField] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");
  
  // Column visibility state
  const [columnVisibility, setColumnVisibility] = useState({
    code: true,
    name: true,
    status: true,
    pyramid: true,
    odour: true,
    cost: true,
    currency: true,
    category: false,
    type: false,
    quantity: false,
    supplier: false,
  });

  const { data: resources, isLoading } = useQuery({
    queryKey: ['/api/resources', { q: searchTerm }],
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // The query will be refetched automatically when searchTerm changes
  };

  const filteredResources = resources && Array.isArray(resources) 
    ? resources.filter((resource: Resource) => {
        let matches = true;
        
        if (categoryFilter && categoryFilter !== "all" && resource.category !== categoryFilter) {
          matches = false;
        }
        
        if (typeFilter && typeFilter !== "all" && resource.type !== typeFilter) {
          matches = false;
        }
        
        return matches;
      })
    : [];

  const sortedResources = filteredResources ? [...filteredResources].sort((a, b) => {
    if (!sortField) return 0;
    
    // Handle null or undefined values
    const valueA = a[sortField as keyof Resource] || '';
    const valueB = b[sortField as keyof Resource] || '';
    
    // For numeric fields
    if (typeof valueA === 'number' && typeof valueB === 'number') {
      return sortDirection === 'asc' ? valueA - valueB : valueB - valueA;
    }
    
    // For string fields
    const compareResult = String(valueA).localeCompare(String(valueB));
    return sortDirection === 'asc' ? compareResult : -compareResult;
  }) : [];

  const uniqueCategories = resources && Array.isArray(resources) 
    ? [...new Set(resources.map((r: Resource) => r.category))] 
    : [];
  const uniqueTypes = resources && Array.isArray(resources) 
    ? [...new Set(resources.map((r: Resource) => r.type))] 
    : [];

  const handleSelectResource = (id: number) => {
    setSelectedResources(prev => {
      if (prev.includes(id)) {
        return prev.filter(resId => resId !== id);
      } else {
        return [...prev, id];
      }
    });
  };

  const handleSelectAll = () => {
    if (selectedResources.length === sortedResources.length) {
      setSelectedResources([]);
    } else {
      setSelectedResources(sortedResources.map(resource => resource.id));
    }
  };

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const getColumnHeader = (field: string, label: string) => (
    <div 
      className="flex items-center cursor-pointer group"
      onClick={() => handleSort(field)}
    >
      <span>{label}</span>
      {sortField === field ? (
        sortDirection === 'asc' ? 
          <ChevronUp className="h-4 w-4 ml-1" /> : 
          <ChevronDown className="h-4 w-4 ml-1" />
      ) : (
        <div className="h-4 w-4 ml-1 opacity-0 group-hover:opacity-25">
          <ChevronUp className="h-4 w-4" />
        </div>
      )}
    </div>
  );

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Search Results</h1>
        <div className="flex gap-2">
          <Link href="/resources/my-requests">
            <Button variant="outline">My Requested Resources</Button>
          </Link>
          <Link href="/resources/request">
            <Button>Request New Resource</Button>
          </Link>
        </div>
      </div>

      <Card className="mb-6">
        <CardContent className="p-6">
          <form onSubmit={handleSearch} className="flex flex-col space-y-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Enter search details..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Button type="submit">Search</Button>
            </div>

            <div className="flex flex-col md:flex-row items-center gap-4 pt-2">
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-gray-500" />
                <span className="text-sm text-gray-500">Filters:</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 flex-1">
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {uniqueCategories.map((category) => (
                      <SelectItem key={category} value={category}>{category}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    {uniqueTypes.map((type) => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </form>
        </CardContent>
      </Card>

      <div className="sticky top-0 z-10 bg-white pb-4">
        <div className="flex justify-between items-center">
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={selectedResources.length === 0}
            >
              Compare
            </Button>
            <Button
              variant="outline"
              size="sm"
              disabled={selectedResources.length === 0}
            >
              Request Sample Documents
            </Button>
            <Button
              variant="outline"
              size="sm"
              disabled={selectedResources.length === 0}
            >
              Reactivate
            </Button>
            <Button
              variant="outline"
              size="sm"
              disabled={selectedResources.length === 0}
            >
              Deactivate
            </Button>
            <Button
              variant="outline"
              size="sm"
              disabled={selectedResources.length === 0}
            >
              Global Change
            </Button>
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="ml-auto">
                <Plus className="h-4 w-4 mr-1" />
                Columns
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Toggle Columns</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuCheckboxItem
                checked={columnVisibility.code}
                onCheckedChange={(checked) => 
                  setColumnVisibility(prev => ({ ...prev, code: checked }))}
              >
                Code
              </DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem
                checked={columnVisibility.name}
                onCheckedChange={(checked) => 
                  setColumnVisibility(prev => ({ ...prev, name: checked }))}
              >
                Name
              </DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem
                checked={columnVisibility.status}
                onCheckedChange={(checked) => 
                  setColumnVisibility(prev => ({ ...prev, status: checked }))}
              >
                Status
              </DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem
                checked={columnVisibility.pyramid}
                onCheckedChange={(checked) => 
                  setColumnVisibility(prev => ({ ...prev, pyramid: checked }))}
              >
                Pyramid
              </DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem
                checked={columnVisibility.odour}
                onCheckedChange={(checked) => 
                  setColumnVisibility(prev => ({ ...prev, odour: checked }))}
              >
                Odour
              </DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem
                checked={columnVisibility.cost}
                onCheckedChange={(checked) => 
                  setColumnVisibility(prev => ({ ...prev, cost: checked }))}
              >
                Cost
              </DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem
                checked={columnVisibility.currency}
                onCheckedChange={(checked) => 
                  setColumnVisibility(prev => ({ ...prev, currency: checked }))}
              >
                Currency
              </DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem
                checked={columnVisibility.category}
                onCheckedChange={(checked) => 
                  setColumnVisibility(prev => ({ ...prev, category: checked }))}
              >
                Category
              </DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem
                checked={columnVisibility.type}
                onCheckedChange={(checked) => 
                  setColumnVisibility(prev => ({ ...prev, type: checked }))}
              >
                Type
              </DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem
                checked={columnVisibility.quantity}
                onCheckedChange={(checked) => 
                  setColumnVisibility(prev => ({ ...prev, quantity: checked }))}
              >
                Quantity
              </DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem
                checked={columnVisibility.supplier}
                onCheckedChange={(checked) => 
                  setColumnVisibility(prev => ({ ...prev, supplier: checked }))}
              >
                Supplier
              </DropdownMenuCheckboxItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <p className="text-center py-4">Loading resources...</p>
          ) : sortedResources?.length === 0 ? (
            <div className="text-center py-8">
              <h3 className="text-lg font-medium mb-2">No resources found</h3>
              <p className="text-gray-500">Try adjusting your search or filter criteria</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-4 py-3 text-left">
                      <Checkbox 
                        checked={selectedResources.length === sortedResources.length && sortedResources.length > 0} 
                        onCheckedChange={handleSelectAll}
                        aria-label="Select all resources"
                      />
                    </th>
                    {columnVisibility.code && (
                      <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {getColumnHeader('code', 'Code')}
                      </th>
                    )}
                    {columnVisibility.name && (
                      <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {getColumnHeader('name', 'Name')}
                      </th>
                    )}
                    {columnVisibility.status && (
                      <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {getColumnHeader('status', 'Status')}
                      </th>
                    )}
                    {columnVisibility.pyramid && (
                      <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {getColumnHeader('pyramid', 'Pyramid')}
                      </th>
                    )}
                    {columnVisibility.odour && (
                      <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {getColumnHeader('odour', 'Odour')}
                      </th>
                    )}
                    {columnVisibility.cost && (
                      <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {getColumnHeader('costPerUnit', 'Cost')}
                      </th>
                    )}
                    {columnVisibility.currency && (
                      <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {getColumnHeader('currency', 'Currency')}
                      </th>
                    )}
                    {columnVisibility.category && (
                      <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {getColumnHeader('category', 'Category')}
                      </th>
                    )}
                    {columnVisibility.type && (
                      <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {getColumnHeader('type', 'Type')}
                      </th>
                    )}
                    {columnVisibility.quantity && (
                      <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {getColumnHeader('quantity', 'Quantity')}
                      </th>
                    )}
                    {columnVisibility.supplier && (
                      <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {getColumnHeader('supplier', 'Supplier')}
                      </th>
                    )}
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {sortedResources.map((resource: Resource) => (
                    <tr key={resource.id} className={selectedResources.includes(resource.id) ? "bg-blue-50" : ""}>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <Checkbox 
                          checked={selectedResources.includes(resource.id)} 
                          onCheckedChange={() => handleSelectResource(resource.id)}
                          aria-label={`Select ${resource.name}`}
                        />
                      </td>
                      {columnVisibility.code && (
                        <td className="px-4 py-3 whitespace-nowrap text-sm">
                          {resource.code || '-'}
                        </td>
                      )}
                      {columnVisibility.name && (
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="font-medium text-gray-900">{resource.name}</div>
                          {resource.description && (
                            <div className="text-xs text-gray-500">{resource.description}</div>
                          )}
                        </td>
                      )}
                      {columnVisibility.status && (
                        <td className="px-4 py-3 whitespace-nowrap text-sm">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                            ${resource.status === 'Active' ? 'bg-green-100 text-green-800' : 
                              resource.status === 'Inactive' ? 'bg-red-100 text-red-800' : 
                              'bg-gray-100 text-gray-800'}`}>
                            {resource.status || 'Unknown'}
                          </span>
                        </td>
                      )}
                      {columnVisibility.pyramid && (
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                          {resource.pyramid || '-'}
                        </td>
                      )}
                      {columnVisibility.odour && (
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                          {resource.odour || '-'}
                        </td>
                      )}
                      {columnVisibility.cost && (
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                          {resource.costPerUnit !== undefined ? resource.costPerUnit.toFixed(2) : '-'}
                        </td>
                      )}
                      {columnVisibility.currency && (
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                          {resource.currency || '-'}
                        </td>
                      )}
                      {columnVisibility.category && (
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                          {resource.category}
                        </td>
                      )}
                      {columnVisibility.type && (
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                          {resource.type}
                        </td>
                      )}
                      {columnVisibility.quantity && (
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                          {resource.quantity} {resource.unit}
                        </td>
                      )}
                      {columnVisibility.supplier && (
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                          {resource.supplier || '-'}
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ResourceSearch;
