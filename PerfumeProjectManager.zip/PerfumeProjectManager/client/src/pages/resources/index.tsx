import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Search, Plus, Upload, Clock, ShoppingBag } from "lucide-react";

const Resources = () => {
  const { data: resourcesData, isLoading } = useQuery({
    queryKey: ['/api/resources']
  });

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Resource Management</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Link href="/resources/search">
          <Card className="cursor-pointer hover:shadow-md transition-shadow">
            <CardContent className="p-6 flex flex-col items-center text-center">
              <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 mb-4">
                <Search className="h-6 w-6" />
              </div>
              <CardTitle className="mb-2">Search Resources</CardTitle>
              <p className="text-sm text-gray-500">Find resources by name, type, or category</p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/resources/request">
          <Card className="cursor-pointer hover:shadow-md transition-shadow">
            <CardContent className="p-6 flex flex-col items-center text-center">
              <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center text-green-600 mb-4">
                <Plus className="h-6 w-6" />
              </div>
              <CardTitle className="mb-2">Request Resource</CardTitle>
              <p className="text-sm text-gray-500">Submit a request for existing resources</p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/resources/new-request-popup">
          <Card className="cursor-pointer hover:shadow-md transition-shadow">
            <CardContent className="p-6 flex flex-col items-center text-center">
              <div className="h-12 w-12 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600 mb-4">
                <Plus className="h-6 w-6" />
              </div>
              <CardTitle className="mb-2">New Resource Request</CardTitle>
              <p className="text-sm text-gray-500">Create a request for a new resource</p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/resources/my-requests">
          <Card className="cursor-pointer hover:shadow-md transition-shadow">
            <CardContent className="p-6 flex flex-col items-center text-center">
              <div className="h-12 w-12 rounded-full bg-amber-100 flex items-center justify-center text-amber-600 mb-4">
                <Clock className="h-6 w-6" />
              </div>
              <CardTitle className="mb-2">My Requested Resources</CardTitle>
              <p className="text-sm text-gray-500">Track your resource requests</p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/resources/import">
          <Card className="cursor-pointer hover:shadow-md transition-shadow">
            <CardContent className="p-6 flex flex-col items-center text-center">
              <div className="h-12 w-12 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 mb-4">
                <Upload className="h-6 w-6" />
              </div>
              <CardTitle className="mb-2">Import Acquisition Resources</CardTitle>
              <p className="text-sm text-gray-500">Import resources from acquisitions</p>
            </CardContent>
          </Card>
        </Link>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Resource Inventory Overview</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p className="text-center py-4">Loading resources...</p>
          ) : !resourcesData || (Array.isArray(resourcesData) && resourcesData.length === 0) ? (
            <div className="text-center py-8">
              <div className="h-16 w-16 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 mx-auto mb-4">
                <ShoppingBag className="h-8 w-8" />
              </div>
              <h3 className="text-lg font-medium mb-2">No resources found</h3>
              <p className="text-gray-500 mb-4">Your resource inventory is empty.</p>
              <Button asChild>
                <Link href="/resources/request">Request Resources</Link>
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Unit</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {Array.isArray(resourcesData) && resourcesData.map((resource: any) => (
                    <tr key={resource.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="font-medium text-gray-900">{resource.name}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{resource.category}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{resource.type}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{resource.quantity}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{resource.unit || '-'}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <Button variant="link" className="text-primary hover:text-primary-dark mr-3 p-0 h-auto">View</Button>
                        <Button variant="link" className="text-gray-600 hover:text-gray-900 p-0 h-auto">Edit</Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Resources;
