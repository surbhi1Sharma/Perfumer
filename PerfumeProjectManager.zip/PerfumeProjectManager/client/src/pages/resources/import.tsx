import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { createResource } from "@/lib/api";
import { File, Upload, AlertCircle, CheckCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const ResourceImport = () => {
  const [file, setFile] = useState<File | null>(null);
  const [resources, setResources] = useState<any[]>([]);
  const [importing, setImporting] = useState(false);
  const [importComplete, setImportComplete] = useState(false);
  const { toast } = useToast();

  const importMutation = useMutation({
    mutationFn: createResource,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/resources'] });
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      // In a real app, you would properly parse the file
      // Here we're just simulating some sample data
      setResources([
        {
          name: "Bergamot Oil",
          category: "Essential Oil",
          type: "Citrus",
          quantity: 1000,
          unit: "ml",
          supplier: "Citrus Suppliers Inc.",
          description: "Premium quality bergamot oil from Italy"
        },
        {
          name: "Lavender Extract",
          category: "Extract",
          type: "Floral",
          quantity: 500,
          unit: "g",
          supplier: "French Botanicals",
          description: "Pure lavender extract from Provence"
        },
        {
          name: "Vanilla Absolute",
          category: "Absolute",
          type: "Gourmand",
          quantity: 250,
          unit: "ml",
          supplier: "Madagascar Extracts",
          description: "Rich and sweet vanilla absolute"
        }
      ]);
    }
  };

  const handleImport = async () => {
    setImporting(true);
    try {
      // In a real app, you would process each resource
      // Here we're just simulating the import
      for (const resource of resources) {
        await importMutation.mutateAsync(resource);
      }
      
      setImportComplete(true);
      toast({
        title: "Import successful",
        description: `Imported ${resources.length} resources successfully.`,
      });
    } catch (error) {
      toast({
        title: "Import failed",
        description: "There was an error importing the resources.",
        variant: "destructive",
      });
    } finally {
      setImporting(false);
    }
  };

  const resetImport = () => {
    setFile(null);
    setResources([]);
    setImportComplete(false);
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-2">Import Acquisition Resources</h1>
        <p className="text-gray-500">Upload and import resources from acquisitions</p>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Import Resources</CardTitle>
          <CardDescription>
            Upload a CSV or Excel file containing resource information from acquisitions
          </CardDescription>
        </CardHeader>
        <CardContent>
          {importComplete ? (
            <Alert className="bg-green-50 border-green-100">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertTitle>Import completed successfully</AlertTitle>
              <AlertDescription>
                All resources have been imported into the system.
              </AlertDescription>
            </Alert>
          ) : (
            <div className="space-y-6">
              <div className="border-2 border-dashed border-gray-200 rounded-lg p-6 text-center">
                <div className="mb-4">
                  <div className="mx-auto w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <File className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <h3 className="text-lg font-medium mb-2">Upload Resource File</h3>
                <p className="text-sm text-gray-500 mb-4">
                  Drag and drop your file here, or click to browse
                </p>
                <Input
                  type="file"
                  accept=".csv, .xlsx, .xls"
                  id="file-upload"
                  className="hidden"
                  onChange={handleFileChange}
                />
                <Button asChild>
                  <label htmlFor="file-upload" className="cursor-pointer">Browse Files</label>
                </Button>
              </div>

              {file && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center">
                    <File className="h-5 w-5 text-gray-400 mr-2" />
                    <span className="font-medium">{file.name}</span>
                    <span className="ml-2 text-sm text-gray-500">
                      ({(file.size / 1024).toFixed(2)} KB)
                    </span>
                  </div>
                </div>
              )}

              {resources.length > 0 && (
                <div>
                  <h3 className="font-medium mb-2">Preview Import Data</h3>
                  <div className="border rounded-lg overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Category</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Quantity</TableHead>
                          <TableHead>Unit</TableHead>
                          <TableHead>Supplier</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {resources.map((resource, index) => (
                          <TableRow key={index}>
                            <TableCell className="font-medium">{resource.name}</TableCell>
                            <TableCell>{resource.category}</TableCell>
                            <TableCell>{resource.type}</TableCell>
                            <TableCell>{resource.quantity}</TableCell>
                            <TableCell>{resource.unit}</TableCell>
                            <TableCell>{resource.supplier}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          {importComplete ? (
            <div className="flex w-full justify-center">
              <Button onClick={resetImport}>Import Another File</Button>
            </div>
          ) : (
            <div className="flex w-full justify-end gap-2">
              <Button
                variant="outline"
                onClick={resetImport}
                disabled={!file || importing}
              >
                Reset
              </Button>
              <Button
                onClick={handleImport}
                disabled={!resources.length || importing}
                className="flex items-center gap-2"
              >
                {importing ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-current border-t-transparent rounded-full" />
                    Importing...
                  </>
                ) : (
                  <>
                    <Upload className="h-4 w-4" />
                    Import Resources
                  </>
                )}
              </Button>
            </div>
          )}
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Import Guidelines</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h3 className="font-medium mb-1">File Format</h3>
              <p className="text-sm text-gray-500">
                Please ensure your file is in CSV or Excel format with the following columns:
              </p>
              <ul className="list-disc list-inside text-sm text-gray-500 mt-2 ml-4">
                <li>Name (required)</li>
                <li>Category (required)</li>
                <li>Type (required)</li>
                <li>Quantity (required)</li>
                <li>Unit (optional)</li>
                <li>Supplier (optional)</li>
                <li>Description (optional)</li>
                <li>Cost Per Unit (optional)</li>
                <li>Notes (optional)</li>
              </ul>
            </div>

            <Alert variant="warning">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Important</AlertTitle>
              <AlertDescription>
                Ensure your data is properly formatted. Duplicate resources will be identified by name and updated rather than creating duplicates.
              </AlertDescription>
            </Alert>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ResourceImport;
