import { useState } from "react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { createResourceRequest } from "@/lib/api";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { ResourceRequestDialog } from "@/components/resources/ResourceRequestDialog";

const NewResourceRequestPopup = () => {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(true);

  const createMutation = useMutation({
    mutationFn: createResourceRequest,
    onSuccess: () => {
      toast({
        title: "Resource request submitted",
        description: "Your resource request has been successfully submitted.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/resource-requests'] });
      navigate("/resources");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to submit resource request. Please try again.",
        variant: "destructive",
      });
      console.error("Error submitting resource request:", error);
    }
  });

  const handleSave = (formData: any) => {
    // Map form data to API request format
    const resourceRequest = {
      resourceId: 0, // This would typically come from a resource created on the backend
      userId: 1, // Current user ID - in a real app this would be from auth context
      quantity: 1, // Default quantity
      urgency: "normal",
      reason: formData.notes,
      // Include the custom fields according to our schema
      customFields: {
        resourceName: formData.resourceName,
        resourceCategory: formData.resourceCategory,
        casNo: formData.casNo || undefined,
        isComponent: formData.isComponent,
        odour: formData.odour,
        pyramid: formData.pyramid
      }
    };

    createMutation.mutate(resourceRequest);
    setIsDialogOpen(false);
  };

  const handleDialogClose = (open: boolean) => {
    setIsDialogOpen(open);
    if (!open) {
      navigate("/resources");
    }
  };

  return (
    <div className="container mx-auto py-6">
      <Card className="mx-auto max-w-4xl">
        <CardHeader>
          <CardTitle>New Resource Request</CardTitle>
          <CardDescription>
            Please use this form to request a new resource for your projects.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center">
            <p className="mb-4">The request form will appear in a popup dialog.</p>
            {!isDialogOpen && (
              <Button onClick={() => setIsDialogOpen(true)}>
                Open Request Form
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <ResourceRequestDialog
        open={isDialogOpen}
        onOpenChange={handleDialogClose}
        onSave={handleSave}
      />
    </div>
  );
};

export default NewResourceRequestPopup;