import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { createResourceRequest } from "@/lib/api";
import { useLocation } from "wouter";

const requestSchema = z.object({
  resourceId: z.number({
    required_error: "Please select a resource",
  }),
  userId: z.number().default(1), // Default to current user (in a real app, this would come from auth)
  quantity: z.number({
    required_error: "Quantity is required",
    invalid_type_error: "Quantity must be a number",
  }).positive("Quantity must be greater than 0"),
  urgency: z.string({
    required_error: "Please select urgency level",
  }),
  reason: z.string().min(10, "Reason must be at least 10 characters").max(500, "Reason cannot exceed 500 characters"),
});

type ResourceRequestFormValues = z.infer<typeof requestSchema>;

const ResourceRequest = () => {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  
  const { data: resources, isLoading: resourcesLoading } = useQuery({
    queryKey: ['/api/resources'],
  });

  const form = useForm<ResourceRequestFormValues>({
    resolver: zodResolver(requestSchema),
    defaultValues: {
      userId: 1,
      quantity: 1,
      urgency: "medium",
      reason: "",
    },
  });

  const createRequestMutation = useMutation({
    mutationFn: createResourceRequest,
    onSuccess: () => {
      toast({
        title: "Request submitted",
        description: "Your resource request has been submitted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/resource-requests'] });
      navigate("/resources/my-requests");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to submit request. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ResourceRequestFormValues) => {
    createRequestMutation.mutate(data);
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-2">Request Resource</h1>
        <p className="text-gray-500">Submit a request for resources needed for your projects</p>
      </div>
      
      <div className="flex justify-between items-center mb-6 max-w-2xl mx-auto">
        <p className="text-sm text-gray-500">Need to request a new resource that's not in the system?</p>
        <Button 
          variant="outline" 
          onClick={() => navigate("/resources/new-request-popup")}
          className="ml-4"
        >
          Create New Resource Request
        </Button>
      </div>

      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Resource Request Form</CardTitle>
          <CardDescription>
            Fill out the details below to request resources for your work
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="resourceId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Resource</FormLabel>
                    <Select
                      disabled={resourcesLoading}
                      onValueChange={(value) => field.onChange(parseInt(value))}
                      value={field.value?.toString()}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select resource" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {Array.isArray(resources) ? resources.map((resource: any) => (
                          <SelectItem key={resource.id} value={resource.id.toString()}>
                            {resource.name} ({resource.category})
                          </SelectItem>
                        )) : null}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="quantity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Quantity</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="1"
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="urgency"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Urgency</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select urgency level" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="reason"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reason for Request</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Explain why you need this resource and how it will be used..."
                        className="min-h-[120px]"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end space-x-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate("/resources")}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createRequestMutation.isPending}
                >
                  {createRequestMutation.isPending ? "Submitting..." : "Submit Request"}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
};

export default ResourceRequest;
