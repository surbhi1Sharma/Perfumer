import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogClose, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  CheckCircle,
  Clock,
  Edit,
  PlusCircle,
  Search,
  Trash2,
  Users,
  XCircle,
} from "lucide-react";

interface User {
  id: number;
  username: string;
  fullName: string;
  email: string;
  role: string;
  team: string;
  permissions: string[];
  department: string | null;
  isActive: boolean;
  lastLogin: string | null;
}

const UserManagement = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTeam, setSelectedTeam] = useState<string>("all");
  const [selectedRole, setSelectedRole] = useState<string>("all");

  // Fetch users data
  const { data: users = [], isLoading: isLoadingUsers } = useQuery({
    queryKey: ["/api/users"],
    queryFn: async () => {
      const response = await fetch("/api/users");
      if (!response.ok) {
        throw new Error("Failed to fetch users");
      }
      return response.json();
    },
  });

  // Fetch permissions data
  const { data: permissionsData = { permissions: [] } } = useQuery({
    queryKey: ["/api/reference/permissions"],
    queryFn: async () => {
      const response = await fetch("/api/reference/permissions");
      if (!response.ok) {
        throw new Error("Failed to fetch permissions");
      }
      return response.json();
    },
  });
  
  const permissions = permissionsData.permissions || [];

  // Fetch roles data
  const { data: rolesData = { roles: [] } } = useQuery({
    queryKey: ["/api/reference/roles"],
    queryFn: async () => {
      const response = await fetch("/api/reference/roles");
      if (!response.ok) {
        throw new Error("Failed to fetch roles");
      }
      return response.json();
    },
  });
  
  const roles = rolesData.roles || [];

  // Fetch teams data
  const { data: teamsData = { teams: [] } } = useQuery({
    queryKey: ["/api/reference/teams"],
    queryFn: async () => {
      const response = await fetch("/api/reference/teams");
      if (!response.ok) {
        throw new Error("Failed to fetch teams");
      }
      return response.json();
    },
  });
  
  const teams = teamsData.teams || [];

  // Create user mutation
  const createUserMutation = useMutation({
    mutationFn: async (newUser: Omit<User, "id" | "lastLogin">) => {
      return apiRequest("/api/users", "POST", newUser);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "User created successfully",
      });
      queryClient.invalidateQueries({
        queryKey: ["/api/users"],
      });
      setDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create user: ${error}`,
        variant: "destructive",
      });
    },
  });

  // Update user mutation
  const updateUserMutation = useMutation({
    mutationFn: async ({
      id,
      userData,
    }: {
      id: number;
      userData: Partial<Omit<User, "id" | "lastLogin">>;
    }) => {
      return apiRequest(`/api/users/${id}`, "PUT", userData);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "User updated successfully",
      });
      queryClient.invalidateQueries({
        queryKey: ["/api/users"],
      });
      setDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update user: ${error}`,
        variant: "destructive",
      });
    },
  });

  // Update user permissions mutation
  const updatePermissionsMutation = useMutation({
    mutationFn: async ({
      id,
      permissions,
    }: {
      id: number;
      permissions: string[];
    }) => {
      return apiRequest(`/api/users/${id}/permissions`, "PUT", { permissions });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "User permissions updated successfully",
      });
      queryClient.invalidateQueries({
        queryKey: ["/api/users"],
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update permissions: ${error}`,
        variant: "destructive",
      });
    },
  });

  // Update user status mutation
  const updateUserStatusMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: number; isActive: boolean }) => {
      return apiRequest(`/api/users/${id}/status`, "PUT", { isActive });
    },
    onSuccess: (_, variables) => {
      toast({
        title: "Success",
        description: `User ${variables.isActive ? "activated" : "deactivated"} successfully`,
      });
      queryClient.invalidateQueries({
        queryKey: ["/api/users"],
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update user status: ${error}`,
        variant: "destructive",
      });
    },
  });

  // Delete user mutation
  const deleteUserMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest(`/api/users/${id}`, "DELETE");
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "User deleted successfully",
      });
      queryClient.invalidateQueries({
        queryKey: ["/api/users"],
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete user: ${error}`,
        variant: "destructive",
      });
    },
  });

  // Filter users based on search query, status, team and role
  const filteredUsers = users.filter((user: User) => {
    // Filter by search query
    const searchMatch =
      user.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.role.toLowerCase().includes(searchQuery.toLowerCase());

    // Filter by active/inactive status
    const statusMatch =
      activeTab === "all" ||
      (activeTab === "active" && user.isActive) ||
      (activeTab === "inactive" && !user.isActive);

    // Filter by team
    const teamMatch = selectedTeam === "all" || user.team === selectedTeam;

    // Filter by role
    const roleMatch = selectedRole === "all" || user.role === selectedRole;

    return searchMatch && statusMatch && teamMatch && roleMatch;
  });

  // Initialize form state for creating/editing a user
  const handleCreateUser = () => {
    setEditingUser(null);
    setDialogOpen(true);
  };

  const handleEditUser = (user: User) => {
    setEditingUser(user);
    setDialogOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    const userData: Omit<User, "id" | "lastLogin"> = {
      username: formData.get("username") as string,
      fullName: formData.get("fullName") as string,
      email: formData.get("email") as string,
      role: formData.get("role") as string,
      team: formData.get("team") as string,
      department: formData.get("department") as string,
      isActive: formData.get("isActive") === "on",
      permissions: [] as string[], // Handled separately
    };

    // Get selected permissions
    const selectedPermissions: string[] = [];
    permissions.forEach((perm: string) => {
      if (formData.get(`permission-${perm}`) === "on") {
        selectedPermissions.push(perm);
      }
    });
    userData.permissions = selectedPermissions;

    if (editingUser) {
      // Update existing user
      updateUserMutation.mutate({
        id: editingUser.id,
        userData,
      });
    } else {
      // Create new user
      const password = formData.get("password") as string;
      const passwordConfirm = formData.get("passwordConfirm") as string;

      if (password !== passwordConfirm) {
        toast({
          title: "Error",
          description: "Passwords do not match",
          variant: "destructive",
        });
        return;
      }

      createUserMutation.mutate({
        ...userData,
        password,
      } as any);
    }
  };

  const handleUpdateStatus = (user: User, isActive: boolean) => {
    updateUserStatusMutation.mutate({
      id: user.id,
      isActive,
    });
  };

  const handleDeleteUser = (userId: number) => {
    if (window.confirm("Are you sure you want to delete this user? This action cannot be undone.")) {
      deleteUserMutation.mutate(userId);
    }
  };

  // Group permissions by category for better display
  const groupedPermissions: Record<string, string[]> = {};
  
  // Process each permission and group by category
  permissions.forEach((permission: string) => {
    const category = permission.split('_')[0];
    if (!groupedPermissions[category]) {
      groupedPermissions[category] = [];
    }
    groupedPermissions[category].push(permission);
  });

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold mb-2">User Management</h1>
          <p className="text-gray-500">
            Manage user accounts, permissions, and access control
          </p>
        </div>
        <Button onClick={handleCreateUser} className="flex items-center">
          <PlusCircle className="mr-2 h-4 w-4" />
          Add User
        </Button>
      </div>

      <Card className="mb-6">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle>Users</CardTitle>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search users..."
                  className="pl-8 w-64"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Select
                value={selectedTeam}
                onValueChange={setSelectedTeam}
              >
                <SelectTrigger className="w-44">
                  <SelectValue placeholder="Filter by team" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Teams</SelectItem>
                  {teams.map((team: string) => (
                    <SelectItem key={team} value={team}>
                      {team}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select
                value={selectedRole}
                onValueChange={setSelectedRole}
              >
                <SelectTrigger className="w-44">
                  <SelectValue placeholder="Filter by role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Roles</SelectItem>
                  {roles.map((role: string) => (
                    <SelectItem key={role} value={role}>
                      {role}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
            <TabsList>
              <TabsTrigger value="all" className="flex items-center">
                <Users className="mr-2 h-4 w-4" />
                All Users
              </TabsTrigger>
              <TabsTrigger value="active" className="flex items-center">
                <CheckCircle className="mr-2 h-4 w-4" />
                Active
              </TabsTrigger>
              <TabsTrigger value="inactive" className="flex items-center">
                <XCircle className="mr-2 h-4 w-4" />
                Inactive
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </CardHeader>
        <CardContent>
          {isLoadingUsers ? (
            <div className="text-center py-4">Loading users...</div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Username</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Team</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Last Login</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-4">
                        No users found
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredUsers.map((user: User) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">{user.fullName}</TableCell>
                        <TableCell>{user.username}</TableCell>
                        <TableCell>{user.role}</TableCell>
                        <TableCell>{user.team}</TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              user.isActive ? "default" : "destructive"
                            }
                          >
                            {user.isActive ? "Active" : "Inactive"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Clock className="mr-2 h-4 w-4 text-muted-foreground" />
                            {user.lastLogin
                              ? new Date(user.lastLogin).toLocaleString()
                              : "Never"}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="outline"
                              size="icon"
                              onClick={() => handleEditUser(user)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant={
                                user.isActive ? "destructive" : "default"
                              }
                              size="icon"
                              onClick={() =>
                                handleUpdateStatus(user, !user.isActive)
                              }
                            >
                              {user.isActive ? (
                                <XCircle className="h-4 w-4" />
                              ) : (
                                <CheckCircle className="h-4 w-4" />
                              )}
                            </Button>
                            <Button
                              variant="destructive"
                              size="icon"
                              onClick={() => handleDeleteUser(user.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create/Edit User Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>
              {editingUser ? "Edit User" : "Create New User"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <Tabs defaultValue="details">
              <TabsList className="mb-4">
                <TabsTrigger value="details">User Details</TabsTrigger>
                <TabsTrigger value="permissions">Permissions</TabsTrigger>
              </TabsList>
              <TabsContent value="details">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="username">Username</Label>
                    <Input
                      id="username"
                      name="username"
                      defaultValue={editingUser?.username || ""}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Full Name</Label>
                    <Input
                      id="fullName"
                      name="fullName"
                      defaultValue={editingUser?.fullName || ""}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      defaultValue={editingUser?.email || ""}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="department">Department</Label>
                    <Input
                      id="department"
                      name="department"
                      defaultValue={editingUser?.department || ""}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="role">Role</Label>
                    <Select name="role" defaultValue={editingUser?.role || ""}>
                      <SelectTrigger id="role">
                        <SelectValue placeholder="Select role" />
                      </SelectTrigger>
                      <SelectContent>
                        {roles.map((role: string) => (
                          <SelectItem key={role} value={role}>
                            {role}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="team">Team</Label>
                    <Select name="team" defaultValue={editingUser?.team || ""}>
                      <SelectTrigger id="team">
                        <SelectValue placeholder="Select team" />
                      </SelectTrigger>
                      <SelectContent>
                        {teams.map((team: string) => (
                          <SelectItem key={team} value={team}>
                            {team}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  {!editingUser && (
                    <>
                      <div className="space-y-2">
                        <Label htmlFor="password">Password</Label>
                        <Input
                          id="password"
                          name="password"
                          type="password"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="passwordConfirm">Confirm Password</Label>
                        <Input
                          id="passwordConfirm"
                          name="passwordConfirm"
                          type="password"
                          required
                        />
                      </div>
                    </>
                  )}
                  <div className="col-span-2 flex items-center space-x-2 pt-2">
                    <Switch
                      id="isActive"
                      name="isActive"
                      defaultChecked={editingUser?.isActive ?? true}
                    />
                    <Label htmlFor="isActive">Active Account</Label>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="permissions">
                <ScrollArea className="h-[300px] pr-4">
                  {Object.keys(groupedPermissions).map(category => (
                    <div key={category} className="mb-4">
                      <h3 className="text-lg font-medium mb-2 capitalize">{category}</h3>
                      <div className="space-y-2">
                        {groupedPermissions[category].map((permission: string) => (
                          <div
                            key={permission}
                            className="flex items-center space-x-2"
                          >
                            <Switch
                              id={`permission-${permission}`}
                              name={`permission-${permission}`}
                              defaultChecked={
                                editingUser?.permissions.includes(permission) ?? false
                              }
                            />
                            <Label htmlFor={`permission-${permission}`}>
                              {permission.split('_').slice(1).join(' ').replace(/\b\w/g, l => l.toUpperCase())}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </ScrollArea>
              </TabsContent>
            </Tabs>
            <DialogFooter className="mt-6">
              <DialogClose asChild>
                <Button variant="outline" type="button">
                  Cancel
                </Button>
              </DialogClose>
              <Button
                type="submit"
                disabled={
                  createUserMutation.isPending || updateUserMutation.isPending
                }
              >
                {editingUser ? "Update User" : "Create User"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default UserManagement;