import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { CalendarIcon, UserIcon, FolderIcon, BeakerIcon, PackageIcon } from "lucide-react";
import { Project, Task, Formula, Resource } from "@/lib/types";

const RecentWork = () => {
  const { data: projects } = useQuery({
    queryKey: ['/api/projects'],
  });

  const { data: tasks } = useQuery({
    queryKey: ['/api/tasks'],
  });

  const { data: formulas } = useQuery({
    queryKey: ['/api/formulas'],
  });

  const { data: resources } = useQuery({
    queryKey: ['/api/resources'],
  });

  const sortByDate = <T extends { createdAt?: string; updatedAt?: string }>(
    items: T[],
    dateField: 'createdAt' | 'updatedAt' = 'createdAt'
  ): T[] => {
    if (!items) return [];
    return [...items].sort((a, b) => {
      const dateA = a[dateField] ? new Date(a[dateField]!).getTime() : 0;
      const dateB = b[dateField] ? new Date(b[dateField]!).getTime() : 0;
      return dateB - dateA;
    }).slice(0, 10); // Get last 10 items
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return "N/A";
    return format(new Date(dateString), "MMM dd, yyyy");
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'active':
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'pending':
      case 'in review':
        return 'bg-yellow-100 text-yellow-800';
      case 'new':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Recent Work</h1>
      
      <Tabs defaultValue="projects">
        <TabsList className="mb-4">
          <TabsTrigger value="projects" className="flex items-center gap-2">
            <FolderIcon className="h-4 w-4" />
            Projects
          </TabsTrigger>
          <TabsTrigger value="tasks" className="flex items-center gap-2">
            <CalendarIcon className="h-4 w-4" />
            Tasks
          </TabsTrigger>
          <TabsTrigger value="formulas" className="flex items-center gap-2">
            <BeakerIcon className="h-4 w-4" />
            Formulas
          </TabsTrigger>
          <TabsTrigger value="resources" className="flex items-center gap-2">
            <PackageIcon className="h-4 w-4" />
            Resources
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="projects">
          <Card>
            <CardHeader>
              <CardTitle>Recent Projects</CardTitle>
            </CardHeader>
            <CardContent>
              {projects && projects.length > 0 ? (
                <div className="divide-y">
                  {sortByDate(projects).map((project: Project) => (
                    <div key={project.id} className="py-4 flex items-start">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary mr-4">
                        <FolderIcon className="h-5 w-5" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium">{project.name}</h3>
                        <p className="text-sm text-gray-500">Client: {project.client}</p>
                        <div className="flex items-center mt-1 text-sm text-gray-500">
                          <CalendarIcon className="h-4 w-4 mr-1" />
                          Created: {formatDate(project.createdAt)}
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(project.status)}`}>
                          {project.status}
                        </span>
                        <span className="text-sm text-gray-500">Stage: {project.stage}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center p-4 text-gray-500">
                  No projects found.
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="tasks">
          <Card>
            <CardHeader>
              <CardTitle>Recent Tasks</CardTitle>
            </CardHeader>
            <CardContent>
              {tasks && tasks.length > 0 ? (
                <div className="divide-y">
                  {sortByDate(tasks, 'updatedAt').map((task: Task) => (
                    <div key={task.id} className="py-4 flex items-start">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary mr-4">
                        <CalendarIcon className="h-5 w-5" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium">{task.title}</h3>
                        {task.description && (
                          <p className="text-sm text-gray-500">{task.description}</p>
                        )}
                        <div className="flex items-center mt-1 text-sm text-gray-500">
                          <UserIcon className="h-4 w-4 mr-1" />
                          Assigned to: User {task.assignedTo}
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(task.status)}`}>
                          {task.status}
                        </span>
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          task.priority === 'high' ? 'bg-red-100 text-red-800' :
                          task.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-blue-100 text-blue-800'
                        }`}>
                          {task.priority}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center p-4 text-gray-500">
                  No tasks found.
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="formulas">
          <Card>
            <CardHeader>
              <CardTitle>Recent Formulas</CardTitle>
            </CardHeader>
            <CardContent>
              {formulas && formulas.length > 0 ? (
                <div className="divide-y">
                  {sortByDate(formulas).map((formula: Formula) => (
                    <div key={formula.id} className="py-4 flex items-start">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary mr-4">
                        <BeakerIcon className="h-5 w-5" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium">{formula.name}</h3>
                        {formula.description && (
                          <p className="text-sm text-gray-500">{formula.description}</p>
                        )}
                        <div className="flex items-center mt-1 text-sm text-gray-500">
                          <span className="mr-2">Type: {formula.type}</span>
                          <span>Category: {formula.category}</span>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(formula.status)}`}>
                          {formula.status}
                        </span>
                        <span className="text-sm text-gray-500">
                          Created: {formatDate(formula.createdAt)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center p-4 text-gray-500">
                  No formulas found.
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="resources">
          <Card>
            <CardHeader>
              <CardTitle>Recent Resources</CardTitle>
            </CardHeader>
            <CardContent>
              {resources && resources.length > 0 ? (
                <div className="divide-y">
                  {sortByDate(resources).map((resource: Resource) => (
                    <div key={resource.id} className="py-4 flex items-start">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary mr-4">
                        <PackageIcon className="h-5 w-5" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium">{resource.name}</h3>
                        {resource.description && (
                          <p className="text-sm text-gray-500">{resource.description}</p>
                        )}
                        <div className="flex items-center mt-1 text-sm text-gray-500">
                          <span className="mr-2">Category: {resource.category}</span>
                          <span>Type: {resource.type}</span>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <span className="text-sm font-medium">
                          Quantity: {resource.quantity} {resource.unit || 'units'}
                        </span>
                        <span className="text-sm text-gray-500">
                          Added: {formatDate(resource.createdAt)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center p-4 text-gray-500">
                  No resources found.
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default RecentWork;
