import { apiRequest } from "./queryClient";
import { 
  Resource, 
  ResourceRequest, 
  Formula, 
  BaseRequest, 
  Project, 
  Task, 
  User,
  Ingredient
} from "./types";

// Auth API
export const login = async (username: string, password: string) => {
  const res = await apiRequest("POST", "/api/auth/login", { username, password });
  return res.json();
};

// Dashboard API
export const getDashboardData = async () => {
  const res = await apiRequest("GET", "/api/dashboard");
  return res.json();
};

// Resources API
export const getAllResources = async () => {
  const res = await apiRequest("GET", "/api/resources");
  return res.json();
};

export const createResource = async (resource: Omit<Resource, "id" | "createdAt">) => {
  const res = await apiRequest("POST", "/api/resources", resource);
  return res.json();
};

export const updateResource = async (id: number, resource: Partial<Omit<Resource, "id" | "createdAt">>) => {
  const res = await apiRequest("PUT", `/api/resources/${id}`, resource);
  return res.json();
};

// Resource Requests API
export const createResourceRequest = async (request: Omit<ResourceRequest, "id" | "status" | "createdAt" | "resolvedAt">) => {
  const res = await apiRequest("POST", "/api/resource-requests", request);
  return res.json();
};

export const updateResourceRequestStatus = async (id: number, status: string) => {
  const res = await apiRequest("PUT", `/api/resource-requests/${id}/status`, { status });
  return res.json();
};

// Ingredients API
export const getAllIngredients = async (): Promise<Ingredient[]> => {
  const res = await apiRequest("GET", "/api/ingredients");
  return res.json();
};

export const getIngredient = async (id: number): Promise<Ingredient> => {
  const res = await apiRequest("GET", `/api/ingredients/${id}`);
  return res.json();
};

export const getIngredientsByCategory = async (category: string): Promise<Ingredient[]> => {
  const res = await apiRequest("GET", `/api/ingredients/category/${encodeURIComponent(category)}`);
  return res.json();
};

export const getIngredientsByPyramid = async (pyramid: string): Promise<Ingredient[]> => {
  const res = await apiRequest("GET", `/api/ingredients/pyramid/${encodeURIComponent(pyramid)}`);
  return res.json();
};

// Formulas API
export const getAllFormulas = async () => {
  const res = await apiRequest("GET", "/api/formulas");
  return res.json();
};

export const createFormula = async (formula: Omit<Formula, "id" | "createdAt" | "updatedAt">) => {
  const res = await apiRequest("POST", "/api/formulas", formula);
  return res.json();
};

export const updateFormula = async (id: number, formula: Partial<Omit<Formula, "id" | "createdAt" | "updatedAt">>) => {
  const res = await apiRequest("PUT", `/api/formulas/${id}`, formula);
  return res.json();
};

// Base Requests API
export const createBaseRequest = async (request: Omit<BaseRequest, "id" | "status" | "createdAt" | "resolvedAt">) => {
  const res = await apiRequest("POST", "/api/base-requests", request);
  return res.json();
};

export const updateBaseRequestStatus = async (id: number, status: string) => {
  const res = await apiRequest("PUT", `/api/base-requests/${id}/status`, { status });
  return res.json();
};

// Projects API
export const getAllProjects = async () => {
  const res = await apiRequest("GET", "/api/projects");
  return res.json();
};

export const createProject = async (project: Omit<Project, "id" | "createdAt" | "updatedAt">) => {
  const res = await apiRequest("POST", "/api/projects", project);
  return res.json();
};

export const updateProject = async (id: number, project: Partial<Omit<Project, "id" | "createdAt" | "updatedAt">>) => {
  const res = await apiRequest("PUT", `/api/projects/${id}`, project);
  return res.json();
};

// Tasks API
export const getAllTasks = async () => {
  const res = await apiRequest("GET", "/api/tasks");
  return res.json();
};

export const createTask = async (task: Omit<Task, "id" | "status" | "createdAt" | "updatedAt" | "completedAt">) => {
  const res = await apiRequest("POST", "/api/tasks", task);
  return res.json();
};

export const updateTask = async (id: number, task: Partial<Omit<Task, "id" | "createdAt" | "updatedAt" | "completedAt">>) => {
  const res = await apiRequest("PUT", `/api/tasks/${id}`, task);
  return res.json();
};

export const updateTaskStatus = async (id: number, status: string) => {
  const res = await apiRequest("PUT", `/api/tasks/${id}/status`, { status });
  return res.json();
};

// AI-powered Compatibility API
export const analyzeIngredientsCompatibility = async (ingredientIds: number[]) => {
  const res = await apiRequest("GET", `/api/ingredients/compatibility?ids=${ingredientIds.join(',')}`);
  return res.json();
};

export const getIngredientSuggestions = async (
  ingredientIds: number[], 
  filters?: { category?: string; pyramid?: string }
) => {
  let url = `/api/ingredients/suggestions?ids=${ingredientIds.join(',')}`;
  
  if (filters?.category) {
    url += `&category=${encodeURIComponent(filters.category)}`;
  }
  
  if (filters?.pyramid) {
    url += `&pyramid=${encodeURIComponent(filters.pyramid)}`;
  }
  
  const res = await apiRequest("GET", url);
  return res.json();
};

export const analyzeFormulaInteractions = async (formulaId: number) => {
  const res = await apiRequest("GET", `/api/formulas/${formulaId}/analyze`);
  return res.json();
};

export const getFormulaCompatibilitySuggestions = async (formulaId: number) => {
  const res = await apiRequest("GET", `/api/formulas/${formulaId}/compatibility-suggestions`);
  return res.json();
};
