export interface DashboardStats {
  activeProjects: number;
  pendingFormulas: number;
  resourceRequests: number;
  urgentRequests: number;
}

export interface User {
  id: number;
  username: string;
  fullName: string;
  role: string;
  email: string;
  department?: string;
}

export interface Resource {
  id: number;
  code?: string;
  name: string;
  category: string;
  type: string;
  description?: string;
  quantity: number;
  unit?: string;
  costPerUnit?: number;
  currency?: string;
  supplier?: string;
  status?: string;
  pyramid?: number;
  odour?: string;
  notes?: string;
  createdAt: string;
}

export interface ResourceRequest {
  id: number;
  userId: number;
  resourceId: number;
  quantity: number;
  urgency: string;
  status: string;
  reason?: string;
  createdAt: string;
  resolvedAt?: string | null;
  customFields?: {
    resourceName?: string;
    resourceCategory?: string;
    casNo?: string;
    isComponent?: boolean;
    odour?: string;
    pyramid?: number;
  };
}

export interface Formula {
  id: number;
  name: string;
  description?: string;
  type: string;
  category: string;
  composition: Record<string, any>;
  createdBy: number;
  createdAt: string;
  updatedAt?: string;
  status: string;
  notes?: string;
}

export interface BaseRequest {
  id: number;
  userId: number;
  name: string;
  purpose: string;
  description?: string;
  urgency: string;
  status: string;
  createdAt: string;
  resolvedAt?: string | null;
}

export interface Project {
  id: number;
  name: string;
  client: string;
  description?: string;
  startDate: string;
  dueDate?: string;
  status: string;
  stage: string;
  manager: number;
  team: number[];
  notes?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface Task {
  id: number;
  title: string;
  description?: string;
  assignedTo: number;
  projectId?: number;
  dueDate?: string;
  priority: string;
  status: string;
  createdAt: string;
  updatedAt?: string;
  completedAt?: string | null;
}

export interface DashboardData {
  stats: DashboardStats;
  recentProjects: Project[];
  upcomingTasks: Task[];
}

export interface FormSelectOption {
  value: string;
  label: string;
}

export interface Ingredient {
  id: number;
  name: string;
  casNumber?: string | null;
  category: string;
  pyramid?: string | null;
  odorProfile: string[] | Record<string, any>;
  concentration?: string | null;
  solubility?: string | null;
  flashPoint?: string | null;
  appearanceState?: string | null;
  tenacity?: string | null;
  stability?: string | null;
  molecularWeight?: string | null;
  potency?: string | null;
  allergenInfo?: string[] | null;
  restrictions?: string[] | null;
  incompatibleWith?: any[] | null;
  substitutes?: any[] | null;
  enhancedBy?: any[] | null;
  recommendations?: Record<string, any> | null;
  createdAt?: string | Date | null;
  updatedAt?: string | Date | null;
}

export interface IngredientInteraction {
  id: number;
  ingredientAId: number;
  ingredientBId: number;
  interactionType: string;
  effect: string;
  strengthLevel: number;
  notes?: string | null;
  createdAt?: string | Date | null;
  updatedAt?: string | Date | null;
}

// AI-powered compatibility types
export interface IngredientCompatibility {
  overallScore: number;
  compatibilityMatrix: {
    ingredientA: Ingredient;
    ingredientB: Ingredient;
    score: number;
    effect: string;
    interactionType: string;
  }[];
  recommendedRatios: {
    ingredient: Ingredient;
    minPercentage: number;
    maxPercentage: number;
    optimalPercentage: number;
  }[];
}

export interface IngredientSuggestions {
  suggestions: {
    ingredient: Ingredient;
    compatibilityScore: number;
    reason: string;
    usageNotes: string;
  }[];
  alternativeGroups: {
    category: string;
    options: Ingredient[];
  }[];
}

export interface FormulaAnalysis {
  interactionScore: number;
  conflicts: {ingredientA: Ingredient, ingredientB: Ingredient, effect: string}[];
  enhancements: {ingredientA: Ingredient, ingredientB: Ingredient, effect: string}[];
  suggestions: {ingredient: Ingredient, purpose: string}[];
}

export interface FormulaCompatibilitySuggestions {
  topSuggestions: {ingredient: Ingredient, reason: string, compatibilityScore: number}[];
  balanceRecommendations: {category: string, currentPercentage: number, recommendedPercentage: number}[];
  substitutionOptions: {originalIngredient: Ingredient, substitutes: {ingredient: Ingredient, reason: string}[]};
}
