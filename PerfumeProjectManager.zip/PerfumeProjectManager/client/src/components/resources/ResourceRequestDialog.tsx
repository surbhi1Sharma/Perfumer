
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useQuery } from "@tanstack/react-query";

const RESOURCE_CATEGORIES = ["Raw Material", "Packaging", "Equipment", "Chemical", "Other"];
const ODOUR_LIST = ["Floral", "Fruity", "Spicy", "Woody", "Sweet", "Fresh", "Citrus", "Herbal", "Mint", "Vanilla"];

const formSchema = z.object({
  resourceName: z.string()
    .min(1, "Resource name is required")
    .max(15, "Resource name cannot exceed 15 characters")
    .regex(/^[a-zA-Z0-9]+$/, "Only alphanumeric characters are allowed"),
  resourceCategory: z.string().min(1, "Resource category is required"),
  casNo: z.string().min(1, "CAS number is required"),
  isComponent: z.boolean(),
  odour: z.string().min(1, "Odour is required"),
  pyramid: z.number().min(0).max(100),
  notes: z.string().max(250, "Notes cannot exceed 250 characters"),
});

type FormValues = z.infer<typeof formSchema>;

interface ResourceRequestDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (data: FormValues) => void;
}

export function ResourceRequestDialog({ open, onOpenChange, onSave }: ResourceRequestDialogProps) {
  const { data: casNumbers = [] } = useQuery<string[]>({
    queryKey: ['/api/cas-numbers'],
    enabled: open,
  });

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      resourceName: "",
      resourceCategory: "",
      casNo: "",
      isComponent: false,
      odour: "",
      pyramid: 50,
      notes: "",
    },
  });

  const handleSubmit = (values: FormValues) => {
    onSave(values);
    form.reset();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>New Resource Request</DialogTitle>
          <DialogDescription>
            Fill in the details to request a new resource.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="resourceName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Resource Name</FormLabel>
                  <FormControl>
                    <Input {...field} maxLength={15} placeholder="Enter resource name" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="resourceCategory"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Resource Category</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {RESOURCE_CATEGORIES.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="casNo"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>CAS Number</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select CAS number" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {casNumbers?.map((cas: string) => (
                        <SelectItem key={cas} value={cas}>
                          {cas}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="isComponent"
              render={({ field }) => (
                <FormItem className="flex items-center justify-between">
                  <FormLabel>Component</FormLabel>
                  <FormControl>
                    <Switch
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="odour"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Odour</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select an odour" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {ODOUR_LIST.map((odour) => (
                        <SelectItem key={odour} value={odour}>
                          {odour}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="pyramid"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Pyramid Level: {field.value}</FormLabel>
                  <FormControl>
                    <Slider
                      min={0}
                      max={100}
                      step={1}
                      value={[field.value]}
                      onValueChange={(vals) => field.onChange(vals[0])}
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea
                      {...field}
                      maxLength={250}
                      placeholder="Enter additional notes"
                      className="resize-none"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end space-x-2 pt-4">
              <Button variant="outline" type="button" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit">Save</Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
