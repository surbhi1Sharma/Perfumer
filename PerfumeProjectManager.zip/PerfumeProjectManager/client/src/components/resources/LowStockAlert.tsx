import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Resource, ResourceThreshold } from '@shared/schema';
import { Link } from 'wouter';

interface LowStockResource {
  resource: Resource;
  threshold: ResourceThreshold;
}

const LowStockAlert = () => {
  const { toast } = useToast();
  
  const { data: lowStockResources, isLoading, error } = useQuery<LowStockResource[]>({
    queryKey: ['/api/resources/low-stock'],
    retry: 1,
  });

  if (isLoading) {
    return (
      <Card className="border-yellow-200 bg-yellow-50">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium">Checking Inventory Levels</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2">
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-yellow-700"></div>
            <span>Loading inventory data...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="border-red-200 bg-red-50">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium text-red-800">Inventory Check Error</CardTitle>
        </CardHeader>
        <CardContent>
          <AlertDescription>
            Unable to retrieve inventory levels. Please try again later.
          </AlertDescription>
        </CardContent>
      </Card>
    );
  }

  if (!lowStockResources || lowStockResources.length === 0) {
    return (
      <Card className="border-green-200 bg-green-50">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium text-green-800">Inventory Levels</CardTitle>
          <CardDescription>All resources are at adequate levels</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-green-700">No resources are below their threshold levels.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-red-200">
      <CardHeader className="pb-2 bg-red-50">
        <div className="flex items-center space-x-2">
          <AlertCircle className="h-5 w-5 text-red-600" />
          <CardTitle className="text-lg font-medium text-red-800">
            Low Stock Alert ({lowStockResources.length})
          </CardTitle>
        </div>
        <CardDescription>Resources that need to be restocked</CardDescription>
      </CardHeader>
      <CardContent className="py-2">
        {lowStockResources.map((item) => (
          <Alert key={item.resource.id} variant="destructive" className="mb-2">
            <div className="flex justify-between items-start">
              <div>
                <AlertTitle className="text-red-800 font-bold">
                  {item.resource.name} ({item.resource.code})
                </AlertTitle>
                <AlertDescription className="mt-1">
                  <div className="flex flex-wrap gap-2 mt-1">
                    <Badge variant="outline" className="bg-white text-red-800 border-red-300">
                      Current: {item.resource.quantity} {item.resource.unit}
                    </Badge>
                    <Badge variant="outline" className="bg-white text-amber-800 border-amber-300">
                      Minimum: {item.threshold.minimumLevel} {item.resource.unit}
                    </Badge>
                    <Badge variant="outline" className="bg-white text-green-800 border-green-300">
                      Target: {item.threshold.targetLevel} {item.resource.unit}
                    </Badge>
                  </div>
                  <p className="text-sm mt-2 text-gray-700">{item.threshold.alertMessage}</p>
                </AlertDescription>
              </div>
            </div>
          </Alert>
        ))}
      </CardContent>
      <CardFooter className="bg-gray-50 flex justify-between">
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            toast({
              title: "Notifications sent",
              description: "Suppliers have been notified for all low stock items."
            });
          }}
        >
          Notify All Suppliers
        </Button>
        <Link href="/resources/search">
          <Button size="sm">
            View All Resources
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
};

export default LowStockAlert;