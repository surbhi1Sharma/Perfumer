import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { analyzeIngredientsCompatibility, getIngredientSuggestions } from '@/lib/api';
import { 
  Ingredient, 
  IngredientCompatibility, 
  IngredientSuggestions 
} from '@/lib/types';
import { 
  Check, 
  AlertTriangle, 
  AlertCircle, 
  PlusCircle, 
  ArrowRight 
} from 'lucide-react';

interface IngredientCompatibilityPanelProps {
  selectedIngredients: Ingredient[];
  onAddIngredient?: (ingredient: Ingredient) => void;
}

export function IngredientCompatibilityPanel({ 
  selectedIngredients,
  onAddIngredient
}: IngredientCompatibilityPanelProps) {
  const [activeTab, setActiveTab] = useState('compatibility');
  const [compatibility, setCompatibility] = useState<IngredientCompatibility | null>(null);
  const [suggestions, setSuggestions] = useState<IngredientSuggestions | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  // Fetch compatibility data when selected ingredients change
  useEffect(() => {
    const fetchCompatibilityData = async () => {
      if (selectedIngredients.length < 2) {
        setCompatibility(null);
        return;
      }

      setIsLoading(true);
      setError(null);

      try {
        const ingredientIds = selectedIngredients.map(ing => ing.id);
        const compatibilityData = await analyzeIngredientsCompatibility(ingredientIds);
        setCompatibility(compatibilityData);
      } catch (err) {
        console.error('Error fetching compatibility data:', err);
        setError('Failed to analyze ingredient compatibility');
        toast({
          title: 'Error',
          description: 'Failed to analyze ingredient compatibility',
          variant: 'destructive',
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchCompatibilityData();
  }, [selectedIngredients, toast]);

  // Fetch ingredient suggestions when active tab changes to suggestions
  useEffect(() => {
    const fetchSuggestions = async () => {
      if (activeTab !== 'suggestions' || selectedIngredients.length === 0) {
        return;
      }

      setIsLoading(true);
      setError(null);

      try {
        const ingredientIds = selectedIngredients.map(ing => ing.id);
        const suggestionsData = await getIngredientSuggestions(ingredientIds);
        setSuggestions(suggestionsData);
      } catch (err) {
        console.error('Error fetching ingredient suggestions:', err);
        setError('Failed to get ingredient suggestions');
        toast({
          title: 'Error',
          description: 'Failed to get ingredient suggestions',
          variant: 'destructive',
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchSuggestions();
  }, [activeTab, selectedIngredients, toast]);

  // Helper function to get a color based on score
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'bg-green-500';
    if (score >= 60) return 'bg-green-300';
    if (score >= 40) return 'bg-yellow-400';
    if (score >= 20) return 'bg-orange-400';
    return 'bg-red-500';
  };

  // Helper function to get an icon based on interaction type
  const getInteractionIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'enhances':
        return <Check className="h-4 w-4 text-green-500" />;
      case 'conflicts':
        return <AlertTriangle className="h-4 w-4 text-red-500" />;
      case 'complementary':
        return <Check className="h-4 w-4 text-blue-500" />;
      case 'potential conflict':
        return <AlertCircle className="h-4 w-4 text-yellow-500" />;
      default:
        return null;
    }
  };

  // Helper function to handle adding an ingredient from suggestions
  const handleAddIngredient = (ingredient: Ingredient) => {
    if (onAddIngredient) {
      onAddIngredient(ingredient);
      toast({
        title: 'Ingredient Added',
        description: `${ingredient.name} has been added to the formula`,
      });
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>AI-Powered Ingredient Analysis</CardTitle>
        <CardDescription>
          Analyze compatibility and get intelligent suggestions for your formula
        </CardDescription>
      </CardHeader>
      <CardContent>
        {selectedIngredients.length < 2 ? (
          <div className="p-4 text-center text-muted-foreground">
            Select at least two ingredients to analyze compatibility
          </div>
        ) : (
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full mb-4">
              <TabsTrigger value="compatibility" className="flex-1">Compatibility Analysis</TabsTrigger>
              <TabsTrigger value="suggestions" className="flex-1">Ingredient Suggestions</TabsTrigger>
              <TabsTrigger value="ratios" className="flex-1">Recommended Ratios</TabsTrigger>
            </TabsList>

            {isLoading ? (
              <div className="h-40 flex items-center justify-center">
                <div className="text-center">
                  <div className="animate-spin h-6 w-6 border-2 border-primary border-t-transparent rounded-full mx-auto mb-2"></div>
                  <p className="text-sm text-muted-foreground">Analyzing ingredients...</p>
                </div>
              </div>
            ) : error ? (
              <div className="p-4 text-center text-red-500">{error}</div>
            ) : (
              <>
                <TabsContent value="compatibility" className="space-y-4">
                  {compatibility && (
                    <>
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h3 className="text-lg font-medium">Overall Compatibility</h3>
                          <p className="text-sm text-muted-foreground">
                            How well these ingredients work together
                          </p>
                        </div>
                        <div className="text-right">
                          <span className="text-2xl font-bold">{compatibility.overallScore}%</span>
                        </div>
                      </div>
                      <Progress value={compatibility.overallScore} className="h-2 mb-6" />

                      <h3 className="text-lg font-medium mb-2">Ingredient Interactions</h3>
                      <div className="space-y-3 max-h-[300px] overflow-y-auto">
                        {compatibility.compatibilityMatrix.map((item, index) => (
                          <div key={index} className="flex items-start p-3 border rounded-md">
                            <div className="mr-3">
                              {getInteractionIcon(item.interactionType)}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center mb-1">
                                <span className="font-medium">{item.ingredientA.name}</span>
                                <ArrowRight className="h-3 w-3 mx-1" />
                                <span className="font-medium">{item.ingredientB.name}</span>
                                <Badge 
                                  className={`ml-2 ${getScoreColor(item.score)}`}
                                >
                                  {item.score}%
                                </Badge>
                              </div>
                              <p className="text-sm text-muted-foreground">{item.effect}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </>
                  )}
                </TabsContent>

                <TabsContent value="suggestions" className="space-y-4">
                  {suggestions && (
                    <>
                      <h3 className="text-lg font-medium mb-2">Recommended Ingredients</h3>
                      <div className="space-y-3 max-h-[300px] overflow-y-auto">
                        {suggestions.suggestions.map((suggestion, index) => (
                          <div key={index} className="flex items-start p-3 border rounded-md">
                            <div className="flex-1">
                              <div className="flex items-center justify-between mb-1">
                                <span className="font-medium">{suggestion.ingredient.name}</span>
                                <div className="flex items-center">
                                  <Badge 
                                    className={getScoreColor(suggestion.compatibilityScore)}
                                  >
                                    {suggestion.compatibilityScore}%
                                  </Badge>
                                  <Button 
                                    variant="ghost" 
                                    size="sm"
                                    onClick={() => handleAddIngredient(suggestion.ingredient)}
                                  >
                                    <PlusCircle className="h-4 w-4 mr-1" />
                                    Add
                                  </Button>
                                </div>
                              </div>
                              <p className="text-sm mb-1">{suggestion.reason}</p>
                              <p className="text-xs text-muted-foreground">{suggestion.usageNotes}</p>
                            </div>
                          </div>
                        ))}
                      </div>

                      <Separator className="my-4" />

                      <h3 className="text-lg font-medium mb-2">Alternative Groups</h3>
                      <div className="space-y-4">
                        {suggestions.alternativeGroups.map((group, index) => (
                          <div key={index} className="space-y-2">
                            <h4 className="text-sm font-medium">{group.category}</h4>
                            <div className="flex flex-wrap gap-2">
                              {group.options.slice(0, 5).map((ingredient, i) => (
                                <Badge 
                                  key={i} 
                                  variant="outline"
                                  className="cursor-pointer hover:bg-accent"
                                  onClick={() => handleAddIngredient(ingredient)}
                                >
                                  {ingredient.name}
                                  <PlusCircle className="h-3 w-3 ml-1" />
                                </Badge>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </>
                  )}
                </TabsContent>

                <TabsContent value="ratios" className="space-y-4">
                  {compatibility && (
                    <>
                      <h3 className="text-lg font-medium mb-2">Recommended Concentration Ratios</h3>
                      <div className="space-y-4 max-h-[300px] overflow-y-auto">
                        {compatibility.recommendedRatios.map((ratio, index) => (
                          <div key={index} className="space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="font-medium">{ratio.ingredient.name}</span>
                              <span className="text-sm">
                                Optimal: <span className="font-semibold">{ratio.optimalPercentage}%</span>
                              </span>
                            </div>
                            <div className="flex items-center text-xs text-muted-foreground">
                              <span className="w-10">{ratio.minPercentage}%</span>
                              <div className="flex-1 mx-2 h-2 bg-gray-200 rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-primary" 
                                  style={{
                                    marginLeft: `${ratio.minPercentage}%`,
                                    width: `${ratio.maxPercentage - ratio.minPercentage}%`
                                  }}
                                />
                              </div>
                              <span className="w-10 text-right">{ratio.maxPercentage}%</span>
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">
                              {ratio.ingredient.pyramid === "Top" && "Top note - provides initial impression"}
                              {ratio.ingredient.pyramid === "Heart" && "Heart note - forms the core character"}
                              {ratio.ingredient.pyramid === "Base" && "Base note - provides longevity and depth"}
                            </p>
                          </div>
                        ))}
                      </div>

                      <div className="bg-muted p-3 rounded-md mt-4">
                        <h4 className="text-sm font-medium mb-1">Pyramid Balance Guide</h4>
                        <p className="text-xs text-muted-foreground">
                          For a well-balanced fragrance, aim for approximately:
                          <br />
                          • Top notes: 20-30% (first impression, volatile)
                          <br />
                          • Heart notes: 40-60% (main character)
                          <br />
                          • Base notes: 10-20% (longevity and depth)
                        </p>
                      </div>
                    </>
                  )}
                </TabsContent>
              </>
            )}
          </Tabs>
        )}
      </CardContent>
    </Card>
  );
}