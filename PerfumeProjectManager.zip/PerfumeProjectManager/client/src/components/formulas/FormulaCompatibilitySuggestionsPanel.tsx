import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { getFormulaCompatibilitySuggestions, analyzeFormulaInteractions } from '@/lib/api';
import { 
  Ingredient, 
  FormulaCompatibilitySuggestions,
  FormulaAnalysis
} from '@/lib/types';
import { 
  Check, 
  AlertTriangle, 
  PlusCircle, 
  RefreshCw,
  ArrowRight, 
  Lightbulb
} from 'lucide-react';

interface FormulaCompatibilitySuggestionsPanelProps {
  formulaId: number;
  onAddIngredient?: (ingredient: Ingredient) => void;
  onRefreshAnalysis?: () => void;
}

export function FormulaCompatibilitySuggestionsPanel({ 
  formulaId,
  onAddIngredient,
  onRefreshAnalysis
}: FormulaCompatibilitySuggestionsPanelProps) {
  const [activeTab, setActiveTab] = useState('suggestions');
  const [suggestions, setSuggestions] = useState<FormulaCompatibilitySuggestions | null>(null);
  const [analysis, setAnalysis] = useState<FormulaAnalysis | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const fetchData = async () => {
    if (!formulaId) return;
    
    setIsLoading(true);
    setError(null);

    try {
      // Fetch formula compatibility suggestions
      const suggestionsData = await getFormulaCompatibilitySuggestions(formulaId);
      setSuggestions(suggestionsData);
      
      // Fetch formula interactions analysis
      const analysisData = await analyzeFormulaInteractions(formulaId);
      setAnalysis(analysisData);
    } catch (err) {
      console.error('Error fetching formula compatibility data:', err);
      setError('Failed to analyze formula compatibility');
      toast({
        title: 'Error',
        description: 'Failed to analyze formula compatibility',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch data when formula ID changes
  useEffect(() => {
    fetchData();
  }, [formulaId, toast]);

  // Helper function to handle adding an ingredient
  const handleAddIngredient = (ingredient: Ingredient) => {
    if (onAddIngredient) {
      onAddIngredient(ingredient);
      toast({
        title: 'Ingredient Added',
        description: `${ingredient.name} has been added to the formula`,
      });
    }
  };

  // Helper function to handle refresh
  const handleRefresh = () => {
    fetchData();
    if (onRefreshAnalysis) {
      onRefreshAnalysis();
    }
    toast({
      title: 'Analysis Refreshed',
      description: 'Formula compatibility analysis has been updated',
    });
  };

  // Helper function to get a color based on compatibility score
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'bg-green-500 text-white';
    if (score >= 60) return 'bg-green-300';
    if (score >= 40) return 'bg-yellow-400';
    if (score >= 20) return 'bg-orange-400 text-white';
    return 'bg-red-500 text-white';
  };

  // Helper function to calculate balance status
  const getBalanceStatus = (current: number, recommended: number) => {
    const difference = current - recommended;
    const threshold = 5; // 5% threshold for "balanced"
    
    if (Math.abs(difference) <= threshold) {
      return { status: 'Balanced', color: 'text-green-500' };
    } else if (difference > 0) {
      return { status: 'Too High', color: 'text-red-500' };
    } else {
      return { status: 'Too Low', color: 'text-blue-500' };
    }
  };

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>AI-Powered Formula Analysis</CardTitle>
          <CardDescription>
            Advanced insights and suggestions for your formula
          </CardDescription>
        </div>
        <Button variant="outline" size="sm" onClick={handleRefresh}>
          <RefreshCw className="h-4 w-4 mr-1" />
          Refresh
        </Button>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="h-40 flex items-center justify-center">
            <div className="text-center">
              <div className="animate-spin h-6 w-6 border-2 border-primary border-t-transparent rounded-full mx-auto mb-2"></div>
              <p className="text-sm text-muted-foreground">Analyzing formula...</p>
            </div>
          </div>
        ) : error ? (
          <div className="p-4 text-center text-red-500">{error}</div>
        ) : (
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full mb-4">
              <TabsTrigger value="suggestions" className="flex-1">Top Suggestions</TabsTrigger>
              <TabsTrigger value="balance" className="flex-1">Balance Analysis</TabsTrigger>
              <TabsTrigger value="analysis" className="flex-1">Formula Analysis</TabsTrigger>
            </TabsList>

            <TabsContent value="suggestions" className="space-y-4">
              {suggestions?.topSuggestions && suggestions.topSuggestions.length > 0 ? (
                <>
                  <h3 className="text-lg font-medium mb-2">Recommended Ingredients</h3>
                  <div className="space-y-3 max-h-[350px] overflow-y-auto">
                    {suggestions.topSuggestions.map((suggestion, index) => (
                      <div key={index} className="flex items-start p-3 border rounded-md">
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-medium">{suggestion.ingredient.name}</span>
                            <div className="flex items-center">
                              <Badge 
                                className={getScoreColor(suggestion.compatibilityScore)}
                              >
                                {suggestion.compatibilityScore}%
                              </Badge>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => handleAddIngredient(suggestion.ingredient)}
                              >
                                <PlusCircle className="h-4 w-4 mr-1" />
                                Add
                              </Button>
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground">{suggestion.reason}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {suggestions.substitutionOptions && suggestions.substitutionOptions.substitutes?.length > 0 && (
                    <>
                      <Separator className="my-4" />

                      <div className="p-3 border rounded-md">
                        <h3 className="text-md font-medium mb-2">
                          <span className="flex items-center">
                            <Lightbulb className="h-4 w-4 mr-1 text-amber-500" />
                            Substitution Options
                          </span>
                        </h3>
                        <p className="text-sm text-muted-foreground mb-2">
                          Consider these substitutes for {suggestions.substitutionOptions.originalIngredient.name}:
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {suggestions.substitutionOptions.substitutes.map((item, i) => (
                            <Badge 
                              key={i} 
                              variant="outline"
                              className="cursor-pointer hover:bg-accent flex items-center"
                              onClick={() => handleAddIngredient(item.ingredient)}
                            >
                              {item.ingredient.name}
                              <PlusCircle className="h-3 w-3 ml-1" />
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </>
                  )}
                </>
              ) : (
                <div className="p-4 text-center text-muted-foreground">
                  No suggestions available for this formula
                </div>
              )}
            </TabsContent>

            <TabsContent value="balance" className="space-y-4">
              {suggestions?.balanceRecommendations && suggestions.balanceRecommendations.length > 0 ? (
                <>
                  <h3 className="text-lg font-medium mb-2">Formula Balance Analysis</h3>
                  <div className="space-y-4">
                    {suggestions.balanceRecommendations.map((item, index) => {
                      const balanceStatus = getBalanceStatus(item.currentPercentage, item.recommendedPercentage);
                      return (
                        <div key={index} className="space-y-1">
                          <div className="flex items-center justify-between">
                            <span className="font-medium">{item.category}</span>
                            <span className={`text-sm font-medium ${balanceStatus.color}`}>
                              {balanceStatus.status}
                            </span>
                          </div>
                          <div className="flex items-start">
                            <div className="flex-1">
                              <Progress 
                                value={item.currentPercentage} 
                                max={100}
                                className="h-2 mb-1" 
                              />
                              <div className="flex justify-between text-xs text-muted-foreground">
                                <span>Current: {item.currentPercentage}%</span>
                                <span>Recommended: {item.recommendedPercentage}%</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className="bg-muted p-3 rounded-md mt-4">
                    <h4 className="text-sm font-medium mb-1">Balance Guide</h4>
                    <p className="text-xs text-muted-foreground">
                      For a well-balanced fragrance, consider:
                      <br />
                      • Top notes (20-30%): Create first impressions, more volatile
                      <br />
                      • Heart notes (40-60%): Form the core character of the fragrance
                      <br />
                      • Base notes (10-20%): Provide longevity, depth, and fixation
                    </p>
                  </div>
                </>
              ) : (
                <div className="p-4 text-center text-muted-foreground">
                  No balance recommendations available
                </div>
              )}
            </TabsContent>

            <TabsContent value="analysis" className="space-y-4">
              {analysis ? (
                <>
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-medium">Interaction Score</h3>
                      <p className="text-sm text-muted-foreground">
                        Overall ingredient harmony
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="text-2xl font-bold">{analysis.interactionScore}/100</span>
                    </div>
                  </div>
                  <Progress 
                    value={analysis.interactionScore} 
                    className={`h-2 mb-6 ${analysis.interactionScore >= 70 ? 'bg-green-500' : analysis.interactionScore >= 40 ? 'bg-yellow-400' : 'bg-red-500'}`} 
                  />

                  {analysis.conflicts.length > 0 && (
                    <>
                      <h3 className="text-lg font-medium mb-2">
                        <span className="flex items-center">
                          <AlertTriangle className="h-4 w-4 mr-1 text-red-500" />
                          Conflicts
                        </span>
                      </h3>
                      <div className="space-y-3 max-h-[150px] overflow-y-auto mb-4">
                        {analysis.conflicts.map((conflict, index) => (
                          <div key={index} className="flex items-start p-3 border border-red-200 bg-red-50 rounded-md">
                            <div className="flex-1">
                              <div className="flex items-center mb-1">
                                <span className="font-medium">{conflict.ingredientA.name}</span>
                                <ArrowRight className="h-3 w-3 mx-1" />
                                <span className="font-medium">{conflict.ingredientB.name}</span>
                              </div>
                              <p className="text-sm text-red-600">{conflict.effect}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </>
                  )}

                  {analysis.enhancements.length > 0 && (
                    <>
                      <h3 className="text-lg font-medium mb-2">
                        <span className="flex items-center">
                          <Check className="h-4 w-4 mr-1 text-green-500" />
                          Enhancements
                        </span>
                      </h3>
                      <div className="space-y-3 max-h-[150px] overflow-y-auto">
                        {analysis.enhancements.map((enhancement, index) => (
                          <div key={index} className="flex items-start p-3 border border-green-200 bg-green-50 rounded-md">
                            <div className="flex-1">
                              <div className="flex items-center mb-1">
                                <span className="font-medium">{enhancement.ingredientA.name}</span>
                                <ArrowRight className="h-3 w-3 mx-1" />
                                <span className="font-medium">{enhancement.ingredientB.name}</span>
                              </div>
                              <p className="text-sm text-green-600">{enhancement.effect}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </>
                  )}

                  {analysis.conflicts.length === 0 && analysis.enhancements.length === 0 && (
                    <div className="p-4 text-center text-muted-foreground">
                      No significant interactions detected between the ingredients
                    </div>
                  )}
                </>
              ) : (
                <div className="p-4 text-center text-muted-foreground">
                  No analysis data available
                </div>
              )}
            </TabsContent>
          </Tabs>
        )}
      </CardContent>
    </Card>
  );
}