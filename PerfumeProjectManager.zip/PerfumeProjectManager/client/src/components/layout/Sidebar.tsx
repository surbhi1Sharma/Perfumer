import { useState } from "react";
import { Link, useLocation } from "wouter";

interface SubmenuItem {
  path: string;
  label: string;
}

interface MenuItem {
  label: string;
  icon: string;
  path: string;
  submenu?: SubmenuItem[];
}

const Sidebar = () => {
  const [location] = useLocation();
  const [expandedMenus, setExpandedMenus] = useState<string[]>([]);

  const menuItems: MenuItem[] = [
    {
      label: "Dashboard",
      icon: "dashboard",
      path: "/",
    },
    {
      label: "My Menu",
      icon: "menu",
      path: "/my-menu",
    },
    {
      label: "Tasks",
      icon: "task",
      path: "/tasks",
    },
    {
      label: "Recent Work",
      icon: "update",
      path: "/recent-work",
    },
    {
      label: "Resources",
      icon: "inventory",
      path: "/resources",
      submenu: [
        { path: "/resources/search", label: "Search Resource" },
        { path: "/resources/request", label: "Request Resource" },
        { path: "/resources/my-requests", label: "My Requested Resources" },
        { path: "/resources/import", label: "Import Acquisition Resources" },
      ],
    },
    {
      label: "Formula Management",
      icon: "calculate",
      path: "/formulas",
      submenu: [
        { path: "/formulas/search", label: "Search Formula" },
        { path: "/formulas/customer-import", label: "Customer Formula Import" },
        { path: "/formulas/acquisition-import", label: "Acquisition Import" },
        { path: "/formulas/potpourri-creation", label: "Potpurri Formula Creation" },
        { path: "/formulas/request-bases", label: "Raise Request for Bases" },
        { path: "/formulas/flavor-visualization", label: "Flavor Visualization" },
      ],
    },
    {
      label: "User Management",
      icon: "people",
      path: "/users",
    },
    {
      label: "Marketing",
      icon: "trending_up",
      path: "/marketing",
    },
    {
      label: "PPD",
      icon: "settings",
      path: "/ppd",
    },
  ];

  const toggleSubmenu = (label: string) => {
    setExpandedMenus((prev) => {
      if (prev.includes(label)) {
        return prev.filter((item) => item !== label);
      } else {
        return [...prev, label];
      }
    });
  };

  const isActive = (path: string): boolean => {
    if (path === "/" && location === "/") return true;
    if (path !== "/" && location.startsWith(path)) return true;
    return false;
  };

  return (
    <aside className="w-64 h-full bg-white shadow-md flex-shrink-0 fixed top-0 left-0 z-10 flex flex-col">
      <div className="p-4 border-b flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <span className="material-icons text-primary">spa</span>
          <span className="text-lg font-medium text-primary">AromaSuite</span>
        </div>
        <button className="md:hidden text-gray-500 hover:text-gray-700">
          <span className="material-icons">menu</span>
        </button>
      </div>
      
      <div className="overflow-y-auto flex-grow">
        <nav className="mt-2">
          {menuItems.map((item) => (
            <div key={item.label} className="sidebar-menu">
              {item.submenu ? (
                <div className="flex flex-col">
                  <div
                    className={`sidebar-link flex items-center justify-between px-4 py-3 text-gray-700 hover:bg-gray-100 cursor-pointer ${isActive(item.path) ? "active bg-gray-100 border-l-3 border-primary" : ""}`}
                    onClick={() => toggleSubmenu(item.label)}
                  >
                    <div className="flex items-center">
                      <span className="material-icons mr-3 text-gray-500">{item.icon}</span>
                      <span>{item.label}</span>
                    </div>
                    <span
                      className={`material-icons text-gray-500 transform transition-transform duration-200 ${expandedMenus.includes(item.label) ? "rotate-180" : ""}`}
                    >
                      expand_more
                    </span>
                  </div>
                  <div
                    className={`sidebar-submenu pl-12 bg-gray-50 overflow-hidden transition-all duration-300 ${expandedMenus.includes(item.label) ? "max-h-60" : "max-h-0"}`}
                  >
                    {item.submenu.map((subitem) => (
                      <Link
                        key={subitem.path}
                        href={subitem.path}
                        className={`block py-2 px-4 text-sm text-gray-600 hover:text-primary ${location === subitem.path ? "text-primary font-medium" : ""}`}
                      >
                        {subitem.label}
                      </Link>
                    ))}
                  </div>
                </div>
              ) : (
                <Link
                  href={item.path}
                  className={`sidebar-link flex items-center px-4 py-3 text-gray-700 hover:bg-gray-100 ${isActive(item.path) ? "active bg-gray-100 border-l-3 border-primary" : ""}`}
                >
                  <span className="material-icons mr-3 text-gray-500">{item.icon}</span>
                  <span>{item.label}</span>
                </Link>
              )}
            </div>
          ))}
        </nav>
      </div>
      
      <div className="p-4 border-t">
        <div className="flex items-center">
          <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center text-white mr-3">
            <span className="material-icons text-sm">person</span>
          </div>
          <div>
            <p className="text-sm font-medium">Sophia Chen</p>
            <p className="text-xs text-gray-500">Senior Perfumer</p>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
