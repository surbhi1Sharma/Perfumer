import { ReactNode } from "react";
import Sidebar from "./Sidebar";
import Header from "./Header";
import { useLocation } from "wouter";

interface LayoutProps {
  children: ReactNode;
}

const getPageTitle = (path: string): string => {
  const pathSegments = path.split("/").filter(Boolean);
  if (pathSegments.length === 0) return "Dashboard";
  
  const mainSegment = pathSegments[0];
  const subSegment = pathSegments[1];
  
  switch (mainSegment) {
    case "my-menu":
      return "My Menu";
    case "tasks":
      return "Tasks";
    case "recent-work":
      return "Recent Work";
    case "resources":
      if (subSegment === "search") return "Search Resources";
      if (subSegment === "request") return "Request Resources";
      if (subSegment === "my-requests") return "My Requested Resources";
      if (subSegment === "import") return "Import Acquisition Resources";
      return "Resources";
    case "formulas":
      if (subSegment === "search") return "Search Formulas";
      if (subSegment === "customer-import") return "Customer Formula Import";
      if (subSegment === "acquisition-import") return "Acquisition Import";
      if (subSegment === "potpourri-creation") return "Potpourri Formula Creation";
      if (subSegment === "request-bases") return "Raise Request for Bases";
      return "Formula Management";
    case "projects":
      if (subSegment === "create") return "Create Project";
      if (subSegment === "search") return "Search Projects";
      return "Project Management";
    case "marketing":
      return "Marketing";
    case "ppd":
      return "PPD";
    default:
      return "Dashboard";
  }
};

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [location] = useLocation();
  const pageTitle = getPageTitle(location);

  return (
    <div className="flex h-screen overflow-hidden bg-gray-100">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden ml-64">
        <Header title={pageTitle} />
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100">
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;
