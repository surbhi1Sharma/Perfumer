import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Bell, Search, HelpCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface HeaderProps {
  title: string;
}

const Header = ({ title }: HeaderProps) => {
  return (
    <header className="bg-white shadow-sm">
      <div className="px-6 py-4 flex items-center justify-between">
        <h1 className="text-xl font-medium text-gray-800">{title}</h1>
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              type="text"
              placeholder="Search..."
              className="pl-10 pr-4 py-2 w-64"
            />
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            className="relative rounded-full"
          >
            <Bell className="h-5 w-5 text-gray-600" />
            <Badge 
              className="absolute top-0 right-0 h-4 w-4 p-0 flex items-center justify-center bg-destructive text-white text-xs rounded-full"
            >
              3
            </Badge>
          </Button>
          <Button variant="ghost" size="icon" className="rounded-full">
            <HelpCircle className="h-5 w-5 text-gray-600" />
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;
