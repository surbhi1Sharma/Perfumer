import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Layout from "@/components/layout/Layout";
import Dashboard from "@/pages/dashboard";
import MyMenu from "@/pages/my-menu";
import Tasks from "@/pages/tasks";
import RecentWork from "@/pages/recent-work";
import Resources from "@/pages/resources";
import ResourceSearch from "@/pages/resources/search";
import ResourceRequest from "@/pages/resources/request";
import NewResourceRequestPopup from "@/pages/resources/new-request-popup";
import MyResourceRequests from "@/pages/resources/my-requests";
import ResourceImport from "@/pages/resources/import";
import Formulas from "@/pages/formulas";
import FormulaSearch from "@/pages/formulas/search";
import CustomerFormulaImport from "@/pages/formulas/customer-import";
import AcquisitionImport from "@/pages/formulas/acquisition-import";
import PotpourriCreation from "@/pages/formulas/potpourri-creation";
import RequestBases from "@/pages/formulas/request-bases";
import FlavorVisualization from "@/pages/formulas/flavor-visualization";
import Projects from "@/pages/projects";
import CreateProject from "@/pages/projects/create";
import SearchProject from "@/pages/projects/search";
import UserManagement from "@/pages/users";
import Marketing from "@/pages/marketing";
import PPD from "@/pages/ppd";

function Router() {
  return (
    <Layout>
      <Switch>
        {/* Main Routes */}
        <Route path="/" component={Dashboard} />
        <Route path="/my-menu" component={MyMenu} />
        <Route path="/tasks" component={Tasks} />
        <Route path="/recent-work" component={RecentWork} />
        
        {/* Resource Routes */}
        <Route path="/resources" component={Resources} />
        <Route path="/resources/search" component={ResourceSearch} />
        <Route path="/resources/request" component={ResourceRequest} />
        <Route path="/resources/new-request-popup" component={NewResourceRequestPopup} />
        <Route path="/resources/my-requests" component={MyResourceRequests} />
        <Route path="/resources/import" component={ResourceImport} />
        
        {/* Formula Routes */}
        <Route path="/formulas" component={Formulas} />
        <Route path="/formulas/search" component={FormulaSearch} />
        <Route path="/formulas/customer-import" component={CustomerFormulaImport} />
        <Route path="/formulas/acquisition-import" component={AcquisitionImport} />
        <Route path="/formulas/potpourri-creation" component={PotpourriCreation} />
        <Route path="/formulas/request-bases" component={RequestBases} />
        <Route path="/formulas/flavor-visualization" component={FlavorVisualization} />
        
        {/* Project Routes */}
        <Route path="/projects" component={Projects} />
        <Route path="/projects/create" component={CreateProject} />
        <Route path="/projects/search" component={SearchProject} />
        
        {/* User Management Routes */}
        <Route path="/users" component={UserManagement} />
        
        {/* Other Routes */}
        <Route path="/marketing" component={Marketing} />
        <Route path="/ppd" component={PPD} />

        {/* Fallback to 404 */}
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
