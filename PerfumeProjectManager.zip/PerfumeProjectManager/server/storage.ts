import {
  users,
  resources,
  resourceRequests,
  formulas,
  baseRequests,
  projects,
  tasks,
  resourceAllocations,
  resourceTransactions,
  resourceThresholds,
  ingredients,
  ingredientInteractions,
  PERMISSIONS,
  type User,
  type InsertUser,
  type Resource,
  type InsertResource,
  type ResourceRequest,
  type InsertResourceRequest,
  type Formula,
  type InsertFormula,
  type BaseRequest,
  type InsertBaseRequest,
  type Project,
  type InsertProject,
  type Task,
  type InsertTask,
  type ResourceAllocation,
  type InsertResourceAllocation,
  type ResourceTransaction,
  type InsertResourceTransaction,
  type ResourceThreshold,
  type InsertResourceThreshold,
  type Ingredient,
  type InsertIngredient,
  type IngredientInteraction,
  type InsertIngredientInteraction,
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  getAllUsers(): Promise<User[]>;
  getUsersByTeam(team: string): Promise<User[]>;
  updateUserPermissions(id: number, permissions: string[]): Promise<User | undefined>;
  updateUserLastLogin(id: number): Promise<User | undefined>;

  // Resource operations
  getResource(id: number): Promise<Resource | undefined>;
  getAllResources(): Promise<Resource[]>;
  searchResources(query: string): Promise<Resource[]>;
  createResource(resource: InsertResource): Promise<Resource>;
  updateResource(id: number, resource: Partial<InsertResource>): Promise<Resource | undefined>;
  
  // Resource Request operations
  getResourceRequest(id: number): Promise<ResourceRequest | undefined>;
  createResourceRequest(request: InsertResourceRequest): Promise<ResourceRequest>;
  getUserResourceRequests(userId: number): Promise<ResourceRequest[]>;
  updateResourceRequestStatus(id: number, status: string): Promise<ResourceRequest | undefined>;
  getAllResourceRequests(): Promise<ResourceRequest[]>;

  // Ingredient operations
  getIngredient(id: number): Promise<Ingredient | undefined>;
  getIngredientByCasNumber(casNumber: string): Promise<Ingredient | undefined>;
  getAllIngredients(): Promise<Ingredient[]>;
  searchIngredients(query: string): Promise<Ingredient[]>;
  createIngredient(ingredient: InsertIngredient): Promise<Ingredient>;
  updateIngredient(id: number, ingredient: Partial<InsertIngredient>): Promise<Ingredient | undefined>;
  getIngredientsByCategory(category: string): Promise<Ingredient[]>;
  getIngredientsByPyramid(pyramid: string): Promise<Ingredient[]>;
  
  // Ingredient Interaction operations
  getIngredientInteraction(id: number): Promise<IngredientInteraction | undefined>;
  createIngredientInteraction(interaction: InsertIngredientInteraction): Promise<IngredientInteraction>;
  getInteractionsBetweenIngredients(ingredientAId: number, ingredientBId: number): Promise<IngredientInteraction[]>;
  getInteractionsForIngredient(ingredientId: number): Promise<IngredientInteraction[]>;
  getConflictingIngredients(ingredientIds: number[]): Promise<{ingredient: Ingredient, conflictsWith: Ingredient, interaction: IngredientInteraction}[]>;
  getSuggestedIngredients(ingredientIds: number[]): Promise<{ingredient: Ingredient, reason: string, strengthLevel: number}[]>;

  // Formula operations
  getFormula(id: number): Promise<Formula | undefined>;
  getAllFormulas(): Promise<Formula[]>;
  searchFormulas(query: string): Promise<Formula[]>;
  createFormula(formula: InsertFormula): Promise<Formula>;
  updateFormula(id: number, formula: Partial<InsertFormula>): Promise<Formula | undefined>;
  getFormulaVersions(parentFormulaId: number): Promise<Formula[]>;
  analyzeFormulaInteractions(formulaId: number): Promise<{
    interactionScore: number;
    conflicts: {ingredientA: Ingredient, ingredientB: Ingredient, effect: string}[];
    enhancements: {ingredientA: Ingredient, ingredientB: Ingredient, effect: string}[];
    suggestions: {ingredient: Ingredient, purpose: string}[];
  }>;
  calculateFormulaProperties(formulaId: number): Promise<Record<string, any>>;

  // Base Request operations
  getBaseRequest(id: number): Promise<BaseRequest | undefined>;
  createBaseRequest(request: InsertBaseRequest): Promise<BaseRequest>;
  getUserBaseRequests(userId: number): Promise<BaseRequest[]>;
  updateBaseRequestStatus(id: number, status: string): Promise<BaseRequest | undefined>;
  getAllBaseRequests(): Promise<BaseRequest[]>;

  // Project operations
  getProject(id: number): Promise<Project | undefined>;
  getAllProjects(): Promise<Project[]>;
  searchProjects(query: string): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<InsertProject>): Promise<Project | undefined>;

  // Task operations
  getTask(id: number): Promise<Task | undefined>;
  getAllTasks(): Promise<Task[]>;
  getUserTasks(userId: number): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: Partial<InsertTask>): Promise<Task | undefined>;
  updateTaskStatus(id: number, status: string): Promise<Task | undefined>;
  getProjectTasks(projectId: number): Promise<Task[]>;

  // Resource Allocation operations
  getResourceAllocation(id: number): Promise<ResourceAllocation | undefined>;
  createResourceAllocation(allocation: InsertResourceAllocation): Promise<ResourceAllocation>;
  updateResourceAllocationStatus(id: number, status: string): Promise<ResourceAllocation | undefined>;
  getResourceAllocations(filters?: {
    resourceId?: number;
    projectId?: number;
    formulaId?: number;
    userId?: number;
    status?: string;
  }): Promise<ResourceAllocation[]>;
  
  // Resource Transaction operations
  getResourceTransaction(id: number): Promise<ResourceTransaction | undefined>;
  createResourceTransaction(transaction: InsertResourceTransaction): Promise<ResourceTransaction>;
  getResourceTransactions(filters?: {
    resourceId?: number;
    userId?: number;
    transactionType?: string;
    startDate?: Date;
    endDate?: Date;
  }): Promise<ResourceTransaction[]>;
  getResourceTransactionHistory(resourceId: number): Promise<ResourceTransaction[]>;
  
  // Resource Threshold operations
  getResourceThreshold(id: number): Promise<ResourceThreshold | undefined>;
  getResourceThresholdByResourceId(resourceId: number): Promise<ResourceThreshold | undefined>;
  createResourceThreshold(threshold: InsertResourceThreshold): Promise<ResourceThreshold>;
  updateResourceThreshold(id: number, threshold: Partial<InsertResourceThreshold>): Promise<ResourceThreshold | undefined>;
  getResourcesWithLowStock(): Promise<{resource: Resource; threshold: ResourceThreshold}[]>;
  
  // AI-powered compatibility and suggestions
  analyzeIngredientsCompatibility(ingredientIds: number[]): Promise<{
    overallScore: number;
    compatibilityMatrix: {
      ingredientA: Ingredient,
      ingredientB: Ingredient,
      score: number,
      effect: string,
      interactionType: string
    }[];
    recommendedRatios: {
      ingredient: Ingredient,
      minPercentage: number,
      maxPercentage: number,
      optimalPercentage: number
    }[];
  }>;
  
  getAdvancedIngredientSuggestions(
    ingredientIds: number[], 
    filters?: {
      category?: string;
      pyramid?: string;
    }
  ): Promise<{
    suggestions: {
      ingredient: Ingredient,
      compatibilityScore: number,
      reason: string,
      usageNotes: string
    }[];
    alternativeGroups: {
      category: string,
      options: Ingredient[]
    }[];
  }>;
  
  getFormulaCompatibilitySuggestions(formulaId: number): Promise<{
    topSuggestions: {ingredient: Ingredient, reason: string, compatibilityScore: number}[];
    balanceRecommendations: {category: string, currentPercentage: number, recommendedPercentage: number}[];
    substitutionOptions: {originalIngredient: Ingredient, substitutes: {ingredient: Ingredient, reason: string}[]};
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private resources: Map<number, Resource>;
  private resourceRequests: Map<number, ResourceRequest>;
  private formulas: Map<number, Formula>;
  private baseRequests: Map<number, BaseRequest>;
  private projects: Map<number, Project>;
  private tasks: Map<number, Task>;
  private resourceAllocations: Map<number, ResourceAllocation>;
  private resourceTransactions: Map<number, ResourceTransaction>;
  private resourceThresholds: Map<number, ResourceThreshold>;
  private ingredients: Map<number, Ingredient>;
  private ingredientInteractions: Map<number, IngredientInteraction>;
  
  private userIdCounter: number;
  private resourceIdCounter: number;
  private resourceRequestIdCounter: number;
  private formulaIdCounter: number;
  private baseRequestIdCounter: number;
  private projectIdCounter: number;
  private taskIdCounter: number;
  private resourceAllocationIdCounter: number;
  private resourceTransactionIdCounter: number;
  private resourceThresholdIdCounter: number;
  private ingredientIdCounter: number;
  private ingredientInteractionIdCounter: number;

  constructor() {
    this.users = new Map();
    this.resources = new Map();
    this.resourceRequests = new Map();
    this.formulas = new Map();
    this.baseRequests = new Map();
    this.projects = new Map();
    this.tasks = new Map();
    this.resourceAllocations = new Map();
    this.resourceTransactions = new Map();
    this.resourceThresholds = new Map();
    this.ingredients = new Map();
    this.ingredientInteractions = new Map();
    
    this.userIdCounter = 1;
    this.resourceIdCounter = 1;
    this.resourceRequestIdCounter = 1;
    this.formulaIdCounter = 1;
    this.baseRequestIdCounter = 1;
    this.projectIdCounter = 1;
    this.taskIdCounter = 1;
    this.resourceAllocationIdCounter = 1;
    this.resourceTransactionIdCounter = 1;
    this.resourceThresholdIdCounter = 1;
    this.ingredientIdCounter = 1;
    this.ingredientInteractionIdCounter = 1;

    // Initialize with a default admin user
    this.createUser({
      username: "admin",
      password: "admin123",
      fullName: "Sophia Chen",
      role: "Admin",
      team: "Admin",
      email: "sophia@aromasuite.com",
      department: "R&D",
      permissions: Object.values(PERMISSIONS),
      isActive: true
    });

    // Add sample resources with extended fields
    // First create the resources
    this.createResource({
      code: "FR-V-001",
      name: "Vanilla Extract",
      category: "Natural Extract",
      type: "Base",
      description: "Premium vanilla extract for perfume creation",
      quantity: 250,
      unit: "ml",
      costPerUnit: 85,
      currency: "USD",
      supplier: "Vanilla Co.",
      status: "Active",
      pyramid: 1,
      odour: "Sweet",
      notes: "High quality Madagascar vanilla"
    });

    this.createResource({
      code: "FR-J-002",
      name: "Jasmine Essential Oil",
      category: "Essential Oil",
      type: "Top Note",
      description: "Pure jasmine essential oil",
      quantity: 100,
      unit: "ml",
      costPerUnit: 120,
      currency: "EUR",
      supplier: "Floral Essentials",
      status: "Active",
      pyramid: 2,
      odour: "Floral",
      notes: "Best for floral perfumes"
    });

    this.createResource({
      code: "FR-A-003",
      name: "Amber Base",
      category: "Synthetic Base",
      type: "Base Note",
      description: "Amber synthetic base for longevity",
      quantity: 500,
      unit: "ml",
      costPerUnit: 65,
      currency: "USD",
      supplier: "SynthAroma",
      status: "Inactive",
      pyramid: 3,
      odour: "Woody",
      notes: "Warm and long-lasting"
    });
    
    // Set up inventory thresholds for resources
    this.createResourceThreshold({
      resourceId: 1, // Vanilla resource ID
      minimumLevel: "100",
      targetLevel: "300",
      alertEnabled: true,
      alertMessage: "Vanilla Extract stock is low. Please reorder from Vanilla Co.",
      createdBy: 1 // Admin user
    });
    
    this.createResourceThreshold({
      resourceId: 2, // Jasmine resource ID
      minimumLevel: "50",
      targetLevel: "150",
      alertEnabled: true,
      alertMessage: "Jasmine Essential Oil stock is low. Please reorder from Floral Essentials.",
      createdBy: 1 // Admin user
    });
    
    this.createResourceThreshold({
      resourceId: 3, // Amber resource ID
      minimumLevel: "200",
      targetLevel: "600",
      alertEnabled: true,
      alertMessage: "Amber Base stock is low. Please reorder from SynthAroma.",
      createdBy: 1 // Admin user
    });
    
    // Add sample projects
    this.createProject({
      name: "Spring Blossom Collection",
      client: "Fleur de Parfum",
      description: "New collection for Spring 2025 featuring floral notes",
      startDate: new Date("2025-01-15"),
      dueDate: new Date("2025-04-30"),
      status: "In Progress",
      stage: "Development",
      manager: 1, // Admin user ID
      team: ["R&D team"],
      notes: "Priority: High"
    });
    
    this.createProject({
      name: "Autumn Woods Fragrance",
      client: "Naturelle Scents",
      description: "Woody and amber fragrance for autumn season",
      startDate: new Date("2025-03-01"),
      dueDate: new Date("2025-08-15"),
      status: "Planning",
      stage: "Initial",
      manager: 1, // Admin user ID
      team: ["R&D team", "Perfumer team"],
      notes: "Priority: Medium"
    });
    
    // Add sample formulas
    this.createFormula({
      name: "Vanilla Dream",
      category: "Perfume",
      type: "EDP",
      status: "Active",
      createdBy: 1, // Admin user
      composition: [{ingredient: "Vanilla Extract", percentage: 18}, {ingredient: "Jasmine", percentage: 5}],
      description: "Sweet vanilla base with floral heart notes"
    });
    
    this.createFormula({
      name: "Amber Woods",
      category: "Perfume",
      type: "EDT",
      status: "Development",
      createdBy: 1, // Admin user
      composition: [{ingredient: "Amber Base", percentage: 12}, {ingredient: "Sandalwood", percentage: 8}],
      description: "Warm amber with woody undertones"
    });
    
    // Create some resource allocations
    this.createResourceAllocation({
      resourceId: 1, // Vanilla resource
      quantity: "50",
      userId: 1, // Admin user
      formulaId: 1, // Vanilla Dream formula
      status: "allocated",
      dueDate: new Date("2025-02-15"),
      notes: "For formula development"
    });
    
    this.createResourceAllocation({
      resourceId: 3, // Amber resource
      quantity: "75",
      userId: 1, // Admin user
      projectId: 2, // Autumn Woods project
      status: "allocated",
      dueDate: new Date("2025-04-01"),
      notes: "For initial prototype"
    });
    
    // Create some tasks
    this.createTask({
      title: "Develop Vanilla Dream prototype",
      description: "Create initial prototype for Vanilla Dream formula",
      assignedTo: 1, // Admin user
      priority: "high",
      dueDate: new Date("2025-02-20"),
      projectId: 1, // Spring Blossom project
    });
    
    this.createTask({
      title: "Source additional jasmine oil",
      description: "We need more jasmine oil for upcoming projects",
      assignedTo: 1, // Admin user
      priority: "medium",
      dueDate: new Date("2025-01-30"),
    });
    
    // Add sample ingredients
    this.createIngredient({
      name: "Vanilla Extract",
      casNumber: "8024-06-4",
      category: "Natural Extract",
      pyramid: "Base",
      odorProfile: ["Sweet", "Balsamic", "Creamy"],
      concentration: "100%",
      solubility: "Alcohol soluble",
      flashPoint: "85°C",
      appearanceState: "Dark brown liquid",
      tenacity: "High",
      stability: "Stable",
      molecularWeight: "152.15",
      potency: "High",
      allergenInfo: ["None known"],
      restrictions: ["None"],
      incompatibleWith: [],
      substitutes: [],
      enhancedBy: [],
      recommendations: {}
    });
    
    this.createIngredient({
      name: "Jasmine Essential Oil",
      casNumber: "8022-96-6",
      category: "Essential Oil",
      pyramid: "Heart",
      odorProfile: ["Floral", "Sweet", "Exotic"],
      concentration: "100%",
      solubility: "Alcohol soluble",
      flashPoint: "60°C",
      appearanceState: "Clear yellow liquid",
      tenacity: "Medium",
      stability: "Moderate",
      molecularWeight: "136.23",
      potency: "High",
      allergenInfo: ["May cause sensitivity"],
      restrictions: ["Limited usage in leave-on products (IFRA)"],
      incompatibleWith: [],
      substitutes: [],
      enhancedBy: [],
      recommendations: {}
    });
    
    this.createIngredient({
      name: "Bergamot Oil",
      casNumber: "8007-75-8",
      category: "Citrus Oil",
      pyramid: "Top",
      odorProfile: ["Citrus", "Fresh", "Slightly Floral"],
      concentration: "100%",
      solubility: "Alcohol soluble",
      flashPoint: "52°C",
      appearanceState: "Light green-yellow liquid",
      tenacity: "Low",
      stability: "Moderate",
      molecularWeight: "154.25",
      potency: "Medium-high",
      allergenInfo: ["Phototoxic"],
      restrictions: ["IFRA restricted due to phototoxicity"],
      incompatibleWith: [],
      substitutes: [],
      enhancedBy: [],
      recommendations: {}
    });
    
    this.createIngredient({
      name: "Ambroxan",
      casNumber: "6790-58-5",
      category: "Synthetic Amber",
      pyramid: "Base",
      odorProfile: ["Amber", "Woody", "Musky"],
      concentration: "10%",
      solubility: "Oil soluble",
      flashPoint: "100°C",
      appearanceState: "White crystalline solid",
      tenacity: "Very high",
      stability: "Excellent",
      molecularWeight: "236.4",
      potency: "High",
      allergenInfo: ["None known"],
      restrictions: ["None"],
      incompatibleWith: [],
      substitutes: [],
      enhancedBy: [],
      recommendations: {}
    });
    
    this.createIngredient({
      name: "Sandalwood Oil",
      casNumber: "8006-87-9",
      category: "Essential Oil",
      pyramid: "Base",
      odorProfile: ["Woody", "Creamy", "Warm"],
      concentration: "100%",
      solubility: "Oil soluble",
      flashPoint: "77°C",
      appearanceState: "Pale yellow liquid",
      tenacity: "High",
      stability: "Good",
      molecularWeight: "200-250",
      potency: "Medium-high",
      allergenInfo: ["Rare skin sensitivity"],
      restrictions: ["Indian sandalwood is protected; use sustainable Australian variety"],
      incompatibleWith: [],
      substitutes: [],
      enhancedBy: [],
      recommendations: {}
    });
    
    // Add sample ingredient interactions
    this.createIngredientInteraction({
      ingredientAId: 1, // Vanilla
      ingredientBId: 2, // Jasmine
      interactionType: "Enhances",
      effect: "Vanilla softens and sweetens jasmine's exotic profile",
      strengthLevel: 85,
      notes: "Classic combination for oriental perfumes"
    });
    
    this.createIngredientInteraction({
      ingredientAId: 2, // Jasmine
      ingredientBId: 3, // Bergamot
      interactionType: "Enhances",
      effect: "Brightens jasmine and adds fresh top notes",
      strengthLevel: 70,
      notes: "Popular in floral-citrus compositions"
    });
    
    this.createIngredientInteraction({
      ingredientAId: 1, // Vanilla
      ingredientBId: 3, // Bergamot
      interactionType: "Conflicts",
      effect: "Can create an overly sweet, discordant note",
      strengthLevel: -40,
      notes: "Use with caution and in low percentages"
    });
    
    this.createIngredientInteraction({
      ingredientAId: 4, // Ambroxan
      ingredientBId: 5, // Sandalwood
      interactionType: "Enhances",
      effect: "Amplifies the woody notes and extends longevity",
      strengthLevel: 90,
      notes: "Excellent base note combination"
    });
    
    this.createIngredientInteraction({
      ingredientAId: 1, // Vanilla
      ingredientBId: 5, // Sandalwood
      interactionType: "Enhances",
      effect: "Creates a creamy, smooth woody foundation",
      strengthLevel: 80,
      notes: "Timeless combination for oriental fragrances"
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const lastLogin = user.isActive ? new Date() : null;
    const newUser: User = { 
      ...user, 
      id,
      lastLogin,
      // Ensure these are never undefined
      department: user.department || null,
      permissions: user.permissions || [],
      isActive: user.isActive !== undefined ? user.isActive : true
    };
    this.users.set(id, newUser);
    return newUser;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }
  
  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const existingUser = this.users.get(id);
    if (!existingUser) return undefined;
    
    const updatedUser: User = { ...existingUser, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async deleteUser(id: number): Promise<boolean> {
    if (!this.users.has(id)) return false;
    return this.users.delete(id);
  }
  
  async getUsersByTeam(team: string): Promise<User[]> {
    return Array.from(this.users.values()).filter(
      (user) => user.team === team
    );
  }
  
  async updateUserPermissions(id: number, permissions: string[]): Promise<User | undefined> {
    const existingUser = this.users.get(id);
    if (!existingUser) return undefined;
    
    const updatedUser: User = { ...existingUser, permissions };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async updateUserLastLogin(id: number): Promise<User | undefined> {
    const existingUser = this.users.get(id);
    if (!existingUser) return undefined;
    
    const now = new Date();
    const updatedUser: User = { ...existingUser, lastLogin: now };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Resource operations
  async getResource(id: number): Promise<Resource | undefined> {
    return this.resources.get(id);
  }

  async getAllResources(): Promise<Resource[]> {
    return Array.from(this.resources.values());
  }

  async searchResources(query: string): Promise<Resource[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.resources.values()).filter(
      (resource) => 
        resource.name.toLowerCase().includes(lowerQuery) ||
        resource.description?.toLowerCase().includes(lowerQuery) ||
        resource.category.toLowerCase().includes(lowerQuery) ||
        resource.type.toLowerCase().includes(lowerQuery)
    );
  }

  async createResource(resource: InsertResource): Promise<Resource> {
    const id = this.resourceIdCounter++;
    const now = new Date();
    const newResource: Resource = { 
      ...resource, 
      id, 
      createdAt: now,
      // Ensure required fields are not undefined
      description: resource.description || null,
      status: resource.status || null,
      notes: resource.notes || null,
      quantity: resource.quantity || null,
      unit: resource.unit || null,
      costPerUnit: resource.costPerUnit || null,
      currency: resource.currency || null,
      supplier: resource.supplier || null,
      pyramid: resource.pyramid || null,
      odour: resource.odour || null,
      code: resource.code || null
    };
    this.resources.set(id, newResource);
    return newResource;
  }

  async updateResource(id: number, resource: Partial<InsertResource>): Promise<Resource | undefined> {
    const existingResource = this.resources.get(id);
    if (!existingResource) return undefined;
    
    const updatedResource: Resource = { ...existingResource, ...resource };
    this.resources.set(id, updatedResource);
    return updatedResource;
  }

  // Resource Request operations
  async getResourceRequest(id: number): Promise<ResourceRequest | undefined> {
    return this.resourceRequests.get(id);
  }

  async createResourceRequest(request: InsertResourceRequest): Promise<ResourceRequest> {
    const id = this.resourceRequestIdCounter++;
    const now = new Date();
    const newRequest: ResourceRequest = { 
      ...request, 
      id, 
      status: "pending", 
      createdAt: now,
      resolvedAt: null,
      // Ensure required fields are not undefined
      reason: request.reason || null,
      customFields: request.customFields || null
    };
    this.resourceRequests.set(id, newRequest);
    return newRequest;
  }

  async getUserResourceRequests(userId: number): Promise<ResourceRequest[]> {
    return Array.from(this.resourceRequests.values()).filter(
      (request) => request.userId === userId
    );
  }

  async updateResourceRequestStatus(id: number, status: string): Promise<ResourceRequest | undefined> {
    const request = this.resourceRequests.get(id);
    if (!request) return undefined;
    
    const updatedRequest: ResourceRequest = { 
      ...request, 
      status,
      resolvedAt: status === 'approved' || status === 'rejected' ? new Date() : request.resolvedAt
    };
    
    this.resourceRequests.set(id, updatedRequest);
    return updatedRequest;
  }

  async getAllResourceRequests(): Promise<ResourceRequest[]> {
    return Array.from(this.resourceRequests.values());
  }

  // Formula operations
  async getFormula(id: number): Promise<Formula | undefined> {
    return this.formulas.get(id);
  }

  async getAllFormulas(): Promise<Formula[]> {
    return Array.from(this.formulas.values());
  }

  async searchFormulas(query: string): Promise<Formula[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.formulas.values()).filter(
      (formula) => 
        formula.name.toLowerCase().includes(lowerQuery) ||
        formula.description?.toLowerCase().includes(lowerQuery) ||
        formula.category.toLowerCase().includes(lowerQuery) ||
        formula.type.toLowerCase().includes(lowerQuery)
    );
  }

  async createFormula(formula: InsertFormula): Promise<Formula> {
    const id = this.formulaIdCounter++;
    const now = new Date();
    const newFormula: Formula = { 
      ...formula, 
      id, 
      createdAt: now,
      updatedAt: now,
      // Ensure required fields are not undefined
      description: formula.description || null,
      notes: formula.notes || null
    };
    this.formulas.set(id, newFormula);
    return newFormula;
  }

  async updateFormula(id: number, formula: Partial<InsertFormula>): Promise<Formula | undefined> {
    const existingFormula = this.formulas.get(id);
    if (!existingFormula) return undefined;
    
    const now = new Date();
    const updatedFormula: Formula = { 
      ...existingFormula, 
      ...formula,
      updatedAt: now
    };
    
    this.formulas.set(id, updatedFormula);
    return updatedFormula;
  }

  async getFormulaVersions(parentFormulaId: number): Promise<Formula[]> {
    return Array.from(this.formulas.values()).filter(
      (formula) => formula.parentFormulaId === parentFormulaId
    );
  }

  async analyzeFormulaInteractions(formulaId: number): Promise<{
    interactionScore: number;
    conflicts: {ingredientA: Ingredient, ingredientB: Ingredient, effect: string}[];
    enhancements: {ingredientA: Ingredient, ingredientB: Ingredient, effect: string}[];
    suggestions: {ingredient: Ingredient, purpose: string}[];
  }> {
    const formula = await this.getFormula(formulaId);
    if (!formula) {
      return {
        interactionScore: 0,
        conflicts: [],
        enhancements: [],
        suggestions: []
      };
    }

    // Extract ingredient IDs from formula composition
    const ingredientNames = formula.composition && Array.isArray(formula.composition) 
      ? (formula.composition as any[]).map(comp => comp.ingredient)
      : [];
    
    // Get all ingredients that match these names
    const allIngredients = await this.getAllIngredients();
    const formulaIngredients = allIngredients.filter(ing => 
      ingredientNames.includes(ing.name)
    );
    
    const ingredientIds = formulaIngredients.map(ing => ing.id);
    
    // Find conflicts
    const conflictItems = await this.getConflictingIngredients(ingredientIds);
    
    // Convert to the expected format
    const conflicts: {ingredientA: Ingredient, ingredientB: Ingredient, effect: string}[] = 
      conflictItems.map(item => ({
        ingredientA: item.ingredient,
        ingredientB: item.conflictsWith,
        effect: item.interaction.effect
      }));
    
    // Get suggestions based on the current ingredients
    const suggestionItems = await this.getSuggestedIngredients(ingredientIds);
    
    // Convert to the expected format
    const suggestions: {ingredient: Ingredient, purpose: string}[] = 
      suggestionItems.map(item => ({
        ingredient: item.ingredient,
        purpose: item.reason
      }));
    
    // Find enhancements (positive interactions)
    const enhancements: {ingredientA: Ingredient, ingredientB: Ingredient, effect: string}[] = [];
    
    // For now, calculate a simple interaction score based on conflicts and enhancements
    const interactionScore = 100 - (conflicts.length * 10) + (enhancements.length * 5);
    
    return {
      interactionScore: Math.max(0, Math.min(100, interactionScore)),
      conflicts,
      enhancements,
      suggestions
    };
  }

  async calculateFormulaProperties(formulaId: number): Promise<Record<string, any>> {
    const formula = await this.getFormula(formulaId);
    if (!formula) {
      return {};
    }

    // Calculate properties based on ingredients
    const properties: Record<string, any> = {
      estimatedLongevity: "6-8 hours",
      sillage: "Moderate",
      intensity: "Medium",
      complexity: "Medium",
      balance: "Well-balanced",
      volatilityProfile: {
        topNotes: "30%",
        heartNotes: "50%",
        baseNotes: "20%"
      }
    };
    
    return properties;
  }

  // Ingredient operations
  async getIngredient(id: number): Promise<Ingredient | undefined> {
    return this.ingredients.get(id);
  }

  async getIngredientByCasNumber(casNumber: string): Promise<Ingredient | undefined> {
    return Array.from(this.ingredients.values()).find(
      (ingredient) => ingredient.casNumber === casNumber
    );
  }

  async getAllIngredients(): Promise<Ingredient[]> {
    return Array.from(this.ingredients.values());
  }

  async searchIngredients(query: string): Promise<Ingredient[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.ingredients.values()).filter(
      (ingredient) => 
        ingredient.name.toLowerCase().includes(lowerQuery) ||
        ingredient.category.toLowerCase().includes(lowerQuery) ||
        ingredient.casNumber?.toLowerCase().includes(lowerQuery)
    );
  }

  async createIngredient(ingredient: InsertIngredient): Promise<Ingredient> {
    const id = this.ingredientIdCounter++;
    const now = new Date();
    const newIngredient: Ingredient = { 
      ...ingredient, 
      id, 
      createdAt: now,
      updatedAt: now,
      // Ensure required fields are not undefined
      casNumber: ingredient.casNumber || null,
      category: ingredient.category,
      pyramid: ingredient.pyramid || null,
      odorProfile: ingredient.odorProfile || [],
      concentration: ingredient.concentration || null,
      solubility: ingredient.solubility || null,
      flashPoint: ingredient.flashPoint || null,
      appearanceState: ingredient.appearanceState || null,
      tenacity: ingredient.tenacity || null,
      stability: ingredient.stability || null,
      molecularWeight: ingredient.molecularWeight || null,
      potency: ingredient.potency || null,
      allergenInfo: ingredient.allergenInfo || [],
      restrictions: ingredient.restrictions || [],
      incompatibleWith: ingredient.incompatibleWith || [],
      substitutes: ingredient.substitutes || [],
      enhancedBy: ingredient.enhancedBy || [],
      recommendations: ingredient.recommendations || {}
    };
    this.ingredients.set(id, newIngredient);
    return newIngredient;
  }

  async updateIngredient(id: number, ingredient: Partial<InsertIngredient>): Promise<Ingredient | undefined> {
    const existingIngredient = this.ingredients.get(id);
    if (!existingIngredient) return undefined;
    
    const now = new Date();
    const updatedIngredient: Ingredient = { 
      ...existingIngredient, 
      ...ingredient,
      updatedAt: now
    };
    
    this.ingredients.set(id, updatedIngredient);
    return updatedIngredient;
  }

  async getIngredientsByCategory(category: string): Promise<Ingredient[]> {
    return Array.from(this.ingredients.values()).filter(
      (ingredient) => ingredient.category === category
    );
  }

  async getIngredientsByPyramid(pyramid: string): Promise<Ingredient[]> {
    return Array.from(this.ingredients.values()).filter(
      (ingredient) => ingredient.pyramid === pyramid
    );
  }

  // Ingredient Interaction operations
  async getIngredientInteraction(id: number): Promise<IngredientInteraction | undefined> {
    return this.ingredientInteractions.get(id);
  }

  async createIngredientInteraction(interaction: InsertIngredientInteraction): Promise<IngredientInteraction> {
    const id = this.ingredientInteractionIdCounter++;
    const now = new Date();
    const newInteraction: IngredientInteraction = { 
      ...interaction, 
      id, 
      createdAt: now,
      updatedAt: now,
      // Ensure required fields are not undefined
      notes: interaction.notes || null,
      // Make sure required fields are present
      ingredientAId: interaction.ingredientAId,
      ingredientBId: interaction.ingredientBId,
      interactionType: interaction.interactionType,
      effect: interaction.effect,
      strengthLevel: interaction.strengthLevel
    };
    this.ingredientInteractions.set(id, newInteraction);
    return newInteraction;
  }

  async getInteractionsBetweenIngredients(ingredientAId: number, ingredientBId: number): Promise<IngredientInteraction[]> {
    return Array.from(this.ingredientInteractions.values()).filter(
      (interaction) => 
        (interaction.ingredientAId === ingredientAId && interaction.ingredientBId === ingredientBId) ||
        (interaction.ingredientAId === ingredientBId && interaction.ingredientBId === ingredientAId)
    );
  }

  async getInteractionsForIngredient(ingredientId: number): Promise<IngredientInteraction[]> {
    return Array.from(this.ingredientInteractions.values()).filter(
      (interaction) => 
        interaction.ingredientAId === ingredientId || interaction.ingredientBId === ingredientId
    );
  }

  async getConflictingIngredients(ingredientIds: number[]): Promise<{ingredient: Ingredient, conflictsWith: Ingredient, interaction: IngredientInteraction}[]> {
    const conflicts: {ingredient: Ingredient, conflictsWith: Ingredient, interaction: IngredientInteraction}[] = [];
    
    // For each pair of ingredients, check if there is a negative interaction
    for (let i = 0; i < ingredientIds.length; i++) {
      for (let j = i + 1; j < ingredientIds.length; j++) {
        const interactions = await this.getInteractionsBetweenIngredients(ingredientIds[i], ingredientIds[j]);
        
        // Filter for negative interactions (interaction type is 'Conflicts' or strength level is negative)
        const negativeInteractions = interactions.filter(
          interaction => interaction.interactionType === 'Conflicts' || interaction.strengthLevel < 0
        );
        
        for (const interaction of negativeInteractions) {
          const ingredientA = await this.getIngredient(interaction.ingredientAId);
          const ingredientB = await this.getIngredient(interaction.ingredientBId);
          
          if (ingredientA && ingredientB) {
            conflicts.push({
              ingredient: ingredientA,
              conflictsWith: ingredientB,
              interaction
            });
          }
        }
      }
    }
    
    return conflicts;
  }

  async getSuggestedIngredients(ingredientIds: number[]): Promise<{ingredient: Ingredient, reason: string, strengthLevel: number}[]> {
    const suggestions: {ingredient: Ingredient, reason: string, strengthLevel: number}[] = [];
    const allIngredients = await this.getAllIngredients();
    
    // Get ingredients not in the current selection
    const potentialIngredients = allIngredients.filter(
      ingredient => !ingredientIds.includes(ingredient.id)
    );
    
    // For each ingredient in the current selection
    for (const currentId of ingredientIds) {
      const currentIngredient = await this.getIngredient(currentId);
      if (!currentIngredient) continue;
      
      // Check for positive interactions with other ingredients
      for (const potentialIngredient of potentialIngredients) {
        const interactions = await this.getInteractionsBetweenIngredients(currentId, potentialIngredient.id);
        
        // Filter for positive interactions
        const positiveInteractions = interactions.filter(
          interaction => interaction.interactionType === 'Enhances' || interaction.strengthLevel > 0
        );
        
        for (const interaction of positiveInteractions) {
          suggestions.push({
            ingredient: potentialIngredient,
            reason: `Works well with ${currentIngredient.name}: ${interaction.effect}`,
            strengthLevel: interaction.strengthLevel
          });
        }
      }
    }
    
    // Remove duplicates and sort by interaction strength
    const uniqueSuggestions = suggestions.reduce((acc, curr) => {
      const exists = acc.find(s => s.ingredient.id === curr.ingredient.id);
      if (!exists) {
        acc.push(curr);
      } else if (exists.strengthLevel < curr.strengthLevel) {
        // If exists but current has higher strength, replace it
        acc = acc.filter(s => s.ingredient.id !== curr.ingredient.id);
        acc.push(curr);
      }
      return acc;
    }, [] as {ingredient: Ingredient, reason: string, strengthLevel: number}[]);
    
    return uniqueSuggestions.sort((a, b) => b.strengthLevel - a.strengthLevel);
  }

  // Base Request operations
  async getBaseRequest(id: number): Promise<BaseRequest | undefined> {
    return this.baseRequests.get(id);
  }

  async createBaseRequest(request: InsertBaseRequest): Promise<BaseRequest> {
    const id = this.baseRequestIdCounter++;
    const now = new Date();
    const newRequest: BaseRequest = { 
      ...request, 
      id, 
      status: "pending", 
      createdAt: now,
      resolvedAt: null,
      // Ensure required fields are not undefined
      description: request.description || null
    };
    this.baseRequests.set(id, newRequest);
    return newRequest;
  }

  async getUserBaseRequests(userId: number): Promise<BaseRequest[]> {
    return Array.from(this.baseRequests.values()).filter(
      (request) => request.userId === userId
    );
  }

  async updateBaseRequestStatus(id: number, status: string): Promise<BaseRequest | undefined> {
    const request = this.baseRequests.get(id);
    if (!request) return undefined;
    
    const updatedRequest: BaseRequest = { 
      ...request, 
      status,
      resolvedAt: status === 'approved' || status === 'rejected' ? new Date() : request.resolvedAt
    };
    
    this.baseRequests.set(id, updatedRequest);
    return updatedRequest;
  }

  async getAllBaseRequests(): Promise<BaseRequest[]> {
    return Array.from(this.baseRequests.values());
  }

  // Project operations
  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async getAllProjects(): Promise<Project[]> {
    return Array.from(this.projects.values());
  }

  async searchProjects(query: string): Promise<Project[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.projects.values()).filter(
      (project) => 
        project.name.toLowerCase().includes(lowerQuery) ||
        project.description?.toLowerCase().includes(lowerQuery) ||
        project.client.toLowerCase().includes(lowerQuery) ||
        project.status.toLowerCase().includes(lowerQuery) ||
        project.stage.toLowerCase().includes(lowerQuery)
    );
  }

  async createProject(project: InsertProject): Promise<Project> {
    const id = this.projectIdCounter++;
    const now = new Date();
    const newProject: Project = { 
      ...project, 
      id, 
      createdAt: now,
      updatedAt: now,
      // Ensure required fields are not undefined
      description: project.description || null,
      notes: project.notes || null,
      dueDate: project.dueDate || null
    };
    this.projects.set(id, newProject);
    return newProject;
  }

  async updateProject(id: number, project: Partial<InsertProject>): Promise<Project | undefined> {
    const existingProject = this.projects.get(id);
    if (!existingProject) return undefined;
    
    const now = new Date();
    const updatedProject: Project = { 
      ...existingProject, 
      ...project,
      updatedAt: now
    };
    
    this.projects.set(id, updatedProject);
    return updatedProject;
  }

  // Task operations
  async getTask(id: number): Promise<Task | undefined> {
    return this.tasks.get(id);
  }

  async getAllTasks(): Promise<Task[]> {
    return Array.from(this.tasks.values());
  }

  async getUserTasks(userId: number): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(
      (task) => task.assignedTo === userId
    );
  }

  async createTask(task: InsertTask): Promise<Task> {
    const id = this.taskIdCounter++;
    const now = new Date();
    const newTask: Task = { 
      ...task, 
      id, 
      status: "pending", 
      createdAt: now,
      updatedAt: now,
      completedAt: null,
      // Ensure required fields are not undefined
      description: task.description || null,
      dueDate: task.dueDate || null,
      projectId: task.projectId || null
    };
    this.tasks.set(id, newTask);
    return newTask;
  }

  async updateTask(id: number, task: Partial<InsertTask>): Promise<Task | undefined> {
    const existingTask = this.tasks.get(id);
    if (!existingTask) return undefined;
    
    const now = new Date();
    const updatedTask: Task = { 
      ...existingTask, 
      ...task,
      updatedAt: now
    };
    
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }

  async updateTaskStatus(id: number, status: string): Promise<Task | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;
    
    const now = new Date();
    const updatedTask: Task = { 
      ...task, 
      status,
      updatedAt: now,
      completedAt: status === 'completed' ? now : task.completedAt
    };
    
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }

  async getProjectTasks(projectId: number): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(
      (task) => task.projectId === projectId
    );
  }

  // Resource Allocation operations
  async getResourceAllocation(id: number): Promise<ResourceAllocation | undefined> {
    return this.resourceAllocations.get(id);
  }

  async createResourceAllocation(allocation: InsertResourceAllocation): Promise<ResourceAllocation> {
    const id = this.resourceAllocationIdCounter++;
    const now = new Date();
    const newAllocation: ResourceAllocation = {
      ...allocation,
      id,
      allocatedAt: now,
      updatedAt: now,
      // Ensure required fields are not undefined
      status: allocation.status || 'allocated',
      notes: allocation.notes || null,
      dueDate: allocation.dueDate || null,
      projectId: allocation.projectId || null,
      formulaId: allocation.formulaId || null
    };
    this.resourceAllocations.set(id, newAllocation);

    // Automatically create a transaction record for this allocation
    this.createResourceTransaction({
      resourceId: allocation.resourceId,
      userId: allocation.userId,
      transactionType: 'allocated',
      quantity: String(Number(allocation.quantity) * -1), // Negative because it's leaving available inventory
      relatedAllocationId: id,
      notes: `Allocated to ${allocation.projectId ? `Project #${allocation.projectId}` : ''} ${allocation.formulaId ? `Formula #${allocation.formulaId}` : ''}`.trim()
    });

    // Update the resource quantity
    const resource = this.resources.get(allocation.resourceId);
    if (resource && resource.quantity !== null) {
      const newQuantity = resource.quantity - Number(allocation.quantity);
      this.updateResource(allocation.resourceId, { quantity: newQuantity >= 0 ? newQuantity : 0 });
    }

    return newAllocation;
  }

  async updateResourceAllocationStatus(id: number, status: string): Promise<ResourceAllocation | undefined> {
    const allocation = this.resourceAllocations.get(id);
    if (!allocation) return undefined;

    const now = new Date();
    const updatedAllocation: ResourceAllocation = {
      ...allocation,
      status,
      updatedAt: now
    };
    this.resourceAllocations.set(id, updatedAllocation);

    // If status is 'returned', create a return transaction and update resource quantity
    if (status === 'returned') {
      this.createResourceTransaction({
        resourceId: allocation.resourceId,
        userId: allocation.userId,
        transactionType: 'returned',
        quantity: String(Number(allocation.quantity)), // Positive because it's returning to inventory
        relatedAllocationId: id,
        notes: `Returned from ${allocation.projectId ? `Project #${allocation.projectId}` : ''} ${allocation.formulaId ? `Formula #${allocation.formulaId}` : ''}`.trim()
      });

      // Update the resource quantity
      const resource = this.resources.get(allocation.resourceId);
      if (resource && resource.quantity !== null) {
        const newQuantity = resource.quantity + Number(allocation.quantity);
        this.updateResource(allocation.resourceId, { quantity: newQuantity });
      }
    }
    
    // If status is 'consumed', create a consumed transaction (no change to resource quantity as it was already deducted)
    if (status === 'consumed') {
      this.createResourceTransaction({
        resourceId: allocation.resourceId,
        userId: allocation.userId,
        transactionType: 'consumed',
        quantity: "0", // Zero because quantity was already deducted when allocated
        relatedAllocationId: id,
        notes: `Consumed by ${allocation.projectId ? `Project #${allocation.projectId}` : ''} ${allocation.formulaId ? `Formula #${allocation.formulaId}` : ''}`.trim()
      });
    }

    return updatedAllocation;
  }

  async getResourceAllocations(filters?: {
    resourceId?: number;
    projectId?: number;
    formulaId?: number;
    userId?: number;
    status?: string;
  }): Promise<ResourceAllocation[]> {
    let allocations = Array.from(this.resourceAllocations.values());
    
    if (filters) {
      if (filters.resourceId !== undefined) {
        allocations = allocations.filter(a => a.resourceId === filters.resourceId);
      }
      if (filters.projectId !== undefined) {
        allocations = allocations.filter(a => a.projectId === filters.projectId);
      }
      if (filters.formulaId !== undefined) {
        allocations = allocations.filter(a => a.formulaId === filters.formulaId);
      }
      if (filters.userId !== undefined) {
        allocations = allocations.filter(a => a.userId === filters.userId);
      }
      if (filters.status !== undefined) {
        allocations = allocations.filter(a => a.status === filters.status);
      }
    }
    
    return allocations;
  }

  // Resource Transaction operations
  async getResourceTransaction(id: number): Promise<ResourceTransaction | undefined> {
    return this.resourceTransactions.get(id);
  }

  async createResourceTransaction(transaction: InsertResourceTransaction): Promise<ResourceTransaction> {
    const id = this.resourceTransactionIdCounter++;
    const newTransaction: ResourceTransaction = {
      ...transaction,
      id,
      transactionDate: new Date(),
      // Ensure required fields are not undefined
      notes: transaction.notes || null,
      relatedAllocationId: transaction.relatedAllocationId || null,
      batchNumber: transaction.batchNumber || null,
      expiryDate: transaction.expiryDate || null
    };
    this.resourceTransactions.set(id, newTransaction);

    // Check for low stock after transaction if transaction affects inventory
    if (transaction.transactionType !== 'consumed') { // No need to check for consumed as quantity was already deducted
      this.checkLowStockAlert(transaction.resourceId);
    }

    return newTransaction;
  }

  async getResourceTransactions(filters?: {
    resourceId?: number;
    userId?: number;
    transactionType?: string;
    startDate?: Date;
    endDate?: Date;
  }): Promise<ResourceTransaction[]> {
    let transactions = Array.from(this.resourceTransactions.values());
    
    if (filters) {
      if (filters.resourceId !== undefined) {
        transactions = transactions.filter(t => t.resourceId === filters.resourceId);
      }
      if (filters.userId !== undefined) {
        transactions = transactions.filter(t => t.userId === filters.userId);
      }
      if (filters.transactionType !== undefined) {
        transactions = transactions.filter(t => t.transactionType === filters.transactionType);
      }
      if (filters.startDate !== undefined) {
        transactions = transactions.filter(t => t.transactionDate && t.transactionDate >= filters.startDate!);
      }
      if (filters.endDate !== undefined) {
        transactions = transactions.filter(t => t.transactionDate && t.transactionDate <= filters.endDate!);
      }
    }
    
    return transactions;
  }

  async getResourceTransactionHistory(resourceId: number): Promise<ResourceTransaction[]> {
    return Array.from(this.resourceTransactions.values())
      .filter(transaction => transaction.resourceId === resourceId)
      .sort((a, b) => {
        // Handle null transaction dates safely
        const dateA = a.transactionDate ? a.transactionDate.getTime() : 0;
        const dateB = b.transactionDate ? b.transactionDate.getTime() : 0;
        return dateB - dateA; // Sort by date descending
      });
  }

  // Resource Threshold operations
  async getResourceThreshold(id: number): Promise<ResourceThreshold | undefined> {
    return this.resourceThresholds.get(id);
  }

  async getResourceThresholdByResourceId(resourceId: number): Promise<ResourceThreshold | undefined> {
    return Array.from(this.resourceThresholds.values()).find(
      threshold => threshold.resourceId === resourceId
    );
  }

  async createResourceThreshold(threshold: InsertResourceThreshold): Promise<ResourceThreshold> {
    const id = this.resourceThresholdIdCounter++;
    const now = new Date();
    const newThreshold: ResourceThreshold = {
      ...threshold,
      id,
      createdAt: now,
      updatedAt: now,
      // Ensure required fields are not undefined
      targetLevel: threshold.targetLevel || null,
      alertEnabled: threshold.alertEnabled || false,
      alertMessage: threshold.alertMessage || null
    };
    this.resourceThresholds.set(id, newThreshold);
    
    // Check if current stock is below threshold
    this.checkLowStockAlert(threshold.resourceId);
    
    return newThreshold;
  }

  async updateResourceThreshold(id: number, threshold: Partial<InsertResourceThreshold>): Promise<ResourceThreshold | undefined> {
    const existingThreshold = this.resourceThresholds.get(id);
    if (!existingThreshold) return undefined;
    
    const now = new Date();
    const updatedThreshold: ResourceThreshold = {
      ...existingThreshold,
      ...threshold,
      updatedAt: now
    };
    this.resourceThresholds.set(id, updatedThreshold);
    
    // Check if current stock is below updated threshold
    this.checkLowStockAlert(existingThreshold.resourceId);
    
    return updatedThreshold;
  }

  async getResourcesWithLowStock(): Promise<{resource: Resource; threshold: ResourceThreshold}[]> {
    const thresholds = Array.from(this.resourceThresholds.values());
    
    return thresholds
      .filter(threshold => 
        threshold.alertEnabled === true && 
        this.resources.has(threshold.resourceId) &&
        this.resources.get(threshold.resourceId)!.quantity !== null &&
        this.resources.get(threshold.resourceId)!.quantity! <= Number(threshold.minimumLevel)
      )
      .map(threshold => ({
        resource: this.resources.get(threshold.resourceId)!,
        threshold
      }));
  }

  // Helper method to check if a resource is below its threshold and create a task if needed
  private async checkLowStockAlert(resourceId: number): Promise<void> {
    const resource = this.resources.get(resourceId);
    const threshold = await this.getResourceThresholdByResourceId(resourceId);
    
    if (resource && threshold && threshold.alertEnabled && 
        resource.quantity !== null && resource.quantity <= Number(threshold.minimumLevel)) {
      
      // Check if there's already an open task for this resource's low stock
      const existingTasks = Array.from(this.tasks.values()).filter(
        task => task.title.includes(`Low stock alert for ${resource.name}`) && 
               task.status !== 'completed'
      );
      
      if (existingTasks.length === 0) {
        // Create a task for inventory manager to restock
        this.createTask({
          title: `Low stock alert for ${resource.name}`,
          description: threshold.alertMessage || 
                      `${resource.name} (${resource.code || ''}) is below minimum level. Current: ${resource.quantity} ${resource.unit || ''}, Minimum: ${threshold.minimumLevel}`,
          assignedTo: 1, // Assign to admin for now
          priority: 'high',
          dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // Due in 7 days
        });
      }
    }
  }

  // AI-powered compatibility and suggestions implementations
  async analyzeIngredientsCompatibility(ingredientIds: number[]): Promise<{
    overallScore: number;
    compatibilityMatrix: {
      ingredientA: Ingredient,
      ingredientB: Ingredient,
      score: number,
      effect: string,
      interactionType: string
    }[];
    recommendedRatios: {
      ingredient: Ingredient,
      minPercentage: number,
      maxPercentage: number,
      optimalPercentage: number
    }[];
  }> {
    // Initialize the compatibility matrix
    const compatibilityMatrix: {
      ingredientA: Ingredient,
      ingredientB: Ingredient,
      score: number,
      effect: string,
      interactionType: string
    }[] = [];
    
    // Generate recommended ratios for each ingredient
    const recommendedRatios: {
      ingredient: Ingredient,
      minPercentage: number,
      maxPercentage: number,
      optimalPercentage: number
    }[] = [];
    
    // Get all ingredients from the provided IDs
    const ingredients: (Ingredient | undefined)[] = await Promise.all(
      ingredientIds.map(id => this.getIngredient(id))
    );
    
    // Filter out undefined ingredients
    const validIngredients = ingredients.filter((ing): ing is Ingredient => ing !== undefined);
    
    if (validIngredients.length === 0) {
      return {
        overallScore: 0,
        compatibilityMatrix: [],
        recommendedRatios: []
      };
    }

    // Calculate compatibility matrix for each ingredient pair
    for (let i = 0; i < validIngredients.length; i++) {
      for (let j = i + 1; j < validIngredients.length; j++) {
        const ingredientA = validIngredients[i];
        const ingredientB = validIngredients[j];
        
        // Get interactions between these ingredients
        const interactions = await this.getInteractionsBetweenIngredients(ingredientA.id, ingredientB.id);
        
        // Calculate a score based on the interactions
        let score = 50; // Default neutral score
        let effect = "Neutral interaction";
        let interactionType = "Neutral";
        
        if (interactions.length > 0) {
          // Use the strongest interaction (by absolute value of strength level)
          const strongestInteraction = interactions.reduce((prev, current) => 
            Math.abs(current.strengthLevel) > Math.abs(prev.strengthLevel) ? current : prev
          );
          
          // Set the score based on the interaction strength (normalize to 0-100)
          score = Math.max(0, Math.min(100, 50 + strongestInteraction.strengthLevel / 2));
          effect = strongestInteraction.effect;
          interactionType = strongestInteraction.interactionType;
        } else {
          // No known interaction, use pyramid levels to estimate compatibility
          if (ingredientA.pyramid === ingredientB.pyramid) {
            // Same pyramid level ingredients might compete
            score = 40;
            effect = "Potential competition at same pyramid level";
            interactionType = "Potential conflict";
          } else if (
            (ingredientA.pyramid === "Top" && ingredientB.pyramid === "Heart") ||
            (ingredientA.pyramid === "Heart" && ingredientB.pyramid === "Base") ||
            (ingredientA.pyramid === "Top" && ingredientB.pyramid === "Base")
          ) {
            // Complementary pyramid levels
            score = 70;
            effect = "Complementary pyramid levels";
            interactionType = "Complementary";
          }
        }
        
        compatibilityMatrix.push({
          ingredientA,
          ingredientB,
          score,
          effect,
          interactionType
        });
      }
      
      // Add recommended ratio for this ingredient based on its pyramid level
      const ingredient = validIngredients[i];
      let minPercentage = 1;
      let maxPercentage = 10;
      let optimalPercentage = 5;
      
      if (ingredient.pyramid === "Top") {
        minPercentage = 5;
        maxPercentage = 30;
        optimalPercentage = 15;
      } else if (ingredient.pyramid === "Heart") {
        minPercentage = 10;
        maxPercentage = 40;
        optimalPercentage = 25;
      } else if (ingredient.pyramid === "Base") {
        minPercentage = 5;
        maxPercentage = 20;
        optimalPercentage = 10;
      }
      
      recommendedRatios.push({
        ingredient,
        minPercentage,
        maxPercentage,
        optimalPercentage
      });
    }
    
    // Calculate overall compatibility score from the matrix
    let overallScore = 0;
    if (compatibilityMatrix.length > 0) {
      const totalScore = compatibilityMatrix.reduce((sum, item) => sum + item.score, 0);
      overallScore = Math.round(totalScore / compatibilityMatrix.length);
    }
    
    return {
      overallScore,
      compatibilityMatrix,
      recommendedRatios
    };
  }
  
  async getAdvancedIngredientSuggestions(
    ingredientIds: number[], 
    filters?: {
      category?: string;
      pyramid?: string;
    }
  ): Promise<{
    suggestions: {
      ingredient: Ingredient,
      compatibilityScore: number,
      reason: string,
      usageNotes: string
    }[];
    alternativeGroups: {
      category: string,
      options: Ingredient[]
    }[];
  }> {
    // Get all ingredients
    const allIngredients = await this.getAllIngredients();
    
    // Get ingredients by IDs
    const selectedIngredients = allIngredients.filter(ing => ingredientIds.includes(ing.id));
    
    // Find potential candidates (not already in the selection)
    let candidates = allIngredients.filter(ing => !ingredientIds.includes(ing.id));
    
    // Apply filters if provided
    if (filters?.category) {
      candidates = candidates.filter(ing => ing.category === filters.category);
    }
    
    if (filters?.pyramid) {
      candidates = candidates.filter(ing => ing.pyramid === filters.pyramid);
    }
    
    // Calculate compatibility scores for each candidate
    const suggestions: {
      ingredient: Ingredient,
      compatibilityScore: number,
      reason: string,
      usageNotes: string
    }[] = [];
    
    for (const candidate of candidates) {
      let totalScore = 0;
      let positiveInteractions = 0;
      let bestReason = "";
      let highestScore = 0;
      
      // Check compatibility with each selected ingredient
      for (const selected of selectedIngredients) {
        const interactions = await this.getInteractionsBetweenIngredients(candidate.id, selected.id);
        
        if (interactions.length > 0) {
          // Use the strongest positive interaction
          const positiveInteraction = interactions.filter(int => int.strengthLevel > 0)
            .sort((a, b) => b.strengthLevel - a.strengthLevel)[0];
          
          if (positiveInteraction) {
            const score = Math.min(100, positiveInteraction.strengthLevel);
            totalScore += score;
            positiveInteractions++;
            
            if (score > highestScore) {
              highestScore = score;
              bestReason = `${positiveInteraction.effect} when combined with ${selected.name}`;
            }
          }
        } else {
          // No known interaction, check if they're complementary by pyramid
          if (
            (candidate.pyramid === "Top" && selected.pyramid === "Heart") ||
            (candidate.pyramid === "Heart" && selected.pyramid === "Base") ||
            (selected.pyramid === "Top" && candidate.pyramid === "Heart") ||
            (selected.pyramid === "Heart" && candidate.pyramid === "Base")
          ) {
            totalScore += 60;
            positiveInteractions++;
            
            if (60 > highestScore) {
              highestScore = 60;
              bestReason = `Complements ${selected.name} with balanced pyramid levels`;
            }
          }
        }
      }
      
      // Calculate final compatibility score
      const compatibilityScore = positiveInteractions > 0 
        ? Math.round(totalScore / positiveInteractions) 
        : 50; // Neutral score if no interactions found
      
      if (bestReason === "") {
        bestReason = "Could add a new dimension to the composition";
      }
      
      // Generate usage notes based on candidate properties
      let usageNotes = "";
      if (candidate.pyramid === "Top") {
        usageNotes = "Best used in small quantities (5-15%) for opening notes";
      } else if (candidate.pyramid === "Heart") {
        usageNotes = "Can form the core of the composition (15-30%)";
      } else if (candidate.pyramid === "Base") {
        usageNotes = "Provides longevity and depth, use 5-20%";
      }
      
      // Add additional context based on category
      if (candidate.category === "Essential Oil") {
        usageNotes += ". Natural, may have batch variations";
      } else if (candidate.category === "Synthetic") {
        usageNotes += ". Consistent profile, good for stability";
      }
      
      suggestions.push({
        ingredient: candidate,
        compatibilityScore,
        reason: bestReason,
        usageNotes
      });
    }
    
    // Sort suggestions by compatibility score
    const sortedSuggestions = suggestions.sort((a, b) => b.compatibilityScore - a.compatibilityScore);
    
    // Create alternative groups by category
    const categorizedIngredients: Record<string, Ingredient[]> = {};
    
    for (const ingredient of candidates) {
      if (!categorizedIngredients[ingredient.category]) {
        categorizedIngredients[ingredient.category] = [];
      }
      categorizedIngredients[ingredient.category].push(ingredient);
    }
    
    const alternativeGroups = Object.entries(categorizedIngredients)
      .map(([category, options]) => ({ category, options }))
      .filter(group => group.options.length > 0);
    
    return {
      suggestions: sortedSuggestions.slice(0, 10), // Return top 10 suggestions
      alternativeGroups
    };
  }
  
  async getFormulaCompatibilitySuggestions(formulaId: number): Promise<{
    topSuggestions: {ingredient: Ingredient, reason: string, compatibilityScore: number}[];
    balanceRecommendations: {category: string, currentPercentage: number, recommendedPercentage: number}[];
    substitutionOptions: {originalIngredient: Ingredient, substitutes: {ingredient: Ingredient, reason: string}[]};
  }> {
    const formula = await this.getFormula(formulaId);
    
    if (!formula) {
      return {
        topSuggestions: [],
        balanceRecommendations: [],
        substitutionOptions: {originalIngredient: {} as Ingredient, substitutes: []}
      };
    }
    
    // Extract ingredient names from formula composition
    const composition = formula.composition as any[] || [];
    const ingredientNames = composition.map(comp => comp.ingredient);
    const ingredientPercentages = composition.reduce((acc: Record<string, number>, comp: any) => {
      acc[comp.ingredient] = comp.percentage || 0;
      return acc;
    }, {});
    
    // Get all ingredients that match these names
    const allIngredients = await this.getAllIngredients();
    const formulaIngredients = allIngredients.filter(ing => 
      ingredientNames.includes(ing.name)
    );
    
    const ingredientIds = formulaIngredients.map(ing => ing.id);
    
    // Get advanced suggestions for ingredients not in the formula
    const advancedSuggestions = await this.getAdvancedIngredientSuggestions(ingredientIds);
    
    // Format top suggestions
    const topSuggestions = advancedSuggestions.suggestions.map(sugg => ({
      ingredient: sugg.ingredient,
      reason: sugg.reason,
      compatibilityScore: sugg.compatibilityScore
    }));
    
    // Analyze current formula balance
    const categoryPercentages: Record<string, number> = {};
    const pyramidPercentages: Record<string, number> = {};
    
    for (const ingredient of formulaIngredients) {
      const percentage = ingredientPercentages[ingredient.name] || 0;
      
      // Accumulate by category
      if (!categoryPercentages[ingredient.category]) {
        categoryPercentages[ingredient.category] = 0;
      }
      categoryPercentages[ingredient.category] += percentage;
      
      // Accumulate by pyramid level
      if (ingredient.pyramid && !pyramidPercentages[ingredient.pyramid]) {
        pyramidPercentages[ingredient.pyramid] = 0;
      }
      if (ingredient.pyramid) {
        pyramidPercentages[ingredient.pyramid] += percentage;
      }
    }
    
    // Generate balance recommendations
    const balanceRecommendations: {
      category: string, 
      currentPercentage: number, 
      recommendedPercentage: number
    }[] = [];
    
    // Recommend ideal pyramid balance (approximately 30% top, 50% heart, 20% base)
    if (pyramidPercentages['Top'] !== undefined) {
      balanceRecommendations.push({
        category: "Top Notes",
        currentPercentage: pyramidPercentages['Top'],
        recommendedPercentage: 30
      });
    }
    
    if (pyramidPercentages['Heart'] !== undefined) {
      balanceRecommendations.push({
        category: "Heart Notes",
        currentPercentage: pyramidPercentages['Heart'],
        recommendedPercentage: 50
      });
    }
    
    if (pyramidPercentages['Base'] !== undefined) {
      balanceRecommendations.push({
        category: "Base Notes",
        currentPercentage: pyramidPercentages['Base'],
        recommendedPercentage: 20
      });
    }
    
    // Find potential substitutes for the most expensive or problematic ingredient
    // For demo, we'll just choose the first ingredient as "problematic"
    let substitutionOptions: {
      originalIngredient: Ingredient, 
      substitutes: {ingredient: Ingredient, reason: string}[]
    } = {
      originalIngredient: {} as Ingredient,
      substitutes: []
    };
    
    if (formulaIngredients.length > 0) {
      const originalIngredient = formulaIngredients[0];
      const potentialSubstitutes = allIngredients.filter(ing => 
        ing.id !== originalIngredient.id && 
        ing.category === originalIngredient.category &&
        ing.pyramid === originalIngredient.pyramid
      );
      
      substitutionOptions = {
        originalIngredient,
        substitutes: potentialSubstitutes.slice(0, 3).map(ing => ({
          ingredient: ing,
          reason: `Similar odor profile and pyramid level to ${originalIngredient.name}`
        }))
      };
    }
    
    return {
      topSuggestions,
      balanceRecommendations,
      substitutionOptions
    };
  }
}

// Create and export a singleton instance
export const storage = new MemStorage();
