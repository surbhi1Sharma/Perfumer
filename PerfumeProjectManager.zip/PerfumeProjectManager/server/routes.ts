import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertResourceSchema, 
  insertResourceRequestSchema, 
  insertFormulaSchema, 
  insertBaseRequestSchema, 
  insertProjectSchema, 
  insertTaskSchema,
  PERMISSIONS,
  ROLES,
  TEAMS
} from "@shared/schema";
import { 
  getDefaultPermissions, 
  hasPermission, 
  getAllPermissions,
  getAllRoles,
  getAllTeams
} from "./auth";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  const apiRouter = express.Router();
  
  // Auth endpoints
  apiRouter.post("/auth/login", async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // In a real app, we would use proper sessions, JWT, etc.
      const { password: userPassword, ...safeUser } = user;
      
      return res.status(200).json({ user: safeUser });
    } catch (error) {
      console.error("Login error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  apiRouter.get("/auth/me", async (req: Request, res: Response) => {
    try {
      // This is a mock placeholder - in a real app, we would check session/token
      const user = await storage.getUser(1);
      
      if (!user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const { password, ...safeUser } = user;
      
      return res.status(200).json(safeUser);
    } catch (error) {
      console.error("Auth error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Dashboard endpoints
  apiRouter.get("/dashboard", async (req: Request, res: Response) => {
    try {
      const projects = await storage.getAllProjects();
      const tasks = await storage.getAllTasks();
      const resources = await storage.getAllResources();
      const resourceRequests = await storage.getAllResourceRequests();
      const formulas = await storage.getAllFormulas();

      // Calculate dashboard stats
      const activeProjects = projects.filter(p => p.status === 'active').length;
      const pendingFormulas = formulas.filter(f => f.status === 'pending').length;
      const urgentRequests = resourceRequests.filter(r => r.urgency === 'high' && r.status === 'pending').length;
      
      const recentProjects = projects
        .sort((a, b) => {
          // Handle null values for createdAt
          if (!a.createdAt) return 1;  // null dates come last
          if (!b.createdAt) return -1;
          return b.createdAt.getTime() - a.createdAt.getTime();
        })
        .slice(0, 5);
      
      const upcomingTasks = tasks
        .filter(t => t.status !== 'completed')
        .sort((a, b) => {
          // Handle null values for dueDate
          if (!a.dueDate) return 1; // null dates come last
          if (!b.dueDate) return -1;
          return a.dueDate.getTime() - b.dueDate.getTime();
        })
        .slice(0, 5);
      
      return res.status(200).json({
        stats: {
          activeProjects,
          pendingFormulas,
          resourceRequests: resourceRequests.filter(r => r.status === 'pending').length,
          urgentRequests
        },
        recentProjects,
        upcomingTasks
      });
    } catch (error) {
      console.error("Dashboard error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Resource endpoints
  apiRouter.get("/resources/low-stock", async (req: Request, res: Response) => {
    try {
      const lowStockResources = await storage.getResourcesWithLowStock();
      return res.status(200).json(lowStockResources);
    } catch (error) {
      console.error("Error fetching low stock resources:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.get("/resources", async (req: Request, res: Response) => {
    try {
      const query = req.query.q as string;
      let resources;
      
      if (query) {
        resources = await storage.searchResources(query);
      } else {
        resources = await storage.getAllResources();
      }
      
      return res.status(200).json(resources);
    } catch (error) {
      console.error("Resources error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.get("/resources/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const resource = await storage.getResource(id);
      
      if (!resource) {
        return res.status(404).json({ message: "Resource not found" });
      }
      
      return res.status(200).json(resource);
    } catch (error) {
      console.error("Resource error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.post("/resources", async (req: Request, res: Response) => {
    try {
      const resourceData = insertResourceSchema.safeParse(req.body);
      
      if (!resourceData.success) {
        return res.status(400).json({ 
          message: "Invalid resource data", 
          errors: resourceData.error.errors 
        });
      }
      
      const resource = await storage.createResource(resourceData.data);
      return res.status(201).json(resource);
    } catch (error) {
      console.error("Create resource error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.put("/resources/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      // Partial validation for update
      const resourceData = insertResourceSchema.partial().safeParse(req.body);
      
      if (!resourceData.success) {
        return res.status(400).json({ 
          message: "Invalid resource data", 
          errors: resourceData.error.errors 
        });
      }
      
      const resource = await storage.updateResource(id, resourceData.data);
      
      if (!resource) {
        return res.status(404).json({ message: "Resource not found" });
      }
      
      return res.status(200).json(resource);
    } catch (error) {
      console.error("Update resource error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Resource request endpoints
  apiRouter.get("/resource-requests", async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      
      let requests;
      if (userId) {
        requests = await storage.getUserResourceRequests(userId);
      } else {
        requests = await storage.getAllResourceRequests();
      }
      
      return res.status(200).json(requests);
    } catch (error) {
      console.error("Resource requests error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.post("/resource-requests", async (req: Request, res: Response) => {
    try {
      const requestData = insertResourceRequestSchema.safeParse(req.body);
      
      if (!requestData.success) {
        return res.status(400).json({ 
          message: "Invalid request data", 
          errors: requestData.error.errors 
        });
      }
      
      const request = await storage.createResourceRequest(requestData.data);
      return res.status(201).json(request);
    } catch (error) {
      console.error("Create resource request error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.put("/resource-requests/:id/status", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const { status } = req.body;
      
      if (!status || !['pending', 'approved', 'rejected'].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const request = await storage.updateResourceRequestStatus(id, status);
      
      if (!request) {
        return res.status(404).json({ message: "Resource request not found" });
      }
      
      return res.status(200).json(request);
    } catch (error) {
      console.error("Update resource request status error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Ingredient endpoints
  apiRouter.get("/ingredients", async (req: Request, res: Response) => {
    try {
      const query = req.query.q as string;
      let ingredients;
      
      if (query) {
        ingredients = await storage.searchIngredients(query);
      } else {
        ingredients = await storage.getAllIngredients();
      }
      
      return res.status(200).json(ingredients);
    } catch (error) {
      console.error("Ingredients error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Ingredient compatibility endpoints
  apiRouter.get("/ingredients/compatibility", async (req: Request, res: Response) => {
    try {
      const ingredientIds = req.query.ids as string;
      
      if (!ingredientIds) {
        return res.status(400).json({ message: "Ingredient IDs are required" });
      }
      
      const ids = ingredientIds.split(',').map(id => parseInt(id)).filter(id => !isNaN(id));
      
      if (ids.length === 0) {
        return res.status(400).json({ message: "Invalid ingredient IDs" });
      }
      
      const compatibility = await storage.analyzeIngredientsCompatibility(ids);
      return res.status(200).json(compatibility);
    } catch (error) {
      console.error("Ingredient compatibility error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.get("/ingredients/suggestions", async (req: Request, res: Response) => {
    try {
      const ingredientIds = req.query.ids as string;
      const category = req.query.category as string;
      const pyramid = req.query.pyramid as string;
      
      if (!ingredientIds) {
        return res.status(400).json({ message: "Ingredient IDs are required" });
      }
      
      const ids = ingredientIds.split(',').map(id => parseInt(id)).filter(id => !isNaN(id));
      
      if (ids.length === 0) {
        return res.status(400).json({ message: "Invalid ingredient IDs" });
      }
      
      const suggestions = await storage.getAdvancedIngredientSuggestions(ids, { category, pyramid });
      return res.status(200).json(suggestions);
    } catch (error) {
      console.error("Ingredient suggestions error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  apiRouter.get("/ingredients/category/:category", async (req: Request, res: Response) => {
    try {
      const category = req.params.category;
      
      if (!category) {
        return res.status(400).json({ message: "Category is required" });
      }
      
      const ingredients = await storage.getIngredientsByCategory(category);
      return res.status(200).json(ingredients);
    } catch (error) {
      console.error("Ingredients by category error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.get("/ingredients/pyramid/:pyramid", async (req: Request, res: Response) => {
    try {
      const pyramid = req.params.pyramid;
      
      if (!pyramid) {
        return res.status(400).json({ message: "Pyramid position is required" });
      }
      
      const ingredients = await storage.getIngredientsByPyramid(pyramid);
      return res.status(200).json(ingredients);
    } catch (error) {
      console.error("Ingredients by pyramid error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.get("/ingredients/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const ingredient = await storage.getIngredient(id);
      
      if (!ingredient) {
        return res.status(404).json({ message: "Ingredient not found" });
      }
      
      return res.status(200).json(ingredient);
    } catch (error) {
      console.error("Ingredient error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Formula endpoints
  apiRouter.get("/formulas", async (req: Request, res: Response) => {
    try {
      const query = req.query.q as string;
      let formulas;
      
      if (query) {
        formulas = await storage.searchFormulas(query);
      } else {
        formulas = await storage.getAllFormulas();
      }
      
      return res.status(200).json(formulas);
    } catch (error) {
      console.error("Formulas error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.get("/formulas/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const formula = await storage.getFormula(id);
      
      if (!formula) {
        return res.status(404).json({ message: "Formula not found" });
      }
      
      return res.status(200).json(formula);
    } catch (error) {
      console.error("Formula error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.get("/formulas/:id/analyze", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const formula = await storage.getFormula(id);
      
      if (!formula) {
        return res.status(404).json({ message: "Formula not found" });
      }
      
      const analysis = await storage.analyzeFormulaInteractions(id);
      return res.status(200).json(analysis);
    } catch (error) {
      console.error("Formula analysis error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.get("/formulas/:id/compatibility-suggestions", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const formula = await storage.getFormula(id);
      
      if (!formula) {
        return res.status(404).json({ message: "Formula not found" });
      }
      
      const suggestions = await storage.getFormulaCompatibilitySuggestions(id);
      return res.status(200).json(suggestions);
    } catch (error) {
      console.error("Formula compatibility suggestions error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.post("/formulas", async (req: Request, res: Response) => {
    try {
      const formulaData = insertFormulaSchema.safeParse(req.body);
      
      if (!formulaData.success) {
        return res.status(400).json({ 
          message: "Invalid formula data", 
          errors: formulaData.error.errors 
        });
      }
      
      const formula = await storage.createFormula(formulaData.data);
      return res.status(201).json(formula);
    } catch (error) {
      console.error("Create formula error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.put("/formulas/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      // Partial validation for update
      const formulaData = insertFormulaSchema.partial().safeParse(req.body);
      
      if (!formulaData.success) {
        return res.status(400).json({ 
          message: "Invalid formula data", 
          errors: formulaData.error.errors 
        });
      }
      
      const formula = await storage.updateFormula(id, formulaData.data);
      
      if (!formula) {
        return res.status(404).json({ message: "Formula not found" });
      }
      
      return res.status(200).json(formula);
    } catch (error) {
      console.error("Update formula error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Base request endpoints
  apiRouter.get("/base-requests", async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      
      let requests;
      if (userId) {
        requests = await storage.getUserBaseRequests(userId);
      } else {
        requests = await storage.getAllBaseRequests();
      }
      
      return res.status(200).json(requests);
    } catch (error) {
      console.error("Base requests error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.post("/base-requests", async (req: Request, res: Response) => {
    try {
      const requestData = insertBaseRequestSchema.safeParse(req.body);
      
      if (!requestData.success) {
        return res.status(400).json({ 
          message: "Invalid request data", 
          errors: requestData.error.errors 
        });
      }
      
      const request = await storage.createBaseRequest(requestData.data);
      return res.status(201).json(request);
    } catch (error) {
      console.error("Create base request error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.put("/base-requests/:id/status", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const { status } = req.body;
      
      if (!status || !['pending', 'approved', 'rejected'].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const request = await storage.updateBaseRequestStatus(id, status);
      
      if (!request) {
        return res.status(404).json({ message: "Base request not found" });
      }
      
      return res.status(200).json(request);
    } catch (error) {
      console.error("Update base request status error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Project endpoints
  apiRouter.get("/projects", async (req: Request, res: Response) => {
    try {
      const query = req.query.q as string;
      let projects;
      
      if (query) {
        projects = await storage.searchProjects(query);
      } else {
        projects = await storage.getAllProjects();
      }
      
      return res.status(200).json(projects);
    } catch (error) {
      console.error("Projects error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.get("/projects/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const project = await storage.getProject(id);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      return res.status(200).json(project);
    } catch (error) {
      console.error("Project error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.post("/projects", async (req: Request, res: Response) => {
    try {
      const projectData = insertProjectSchema.safeParse(req.body);
      
      if (!projectData.success) {
        return res.status(400).json({ 
          message: "Invalid project data", 
          errors: projectData.error.errors 
        });
      }
      
      const project = await storage.createProject(projectData.data);
      return res.status(201).json(project);
    } catch (error) {
      console.error("Create project error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.put("/projects/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      // Partial validation for update
      const projectData = insertProjectSchema.partial().safeParse(req.body);
      
      if (!projectData.success) {
        return res.status(400).json({ 
          message: "Invalid project data", 
          errors: projectData.error.errors 
        });
      }
      
      const project = await storage.updateProject(id, projectData.data);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      return res.status(200).json(project);
    } catch (error) {
      console.error("Update project error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Task endpoints
  apiRouter.get("/tasks", async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : undefined;
      
      let tasks;
      if (userId) {
        tasks = await storage.getUserTasks(userId);
      } else if (projectId) {
        tasks = await storage.getProjectTasks(projectId);
      } else {
        tasks = await storage.getAllTasks();
      }
      
      return res.status(200).json(tasks);
    } catch (error) {
      console.error("Tasks error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.get("/tasks/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const task = await storage.getTask(id);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      return res.status(200).json(task);
    } catch (error) {
      console.error("Task error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.post("/tasks", async (req: Request, res: Response) => {
    try {
      const taskData = insertTaskSchema.safeParse(req.body);
      
      if (!taskData.success) {
        return res.status(400).json({ 
          message: "Invalid task data", 
          errors: taskData.error.errors 
        });
      }
      
      const task = await storage.createTask(taskData.data);
      return res.status(201).json(task);
    } catch (error) {
      console.error("Create task error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.put("/tasks/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      // Partial validation for update
      const taskData = insertTaskSchema.partial().safeParse(req.body);
      
      if (!taskData.success) {
        return res.status(400).json({ 
          message: "Invalid task data", 
          errors: taskData.error.errors 
        });
      }
      
      const task = await storage.updateTask(id, taskData.data);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      return res.status(200).json(task);
    } catch (error) {
      console.error("Update task error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.put("/tasks/:id/status", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const { status } = req.body;
      
      if (!status || !['pending', 'in_progress', 'completed'].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const task = await storage.updateTaskStatus(id, status);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      return res.status(200).json(task);
    } catch (error) {
      console.error("Update task status error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // CAS number endpoint for resource request form
  apiRouter.get("/cas-numbers", async (req: Request, res: Response) => {
    try {
      // In a real app, this would come from a database
      // Using mock data for demo purposes
      const casNumbers = [
        "64-17-5", // Ethanol
        "67-63-0", // Isopropyl alcohol
        "78-70-6", // Linalool
        "98-55-5", // Alpha-Terpineol
        "105-87-3", // Geranyl acetate
        "106-24-1", // Geraniol
        "107-75-5", // Hydroxycitronellal
        "118-58-1", // Benzyl salicylate
        "120-51-4", // Benzyl benzoate
        "128-37-0", // Butylated hydroxytoluene
      ];
      return res.status(200).json(casNumbers);
    } catch (error) {
      console.error("Error fetching CAS numbers:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Resource inventory management endpoints
  
  // Mount the API router
  // User management endpoints
  apiRouter.get("/users", async (req: Request, res: Response) => {
    try {
      const team = req.query.team as string;
      let users;
      
      if (team) {
        users = await storage.getUsersByTeam(team);
      } else {
        users = await storage.getAllUsers();
      }
      
      // Remove password from response
      const safeUsers = users.map(user => {
        const { password, ...safeUser } = user;
        return safeUser;
      });
      
      return res.status(200).json(safeUsers);
    } catch (error) {
      console.error("Users error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.get("/users/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const user = await storage.getUser(id);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password, ...safeUser } = user;
      
      return res.status(200).json(safeUser);
    } catch (error) {
      console.error("User error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.post("/users", async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.safeParse(req.body);
      
      if (!userData.success) {
        return res.status(400).json({ 
          message: "Invalid user data", 
          errors: userData.error.errors 
        });
      }
      
      // If permissions are not provided, set default permissions based on role and team
      if (!userData.data.permissions) {
        userData.data.permissions = getDefaultPermissions(
          userData.data.role,
          userData.data.team
        );
      }
      
      const user = await storage.createUser(userData.data);
      
      // Remove password from response
      const { password, ...safeUser } = user;
      
      return res.status(201).json(safeUser);
    } catch (error) {
      console.error("Create user error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.put("/users/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      // Partial validation for update
      const userData = insertUserSchema.partial().safeParse(req.body);
      
      if (!userData.success) {
        return res.status(400).json({ 
          message: "Invalid user data", 
          errors: userData.error.errors 
        });
      }
      
      const user = await storage.updateUser(id, userData.data);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password, ...safeUser } = user;
      
      return res.status(200).json(safeUser);
    } catch (error) {
      console.error("Update user error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.put("/users/:id/permissions", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const { permissions } = req.body;
      
      if (!Array.isArray(permissions)) {
        return res.status(400).json({ message: "Permissions must be an array" });
      }
      
      // Validate that all permissions are valid
      const allPermissions = getAllPermissions();
      const invalidPermissions = permissions.filter(p => !allPermissions.includes(p));
      
      if (invalidPermissions.length > 0) {
        return res.status(400).json({ 
          message: "Invalid permissions", 
          invalidPermissions 
        });
      }
      
      const user = await storage.updateUserPermissions(id, permissions);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password, ...safeUser } = user;
      
      return res.status(200).json(safeUser);
    } catch (error) {
      console.error("Update user permissions error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.put("/users/:id/status", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const { isActive } = req.body;
      
      if (typeof isActive !== 'boolean') {
        return res.status(400).json({ message: "isActive must be a boolean" });
      }
      
      const user = await storage.updateUser(id, { isActive });
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password, ...safeUser } = user;
      
      return res.status(200).json(safeUser);
    } catch (error) {
      console.error("Update user status error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.delete("/users/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const deleted = await storage.deleteUser(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "User not found" });
      }
      
      return res.status(204).send();
    } catch (error) {
      console.error("Delete user error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Reference data endpoints
  apiRouter.get("/reference/permissions", async (req: Request, res: Response) => {
    try {
      return res.status(200).json({
        permissions: getAllPermissions()
      });
    } catch (error) {
      console.error("Permissions error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.get("/reference/roles", async (req: Request, res: Response) => {
    try {
      return res.status(200).json({
        roles: getAllRoles()
      });
    } catch (error) {
      console.error("Roles error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.get("/reference/teams", async (req: Request, res: Response) => {
    try {
      return res.status(200).json({
        teams: getAllTeams()
      });
    } catch (error) {
      console.error("Teams error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.use("/api", apiRouter);

  const httpServer = createServer(app);
  return httpServer;
}
