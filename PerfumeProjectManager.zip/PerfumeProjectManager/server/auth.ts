import { User, PERMISSIONS, ROLES, TEAMS } from "../shared/schema";

// Default role permissions mapping
const ROLE_PERMISSIONS = {
  [ROLES.ADMIN]: Object.values(PERMISSIONS),
  [ROLES.MANAGER]: [
    PERMISSIONS.VIEW_DASHBOARD,
    PERMISSIONS.VIEW_RESOURCES,
    PERMISSIONS.VIEW_REQUESTS,
    PERMISSIONS.APPROVE_REQUESTS,
    PERMISSIONS.VIEW_FORMULAS,
    PERMISSIONS.VIEW_PROJECTS,
    PERMISSIONS.EDIT_PROJECTS,
    PERMISSIONS.CREATE_PROJECTS,
    PERMISSIONS.VIEW_TASKS,
    PERMISSIONS.CREATE_TASKS,
    PERMISSIONS.EDIT_TASKS,
    PERMISSIONS.ASSIGN_TASKS,
  ],
  [ROLES.SPECIALIST]: [
    PERMISSIONS.VIEW_DASHBOARD,
    PERMISSIONS.VIEW_RESOURCES,
    PERMISSIONS.CREATE_RESOURCES,
    PERMISSIONS.EDIT_RESOURCES,
    PERMISSIONS.VIEW_REQUESTS,
    PERMISSIONS.CREATE_REQUESTS,
    PERMISSIONS.VIEW_FORMULAS,
    PERMISSIONS.VIEW_PROJECTS,
    PERMISSIONS.VIEW_TASKS,
    PERMISSIONS.EDIT_TASKS,
  ],
  [ROLES.USER]: [
    PERMISSIONS.VIEW_DASHBOARD,
    PERMISSIONS.VIEW_RESOURCES,
    PERMISSIONS.VIEW_REQUESTS,
    PERMISSIONS.CREATE_REQUESTS,
    PERMISSIONS.VIEW_FORMULAS,
    PERMISSIONS.VIEW_PROJECTS,
    PERMISSIONS.VIEW_TASKS,
  ],
};

// Default team permissions mapping
const TEAM_PERMISSIONS = {
  [TEAMS.PURCHASE]: [
    PERMISSIONS.VIEW_RESOURCES,
    PERMISSIONS.CREATE_RESOURCES,
    PERMISSIONS.EDIT_RESOURCES,
    PERMISSIONS.VIEW_REQUESTS,
    PERMISSIONS.APPROVE_REQUESTS,
  ],
  [TEAMS.REGULATORY]: [
    PERMISSIONS.VIEW_RESOURCES,
    PERMISSIONS.VIEW_FORMULAS,
  ],
  [TEAMS.ANALYTICAL]: [
    PERMISSIONS.VIEW_RESOURCES,
    PERMISSIONS.EDIT_RESOURCES,
    PERMISSIONS.VIEW_FORMULAS,
    PERMISSIONS.EDIT_FORMULAS,
  ],
  [TEAMS.RND]: [
    PERMISSIONS.VIEW_RESOURCES,
    PERMISSIONS.VIEW_FORMULAS,
    PERMISSIONS.CREATE_FORMULAS,
    PERMISSIONS.EDIT_FORMULAS,
  ],
  [TEAMS.QC]: [
    PERMISSIONS.VIEW_RESOURCES,
    PERMISSIONS.VIEW_FORMULAS,
  ],
  [TEAMS.PERFUMER]: [
    PERMISSIONS.VIEW_RESOURCES,
    PERMISSIONS.VIEW_FORMULAS,
    PERMISSIONS.CREATE_FORMULAS,
    PERMISSIONS.EDIT_FORMULAS,
  ],
  [TEAMS.ADMIN]: Object.values(PERMISSIONS),
};

// Helper to get default permissions based on role and team
export function getDefaultPermissions(role: string, team: string): string[] {
  const rolePerms = ROLE_PERMISSIONS[role as keyof typeof ROLE_PERMISSIONS] || [];
  const teamPerms = TEAM_PERMISSIONS[team as keyof typeof TEAM_PERMISSIONS] || [];
  
  // Combine and remove duplicates
  return Array.from(new Set([...rolePerms, ...teamPerms]));
}

// Check if user has a specific permission
export function hasPermission(user: User, permission: string): boolean {
  if (!user || !user.isActive) return false;
  
  // Admin role has all permissions
  if (user.role === ROLES.ADMIN) return true;
  
  // Check if permission is in user's permissions array
  try {
    const permissions = user.permissions as string[];
    return permissions.includes(permission);
  } catch (error) {
    console.error('Error checking permissions:', error);
    return false;
  }
}

// Check if user has any of the listed permissions
export function hasAnyPermission(user: User, permissions: string[]): boolean {
  return permissions.some(permission => hasPermission(user, permission));
}

// Check if user has all of the listed permissions
export function hasAllPermissions(user: User, permissions: string[]): boolean {
  return permissions.every(permission => hasPermission(user, permission));
}

// Get a list of all possible permissions
export function getAllPermissions(): string[] {
  return Object.values(PERMISSIONS);
}

// Get a list of all possible roles
export function getAllRoles(): string[] {
  return Object.values(ROLES);
}

// Get a list of all possible teams
export function getAllTeams(): string[] {
  return Object.values(TEAMS);
}