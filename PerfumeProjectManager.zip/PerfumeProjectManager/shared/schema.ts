import { pgTable, text, serial, integer, decimal, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Permission constants
export const PERMISSIONS = {
  // Resource permissions
  VIEW_RESOURCES: "view_resources",
  CREATE_RESOURCES: "create_resources",
  EDIT_RESOURCES: "edit_resources",
  DELETE_RESOURCES: "delete_resources",
  
  // Request permissions
  VIEW_REQUESTS: "view_requests",
  CREATE_REQUESTS: "create_requests",
  APPROVE_REQUESTS: "approve_requests",
  
  // Formula permissions
  VIEW_FORMULAS: "view_formulas",
  CREATE_FORMULAS: "create_formulas",
  EDIT_FORMULAS: "edit_formulas",
  
  // Project permissions
  VIEW_PROJECTS: "view_projects",
  CREATE_PROJECTS: "create_projects",
  EDIT_PROJECTS: "edit_projects",
  
  // Task permissions
  VIEW_TASKS: "view_tasks",
  CREATE_TASKS: "create_tasks",
  EDIT_TASKS: "edit_tasks",
  ASSIGN_TASKS: "assign_tasks",
  
  // User management
  MANAGE_USERS: "manage_users",
  
  // Dashboard
  VIEW_DASHBOARD: "view_dashboard",
};

// Team types
export const TEAMS = {
  PURCHASE: "purchase",
  REGULATORY: "regulatory",
  ANALYTICAL: "analytical",
  RND: "r&d",
  QC: "qc",
  PERFUMER: "perfumer",
  ADMIN: "admin",
} as const;

export type TeamType = typeof TEAMS[keyof typeof TEAMS];

// User roles
export const ROLES = {
  ADMIN: "admin",
  MANAGER: "manager",
  SPECIALIST: "specialist",
  USER: "user",
} as const;

export type RoleType = typeof ROLES[keyof typeof ROLES];

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  role: text("role").notNull(),
  team: text("team").notNull(),
  email: text("email").notNull(),
  department: text("department"),
  permissions: jsonb("permissions").notNull().default('[]'),
  isActive: boolean("is_active").notNull().default(true),
  lastLogin: timestamp("last_login"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  role: true,
  team: true,
  email: true,
  department: true,
  permissions: true,
  isActive: true,
});

// Resources schema
export const resources = pgTable("resources", {
  id: serial("id").primaryKey(),
  code: text("code"),
  name: text("name").notNull(),
  category: text("category").notNull(),
  type: text("type").notNull(),
  description: text("description"),
  quantity: integer("quantity").default(0),
  unit: text("unit"),
  costPerUnit: integer("cost_per_unit"),
  currency: text("currency"),
  supplier: text("supplier"),
  status: text("status"),
  pyramid: integer("pyramid"),
  odour: text("odour"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertResourceSchema = createInsertSchema(resources).pick({
  code: true,
  name: true,
  category: true,
  type: true,
  description: true,
  quantity: true,
  unit: true,
  costPerUnit: true,
  currency: true,
  supplier: true,
  status: true,
  pyramid: true,
  odour: true,
  notes: true,
});

// Resource Requests schema
export const resourceRequests = pgTable("resource_requests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  resourceId: integer("resource_id").notNull(),
  quantity: integer("quantity").notNull(),
  urgency: text("urgency").notNull(),
  status: text("status").notNull().default("pending"),
  reason: text("reason"),
  createdAt: timestamp("created_at").defaultNow(),
  resolvedAt: timestamp("resolved_at"),
  // Custom fields for new resource requests
  customFields: jsonb("custom_fields"),
});

export const insertResourceRequestSchema = createInsertSchema(resourceRequests).pick({
  userId: true,
  resourceId: true,
  quantity: true,
  urgency: true,
  reason: true,
  customFields: true,
});

// Ingredients schema
export const ingredients = pgTable("ingredients", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  casNumber: text("cas_number"),
  category: text("category").notNull(),
  odorProfile: jsonb("odor_profile").default('[]'),
  concentration: decimal("concentration", { precision: 10, scale: 2 }),
  solubility: text("solubility"),
  flashPoint: decimal("flash_point", { precision: 10, scale: 2 }),
  appearanceState: text("appearance_state"),
  tenacity: text("tenacity"),
  stability: text("stability"),
  molecularWeight: decimal("molecular_weight", { precision: 10, scale: 2 }),
  pyramid: text("pyramid"), // Top, Middle, Base note
  potency: text("potency"), // Weak, Moderate, Strong
  allergenInfo: jsonb("allergen_info"),
  restrictions: jsonb("restrictions"),
  incompatibleWith: jsonb("incompatible_with").default('[]'),
  substitutes: jsonb("substitutes").default('[]'),
  enhancedBy: jsonb("enhanced_by").default('[]'),
  recommendations: jsonb("recommendations").default('{}'),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at"),
});

export const insertIngredientSchema = createInsertSchema(ingredients).pick({
  name: true,
  casNumber: true,
  category: true,
  odorProfile: true,
  concentration: true,
  solubility: true,
  flashPoint: true,
  appearanceState: true,
  tenacity: true,
  stability: true,
  molecularWeight: true,
  pyramid: true,
  potency: true,
  allergenInfo: true,
  restrictions: true,
  incompatibleWith: true,
  substitutes: true,
  enhancedBy: true,
  recommendations: true,
});

// Ingredient Interactions schema
export const ingredientInteractions = pgTable("ingredient_interactions", {
  id: serial("id").primaryKey(),
  ingredientAId: integer("ingredient_a_id").notNull(),
  ingredientBId: integer("ingredient_b_id").notNull(),
  interactionType: text("interaction_type").notNull(), // Enhances, Conflicts, Substitutes, Complements
  effect: text("effect").notNull(),
  strengthLevel: integer("strength_level").notNull(), // 1-10 scale
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at"),
});

export const insertIngredientInteractionSchema = createInsertSchema(ingredientInteractions).pick({
  ingredientAId: true,
  ingredientBId: true,
  interactionType: true,
  effect: true,
  strengthLevel: true,
  notes: true,
});

// Formulas schema
export const formulas = pgTable("formulas", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  type: text("type").notNull(),
  category: text("category").notNull(),
  composition: jsonb("composition").notNull(),
  iflAccordId: text("ifl_accord_id"), // International Fragrance Library accord identifier
  properties: jsonb("properties").default('{}'), // Calculated properties like sillage, longevity, etc.
  interactionScore: integer("interaction_score"), // Overall score of ingredient compatibility
  safetyProfile: jsonb("safety_profile").default('{}'), // Allergen declarations, IFRA compliance
  sustainabilityScore: integer("sustainability_score"), // Environmental impact score
  createdBy: integer("created_by").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at"),
  status: text("status").notNull(),
  notes: text("notes"),
  version: integer("version").default(1),
  parentFormulaId: integer("parent_formula_id"), // For formula versions/iterations
});

export const insertFormulaSchema = createInsertSchema(formulas).pick({
  name: true,
  description: true,
  type: true,
  category: true,
  composition: true,
  iflAccordId: true,
  properties: true,
  interactionScore: true,
  safetyProfile: true,
  sustainabilityScore: true,
  createdBy: true,
  status: true,
  notes: true,
  version: true,
  parentFormulaId: true,
});

// Base Requests schema
export const baseRequests = pgTable("base_requests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  purpose: text("purpose").notNull(),
  description: text("description"),
  urgency: text("urgency").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
  resolvedAt: timestamp("resolved_at"),
});

export const insertBaseRequestSchema = createInsertSchema(baseRequests).pick({
  userId: true,
  name: true,
  purpose: true,
  description: true,
  urgency: true,
});

// Projects schema
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  client: text("client").notNull(),
  description: text("description"),
  startDate: timestamp("start_date").notNull(),
  dueDate: timestamp("due_date"),
  status: text("status").notNull(),
  stage: text("stage").notNull(),
  manager: integer("manager").notNull(),
  team: jsonb("team").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at"),
});

export const insertProjectSchema = createInsertSchema(projects).pick({
  name: true,
  client: true,
  description: true,
  startDate: true,
  dueDate: true,
  status: true,
  stage: true,
  manager: true,
  team: true,
  notes: true,
});

// Tasks schema
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  assignedTo: integer("assigned_to").notNull(),
  projectId: integer("project_id"),
  dueDate: timestamp("due_date"),
  priority: text("priority").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at"),
  completedAt: timestamp("completed_at"),
});

export const insertTaskSchema = createInsertSchema(tasks).pick({
  title: true,
  description: true,
  assignedTo: true,
  projectId: true,
  dueDate: true,
  priority: true,
});

// Define export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Resource = typeof resources.$inferSelect;
export type InsertResource = z.infer<typeof insertResourceSchema>;

export type ResourceRequest = typeof resourceRequests.$inferSelect;
export type InsertResourceRequest = z.infer<typeof insertResourceRequestSchema>;

export type Formula = typeof formulas.$inferSelect;
export type InsertFormula = z.infer<typeof insertFormulaSchema>;

export type BaseRequest = typeof baseRequests.$inferSelect;
export type InsertBaseRequest = z.infer<typeof insertBaseRequestSchema>;

export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;

// Resource Allocations schema
export const resourceAllocations = pgTable("resource_allocations", {
  id: serial("id").primaryKey(),
  resourceId: integer("resource_id").notNull(),
  projectId: integer("project_id"),
  formulaId: integer("formula_id"),
  userId: integer("user_id").notNull(), // User who made the allocation
  quantity: decimal("quantity", { precision: 10, scale: 2 }).notNull(),
  status: text("status").notNull().default("allocated"), // allocated, consumed, returned
  notes: text("notes"),
  allocatedAt: timestamp("allocated_at").defaultNow(),
  updatedAt: timestamp("updated_at"),
  dueDate: timestamp("due_date"), // When the resource is expected to be returned/consumed
});

export const insertResourceAllocationSchema = createInsertSchema(resourceAllocations).pick({
  resourceId: true,
  projectId: true,
  formulaId: true,
  userId: true,
  quantity: true,
  status: true,
  notes: true,
  dueDate: true,
});

// Resource Inventory Transactions schema - to track all inventory movements
export const resourceTransactions = pgTable("resource_transactions", {
  id: serial("id").primaryKey(),
  resourceId: integer("resource_id").notNull(),
  userId: integer("user_id").notNull(), // User who performed the transaction
  transactionType: text("transaction_type").notNull(), // received, allocated, returned, consumed, adjusted, etc.
  quantity: decimal("quantity", { precision: 10, scale: 2 }).notNull(), // Positive for inflow, negative for outflow
  relatedAllocationId: integer("related_allocation_id"), // If transaction is related to an allocation
  notes: text("notes"),
  transactionDate: timestamp("transaction_date").defaultNow(),
  batchNumber: text("batch_number"), // Tracking batches of resources
  expiryDate: timestamp("expiry_date"), // For resources with expiry dates
});

export const insertResourceTransactionSchema = createInsertSchema(resourceTransactions).pick({
  resourceId: true,
  userId: true,
  transactionType: true,
  quantity: true,
  relatedAllocationId: true,
  notes: true,
  batchNumber: true,
  expiryDate: true,
});

// Resource Threshold Alerts schema - for inventory management
export const resourceThresholds = pgTable("resource_thresholds", {
  id: serial("id").primaryKey(),
  resourceId: integer("resource_id").notNull(),
  minimumLevel: decimal("minimum_level", { precision: 10, scale: 2 }).notNull(),
  targetLevel: decimal("target_level", { precision: 10, scale: 2 }),
  alertEnabled: boolean("alert_enabled").default(true),
  alertMessage: text("alert_message"),
  createdBy: integer("created_by").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at"),
});

export const insertResourceThresholdSchema = createInsertSchema(resourceThresholds).pick({
  resourceId: true,
  minimumLevel: true,
  targetLevel: true,
  alertEnabled: true,
  alertMessage: true,
  createdBy: true,
});

export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;

export type ResourceAllocation = typeof resourceAllocations.$inferSelect;
export type InsertResourceAllocation = z.infer<typeof insertResourceAllocationSchema>;

export type ResourceTransaction = typeof resourceTransactions.$inferSelect;
export type InsertResourceTransaction = z.infer<typeof insertResourceTransactionSchema>;

export type ResourceThreshold = typeof resourceThresholds.$inferSelect;
export type InsertResourceThreshold = z.infer<typeof insertResourceThresholdSchema>;

export type Ingredient = typeof ingredients.$inferSelect;
export type InsertIngredient = z.infer<typeof insertIngredientSchema>;

export type IngredientInteraction = typeof ingredientInteractions.$inferSelect;
export type InsertIngredientInteraction = z.infer<typeof insertIngredientInteractionSchema>;
